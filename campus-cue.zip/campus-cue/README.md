# Campus Cue

A Georgia Tech DJ workspace with 154 vocal song links, editable sets, Atlanta/rap/college-bar filters, uploaded audio, listening summaries, and mix suggestions based on saved track preparation and rated transitions.

## Run locally

Install Node.js 22.13 or newer and Git. Open a terminal inside this folder:

```sh
npm install --global pnpm@11.25.0
pnpm install --frozen-lockfile
pnpm db:setup
pnpm dev
```

Open **http://localhost:5173**. Keep the terminal running. Stop with Ctrl+C.

The migrations create a local SQLite database through Cloudflare D1 emulation. On the first library load, the app adds its song catalog and starter sets. Audio uploads use local R2 emulation. Local data stays under `.wrangler/` and is ignored by Git. No Spotify developer key or AI API key is needed. Spotify playback depends on Spotify availability and the listener's account.

## Create your GitHub repository

1. Extract the ZIP and open the `campus-cue` folder in VS Code.
2. On GitHub, create an empty repository named `campus-cue`. Leave the README, license, and gitignore options unchecked.
3. Run these commands in the folder. Replace `YOUR_USERNAME` with your GitHub username:

```sh
git init
git add .
git commit -m "Initial Campus Cue app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/campus-cue.git
git push -u origin main
```

GitHub may prompt you to sign in. Do not commit passwords, tokens, uploads, or local database files.

## Check the app

```sh
pnpm check
pnpm build
pnpm test
```

To run the compiled app locally after building, use `pnpm start` and open the address printed by Wrangler. The integration tests use isolated databases and buckets.

## What is included

- `app/`: interface and API routes.
- `components/`: small UI components and playback hooks.
- `lib/`: catalog, search, SQL access, and recommendation logic.
- `db/schema.ts` and `drizzle/`: schema and all four migrations.
- `scripts/verify-*.mjs`: behavior checks.
- `wrangler.json`: local database/storage configuration.
- `pnpm-lock.yaml`: locked dependency versions.
- `docs/IMPLEMENTATION.md`: detailed model behavior, sources, and limitations. Its original Sites deployment commands describe the hosted version; use this README for this standalone export.

## Limits and deployment

The ZIP contains source code, not your live site's database, uploaded audio, likes, or ratings. It includes the catalog and default editable sets. GitHub stores the code; GitHub Pages cannot run this SQL/Worker app.

This export is configured for **local use** and has no login or access-control system. Before hosting it elsewhere, add authentication, create your own D1 database and R2 bucket, update their IDs/names in `wrangler.json`, apply migrations to the remote database, and configure the built Worker. The placeholder database ID is for local emulation only. Your existing Campus Cue site remains separate.

Mix scores are ranking aids. BPM/key/groove are entered by the user; Spotify audio is not analyzed and the app does not mix audio automatically. The personal model learns from explicitly rated transitions. Its predictive accuracy has not been measured.

Exported from source commit `5f152ccb6775951381e278c4261b43d07cbc1baf`, with standalone local configuration added. Browser interaction and Spotify playback remain unverified.
