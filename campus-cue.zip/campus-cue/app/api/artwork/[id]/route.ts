import { database } from '@/lib/data';
import { artworkResponse, artworkFallback } from '@/lib/artwork-response';
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const track = await database().prepare('SELECT spotify_id FROM tracks WHERE id=?').bind(id).first<{ spotify_id: string | null }>();
    if (!track?.spotify_id) return new Response(null, { status: 404 });
    return artworkResponse(track.spotify_id);
  } catch { return artworkFallback(); }
}
