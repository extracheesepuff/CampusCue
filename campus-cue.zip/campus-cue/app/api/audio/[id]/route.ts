import { database,bucket } from '@/lib/data';
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){
 try{
 const {id}=await params;const track=await database().prepare('SELECT audio_key FROM tracks WHERE id=?').bind(id).first<{audio_key:string|null}>();
 if(!track?.audio_key)return new Response('Audio not found',{status:404});
 const b=bucket();const head=await b.head(track.audio_key);if(!head)return new Response('Audio not found',{status:404});
 const range=req.headers.get('range');let start=0,end=head.size-1;
 if(range){const m=/^bytes=(\d*)-(\d*)$/.exec(range);if(!m||(!m[1]&&!m[2]))return new Response(null,{status:416,headers:{'Content-Range':`bytes */${head.size}`}});
 if(!m[1])start=Math.max(0,head.size-Number(m[2]));else{start=Number(m[1]);if(m[2])end=Math.min(end,Number(m[2]));}
 if(!Number.isSafeInteger(start)||!Number.isSafeInteger(end)||start>end||start>=head.size)return new Response(null,{status:416,headers:{'Content-Range':`bytes */${head.size}`}});
 }
 const obj=await b.get(track.audio_key,range?{range:{offset:start,length:end-start+1}}:undefined);if(!obj)return new Response('Audio not found',{status:404});
 const headers=new Headers({'Accept-Ranges':'bytes','Content-Length':String(end-start+1),'Cache-Control':'private, max-age=3600','X-Content-Type-Options':'nosniff'});obj.writeHttpMetadata(headers);if(range)headers.set('Content-Range',`bytes ${start}-${end}/${head.size}`);
 return new Response(obj.body,{status:range?206:200,headers});
 }catch(e){console.error(e);return new Response('Audio temporarily unavailable',{status:503});}
}
