import { database, initialize, snapshot } from '@/lib/data';
import { features, camelotKeys, techniques, type Prep } from '@/lib/dj-model';
import { grooves, vocalLevels } from '@/lib/rhythm';
import type { Track } from '@/lib/types';
import { z } from 'zod';
const trackId = z.string().min(1).max(100);
const nullableNumber = (low: number, high: number) => z.number().finite().min(low).max(high).nullable();
const entry = z.object({
  id: z.string().uuid(),
  fromId: trackId,
  toId: trackId,
  rating: z.number().int().min(1).max(5),
  technique: z.enum(techniques),
  notes: z.string().trim().max(500).default('')
});
const actions = z.discriminatedUnion('action', [z.object({
  action: z.literal('prep'),
  trackId,
  revision: z.number().int().min(-1),
  bpm: nullableNumber(40, 240),
  camelot: z.enum(camelotKeys as [string, ...string[]]).nullable(),
  energy: z.number().int().min(1).max(10).nullable(),
  cueIn: nullableNumber(0, 7200),
  cueOut: nullableNumber(0, 7200),
  notes: z.string().trim().max(1000),
  groove: z.enum(grooves).nullable().optional(),
  phraseBars: z.union([z.literal(8), z.literal(16), z.literal(32)]).nullable().optional(),
  introVocals: z.enum(vocalLevels).nullable().optional(),
  outroVocals: z.enum(vocalLevels).nullable().optional()
}), z.object({
  action: z.literal('record'),
  entries: z.array(entry).min(1).max(100)
}), z.object({
  action: z.literal('delete'),
  id: z.string().uuid()
})]);
const json = (d: unknown, status = 200) => Response.json(d, {
  status,
  headers: {
    'Cache-Control': 'no-store'
  }
});
export async function GET() {
  try {
    await initialize();
    const db = database();
    const rows = await db.batch([db.prepare('SELECT * FROM dj_prep'), db.prepare('SELECT * FROM dj_transitions ORDER BY created_at DESC,id DESC LIMIT 500'), db.prepare('SELECT COUNT(*) AS count FROM dj_transitions')]);
    return json({
      prep: rows[0].results,
      transitions: rows[1].results,
      total: (rows[2].results[0] as {
        count: number;
      }).count
    });
  } catch (e) {
    console.error(e);
    return json({
      error: 'DJ history unavailable. Try again.'
    }, 503);
  }
}
export async function POST(req: Request) {
  if (req.headers.get('origin') && req.headers.get('origin') !== new URL(req.url).origin) return json({
    error: 'Invalid request origin'
  }, 403);
  try {
    const a = actions.parse(await req.json());
    await initialize();
    const db = database();
    if (a.action === 'prep') {
      const track = await db.prepare('SELECT id,duration,spotify_id FROM tracks WHERE id=? AND is_demo=0').bind(a.trackId).first<{
        id: string;
        duration: number;
        spotify_id: string | null;
      }>();
      if (!track) return json({
        error: 'Track not found.'
      }, 404);
      if (a.cueIn !== null && a.cueOut !== null && a.cueOut <= a.cueIn) return json({
        error: 'Mix-out must come after mix-in.'
      }, 400);
      if (!track.spotify_id && [a.cueIn, a.cueOut].some(c => c !== null && c > track.duration)) return json({
        error: 'Cue point exceeds the uploaded audio length.'
      }, 400);
      // Older clients omit rhythm fields; preserve those values on an update.
      const previous = await db.prepare('SELECT * FROM dj_prep WHERE track_id=?').bind(a.trackId).first<Prep>();
      const keep = (value: unknown, old: unknown) => value === undefined ? old ?? null : value;
      const values = [a.bpm, a.camelot, a.energy, a.cueIn, a.cueOut, a.notes, keep(a.groove, previous?.groove), keep(a.phraseBars, previous?.phrase_bars), keep(a.introVocals, previous?.intro_vocals), keep(a.outroVocals, previous?.outro_vocals)];
      const result = a.revision === -1 ? await db.prepare('INSERT OR IGNORE INTO dj_prep (track_id,bpm,camelot,energy,cue_in,cue_out,notes,groove,phrase_bars,intro_vocals,outro_vocals) VALUES (?,?,?,?,?,?,?,?,?,?,?)').bind(a.trackId, ...values).run() : await db.prepare('UPDATE dj_prep SET bpm=?,camelot=?,energy=?,cue_in=?,cue_out=?,notes=?,groove=?,phrase_bars=?,intro_vocals=?,outro_vocals=?,revision=revision+1 WHERE track_id=? AND revision=?').bind(...values, a.trackId, a.revision).run();
      if (!result.meta.changes) return json({
        error: 'Track prep changed in another tab. Reload before saving.'
      }, 409);
    } else if (a.action === 'record') {
      if (new Set(a.entries.map(e => e.id)).size !== a.entries.length) return json({
        error: 'Duplicate history entry IDs.'
      }, 400);
      const library = await snapshot(),
        prep = (await db.prepare('SELECT * FROM dj_prep').all<Prep>()).results;
      const tracks = library.tracks as unknown as Track[];
      const stmts = [];
      for (const e of a.entries) {
        const from = tracks.find(t => t.id === e.fromId),
          to = tracks.find(t => t.id === e.toId);
        if (!from || !to) return json({
          error: 'One or more tracks were not found.'
        }, 404);
        if (from.id === to.id) return json({
          error: 'Select two different tracks.'
        }, 400);
        stmts.push(db.prepare('INSERT OR IGNORE INTO dj_transitions (id,from_id,to_id,rating,technique,notes,features) VALUES (?,?,?,?,?,?,?)').bind(e.id, e.fromId, e.toId, e.rating, e.technique, e.notes, JSON.stringify(features(from, to, prep))));
      }
      await db.batch(stmts);
    } else await db.prepare('DELETE FROM dj_transitions WHERE id=?').bind(a.id).run();
    return json({
      ok: true
    });
  } catch (e) {
    if (e instanceof z.ZodError) return json({
      error: e.issues[0]?.message ?? 'Invalid input.'
    }, 400);
    if (e instanceof SyntaxError) return json({
      error: 'Invalid JSON.'
    }, 400);
    console.error(e);
    return json({
      error: 'Could not save DJ data. Try again.'
    }, 503);
  }
}
