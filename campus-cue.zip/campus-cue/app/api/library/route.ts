import { database, initialize, snapshot, bucket } from '@/lib/data';
import { genres } from '@/lib/genres';
import { z } from 'zod';
const name=z.string().trim().min(1).max(100);
const id=z.string().min(1).max(100);
const actions=z.discriminatedUnion('action',[
 z.object({action:z.literal('createPlaylist'),name,description:z.string().trim().max(240).default('')}),
 z.object({action:z.literal('renamePlaylist'),id,name,description:z.string().trim().max(240).default('')}),
 z.object({action:z.literal('deletePlaylist'),id}),
 z.object({action:z.literal('addTrack'),playlistId:id,trackId:id}),z.object({action:z.literal('removeTrack'),playlistId:id,trackId:id}),
 z.object({action:z.literal('reorder'),playlistId:id,revision:z.number().int().min(0),trackIds:z.array(id).max(500)}),
 z.object({action:z.literal('favorite'),userId:id,trackId:id,liked:z.boolean()}),
 z.object({action:z.literal('listen'),userId:id,trackId:id,seconds:z.number().finite().min(2).max(7200),eventId:z.string().uuid()}),
 z.object({action:z.literal('createUser'),name})
]);
const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){try{await initialize();return json(await snapshot());}catch(e){console.error(e);return json({error:'Your library is unavailable. Try again.'},503);}}
export async function POST(req:Request){
 if(req.headers.get('origin') && new URL(req.url).origin!==req.headers.get('origin'))return json({error:'Invalid request origin'},403);
 try{
 const db=database();
 if(req.headers.get('content-type')?.startsWith('multipart/form-data')){
 const size=Number(req.headers.get('content-length')??0);if(size>22*1024*1024)return json({error:'Audio files must be 20 MB or smaller.'},413);
 const form=await req.formData();const file=form.get('audio');
 const meta=z.object({title:name,creator:name,genre:z.enum(genres),bpm:z.coerce.number().finite().min(40).max(240),key:name,duration:z.coerce.number().finite().positive().max(7200)}).parse(Object.fromEntries(form));
 if(!(file instanceof File)||!file.size||file.size>20*1024*1024)return json({error:'Choose an audio file up to 20 MB.'},400);
 const types:Record<string,string>={'mp3':'audio/mpeg','wav':'audio/wav','ogg':'audio/ogg','m4a':'audio/mp4'};const ext=file.name.split('.').pop()?.toLowerCase()??'';
 if(!types[ext])return json({error:'Supported formats: MP3, WAV, OGG, M4A.'},400);
 const head=new Uint8Array(await file.slice(0,16).arrayBuffer());const sig=new TextDecoder().decode(head);
 const valid=ext==='wav'?sig.startsWith('RIFF')&&sig.slice(8,12)==='WAVE':ext==='ogg'?sig.startsWith('OggS'):ext==='m4a'?sig.slice(4,8)==='ftyp':sig.startsWith('ID3')||(head[0]===255&&(head[1]&224)===224);
 if(!valid)return json({error:'The file contents do not match its audio format.'},400);
 const trackId=crypto.randomUUID(),creatorId=crypto.randomUUID(),key=`audio/${trackId}.${ext}`;
 await bucket().put(key,file.stream(),{httpMetadata:{contentType:types[ext]}});
 try{await db.batch([
 db.prepare('INSERT OR IGNORE INTO creators (id,name,normalized_name) VALUES (?,?,?)').bind(creatorId,meta.creator,meta.creator.toLowerCase()),
 db.prepare('INSERT INTO tracks (id,creator_id,title,genre,bpm,musical_key,duration,audio_key) SELECT ?,id,?,?,?,?,?,? FROM creators WHERE normalized_name=?').bind(trackId,meta.title,meta.genre,meta.bpm,meta.key,meta.duration,key,meta.creator.toLowerCase())
 ]);}catch(e){await bucket().delete(key);throw e;}
 return json({ok:true,id:trackId},201);
 }
 const a=actions.parse(await req.json());
 if('playlistId' in a || ['renamePlaylist','deletePlaylist'].includes(a.action)){
 const pid='playlistId' in a?a.playlistId:('id' in a?a.id:'');
 if(!await db.prepare('SELECT id FROM playlists WHERE id=? AND user_id=?').bind(pid,'owner').first())return json({error:'Playlist not found.'},404);
 }
 if('trackId' in a && !await db.prepare('SELECT id FROM tracks WHERE id=?').bind(a.trackId).first())return json({error:'Track not found.'},404);
 if('userId' in a && !await db.prepare('SELECT id FROM users WHERE id=?').bind(a.userId).first())return json({error:'Listener not found.'},404);
 switch(a.action){
 case 'createPlaylist':{const pid=crypto.randomUUID();await db.prepare('INSERT INTO playlists (id,user_id,name,description) VALUES (?,?,?,?)').bind(pid,'owner',a.name,a.description).run();return json({ok:true,id:pid},201);}
 case 'renamePlaylist':await db.prepare('UPDATE playlists SET name=?,description=? WHERE id=?').bind(a.name,a.description,a.id).run();break;
 case 'deletePlaylist':await db.prepare('DELETE FROM playlists WHERE id=?').bind(a.id).run();break;
 case 'addTrack':await db.batch([db.prepare('INSERT OR IGNORE INTO playlist_tracks (playlist_id,track_id,position) SELECT ?,?,COALESCE(MAX(position),-1)+1 FROM playlist_tracks WHERE playlist_id=?').bind(a.playlistId,a.trackId,a.playlistId),db.prepare('UPDATE playlists SET revision=revision+1 WHERE id=?').bind(a.playlistId)]);break;
 case 'removeTrack':await db.batch([db.prepare('DELETE FROM playlist_tracks WHERE playlist_id=? AND track_id=?').bind(a.playlistId,a.trackId),db.prepare('UPDATE playlists SET revision=revision+1 WHERE id=?').bind(a.playlistId)]);break;
 case 'reorder':{
 const rows=(await db.prepare('SELECT track_id FROM playlist_tracks WHERE playlist_id=?').bind(a.playlistId).all<{track_id:string}>()).results;
 if(new Set(a.trackIds).size!==a.trackIds.length||rows.length!==a.trackIds.length||rows.some(r=>!a.trackIds.includes(r.track_id)))return json({error:'Playlist changed. Refresh and try again.'},409);
 // Compare-and-swap revision and updates run inside one D1 batch transaction.
 const rs=await db.batch([...a.trackIds.map((t,i)=>db.prepare('UPDATE playlist_tracks SET position=? WHERE playlist_id=? AND track_id=? AND (SELECT revision FROM playlists WHERE id=?)=?').bind(i,a.playlistId,t,a.playlistId,a.revision)),db.prepare('UPDATE playlists SET revision=revision+1 WHERE id=? AND revision=?').bind(a.playlistId,a.revision)]);
 if(!rs[rs.length-1].meta.changes)return json({error:'Playlist changed. Refresh and try again.'},409);break;
 }
 case 'favorite':if(a.liked)await db.prepare('INSERT OR IGNORE INTO favorites (user_id,track_id) VALUES (?,?)').bind(a.userId,a.trackId).run();else await db.prepare('DELETE FROM favorites WHERE user_id=? AND track_id=?').bind(a.userId,a.trackId).run();break;
 case 'listen':if(await db.prepare('SELECT spotify_id FROM tracks WHERE id=?').bind(a.trackId).first<{spotify_id:string|null}>().then(t=>!!t?.spotify_id))return json({error:'Spotify playback is controlled by Spotify and is not counted as a local play.'},400);await db.prepare('INSERT OR IGNORE INTO listens (id,user_id,track_id,seconds) SELECT ?,?,?,MIN(?,duration) FROM tracks WHERE id=?').bind(a.eventId,a.userId,a.trackId,a.seconds,a.trackId).run();break;
 case 'createUser':{const uid=crypto.randomUUID();await db.prepare('INSERT INTO users (id,name) VALUES (?,?)').bind(uid,a.name).run();return json({ok:true,id:uid},201);}
 }
 return json({ok:true});
 }catch(e){if(e instanceof SyntaxError)return json({error:'Invalid JSON request.'},400);if(e instanceof z.ZodError)return json({error:e.issues[0]?.message??'Invalid input.'},400);console.error(e);return json({error:'Could not save. Your input has been preserved; try again.'},503);}
}
