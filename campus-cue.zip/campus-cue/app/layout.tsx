import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Campus Cue | DJ library",
  description: "Campus DJ audio library, set playlists, and listener preferences.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
