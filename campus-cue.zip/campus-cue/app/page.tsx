'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Tabs, TabsContent } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Toaster, toast } from 'sonner';
import type { Library, Track, Playlist } from '@/lib/types';
import { request } from '@/lib/library-api';
import { usePlaylistTool } from '@/components/workspace/use-playlist-tool';
import { usePlayback } from '@/components/workspace/use-playback';
import { TopBar, Heading, Navigation } from '@/components/workspace/frame';
import { AddToSet, DeleteSet } from '@/components/workspace/set-dialogs';
import { uploadAudio } from '@/lib/upload-audio';
import DJWorkspace from '@/components/dj/workspace';
import LibraryBrowser, { defaultFilters, type LibraryFilters } from '@/components/library/browser';
import TrackTable from '@/components/library/track-table';
import Insights from '@/components/workspace/insights';
import Sets from '@/components/workspace/sets';
import Player from '@/components/workspace/player';
import CreateDialog from '@/components/workspace/create-dialog';
import PrepDialog from '@/components/dj/prep-dialog';
export default function Page() {
  const [data, setData] = useState<Library | null>(null),
    [error, setError] = useState(''),
    [tab, setTab] = useState('library'),
    [user, setUser] = useState('owner'),
    [selected, setSelected] = useState(''),
    [modal, setModal] = useState<'upload' | 'playlist' | 'listener' | null>(null),
    [editing, setEditing] = useState<Playlist | null>(null),
    [deleting, setDeleting] = useState<Playlist | null>(null),
    [busy, setBusy] = useState(false),
    [formError, setFormError] = useState(''),
    [addTo, setAddTo] = useState<{
      track: Track;
    } | null>(null),
    [target, setTarget] = useState('');
  const [quickPrep, setQuickPrep] = useState<Track | null>(null);
  const [filters, setFilters] = useState<LibraryFilters>(defaultFilters);
  const operation = useRef(false),
    pendingTrack = useRef<Track | null>(null);
  const loadSequence = useRef(0);
  const load = useCallback(async () => {
    const sequence = ++loadSequence.current;
    const r = await fetch('/api/library', {
      cache: 'no-store'
    });
    const d = (await r.json()) as Library & {
      error?: string;
    };
    if (!r.ok) throw new Error(d.error || 'Could not load library.');
    if (sequence === loadSequence.current) {
      setData(d);
      setError('');
    }
    return d;
  }, []);
  const playback = usePlayback(user, load);
  const {
    current,
    playing,
    start
  } = playback;
  useEffect(() => {
    load().catch(e => setError(e.message));
  }, [load]);
  useEffect(() => {
    const shortcut = (event: KeyboardEvent) => {
      const element = event.target as HTMLElement;
      if (modal || addTo || deleting || element.closest('[role="dialog"], [role="alertdialog"]')) return;
      const command = (event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k';
      const typing = element.matches('input, textarea, select') || element.isContentEditable;
      if (!command && (typing || event.key !== '/' || event.metaKey || event.ctrlKey || event.altKey)) return;
      event.preventDefault();
      setTab('library');
      requestAnimationFrame(() => document.getElementById('library-search')?.focus());
    };
    window.addEventListener('keydown', shortcut);
    return () => window.removeEventListener('keydown', shortcut);
  }, [modal, addTo, deleting]);
  const act = useCallback(async (body: unknown) => {
    if (operation.current) throw new Error('Wait for the current change to finish.');
    operation.current = true;
    setBusy(true);
    try {
      const result = await request(body);
      await load().catch(() => toast.error('Change saved, but the library could not refresh. Reload to see it.'));
      return result;
    } catch (e) {
      toast.error((e as Error).message);
      throw e;
    } finally {
      operation.current = false;
      setBusy(false);
    }
  }, [load]);
  const openSet = useCallback((id: string) => {
    setSelected(id);
    setTab('sets');
  }, []);
  usePlaylistTool(act, openSet);
  const likedIds = useMemo(() => new Set(data?.favorites.filter(f => f.user_id === user).map(f => f.track_id)), [data?.favorites, user]);
  const liked = useCallback((id: string) => likedIds.has(id), [likedIds]);
  const favorite = (t: Track) => void act({
    action: 'favorite',
    userId: user,
    trackId: t.id,
    liked: !liked(t.id)
  }).catch(() => {});
  const openModal = (m: typeof modal) => {
    setFormError('');
    setEditing(null);
    setModal(m);
  };
  const selectedPlaylist = data?.playlists.find(p => p.id === selected) ?? data?.playlists[0];
  const setTracks = data?.items.filter(i => i.playlist_id === selectedPlaylist?.id).map(i => data.tracks.find(t => t.id === i.track_id)).filter((t): t is Track => !!t) ?? [];
  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (operation.current) return;
    operation.current = true;
    setFormError('');
    const form = e.currentTarget;
    const f = new FormData(form);
    setBusy(true);
    try {
      if (modal === 'upload') {
        if (!f.get('key')) throw new Error('Choose the musical key from your DJ software.');
        await uploadAudio(f);
        await load().catch(() => toast.error('Upload saved. Reload to refresh your library.'));
        toast.success('Track added to your library.');
      } else if (modal === 'playlist') {
        const r = await request({
          action: editing ? 'renamePlaylist' : 'createPlaylist',
          id: editing?.id,
          name: f.get('name'),
          description: f.get('description')
        });
        if (!editing && pendingTrack.current) {
          const track = pendingTrack.current;
          pendingTrack.current = null;
          await request({
            action: 'addTrack',
            playlistId: r.id,
            trackId: track.id
          }).catch(() => toast.error('Set created. Add the track again from your library.'));
        }
        await load().catch(() => toast.error('Set saved. Reload to refresh your library.'));
        setSelected(editing?.id ?? r.id);
        setTab('sets');
        toast.success(editing ? 'Set updated.' : 'Set created.');
      } else {
        const r = await request({
          action: 'createUser',
          name: f.get('name')
        });
        await load().catch(() => toast.error('Profile saved. Reload to refresh your library.'));
        setUser(r.id);
        toast.success('Listener profile added.');
      }
      setModal(null);
    } catch (e) {
      setFormError((e as Error).message);
    } finally {
      operation.current = false;
      setBusy(false);
    }
  };
  const move = (i: number, delta: number) => {
    const ids = setTracks.map(t => t.id);
    [ids[i], ids[i + delta]] = [ids[i + delta], ids[i]];
    void act({
      action: 'reorder',
      playlistId: selectedPlaylist!.id,
      revision: selectedPlaylist!.revision,
      trackIds: ids
    }).catch(() => {
      load().catch(() => {});
    });
  };
  const addTrack = (track: Track) => {
    setTarget(data?.playlists[0]?.id ?? '');
    setAddTo({
      track
    });
  };
  const trackTable = (tracks: Track[], inSet = false) => <TrackTable tracks={tracks} inSet={inSet} current={current} playing={playing} busy={busy} liked={liked} favorite={favorite} start={start} browseArtist={artist => {
    setFilters({
      ...defaultFilters,
      query: artist,
      scope: 'artist'
    });
    setTab('library');
  }} move={move} remove={track => void act({
    action: 'removeTrack',
    playlistId: selectedPlaylist!.id,
    trackId: track.id
  }).catch(() => {})} add={addTrack} prepare={setQuickPrep} />;
  return <div className="app-shell">
<Toaster theme="dark" position="top-right" />
<TopBar />
<div className="page-wrap">
<Heading data={data} busy={busy} upload={() => openModal('upload')} />
 <Tabs value={tab} onValueChange={setTab}>
<Navigation data={data} busy={busy} user={user} onListener={async value => {
          await playback.stop();
          setUser(value);
        }} addListener={() => openModal('listener')} />
 {error ? <div className="error-state" role="alert">
<h2>Library unavailable</h2>
<p>{error}</p>
<button className="secondary" onClick={() => load().catch(e => setError(e.message))}>Retry</button>
</div> : !data ? <div className="loading-state" aria-label="Loading library">{[1, 2, 3, 4].map(i => <Skeleton key={i} className="h-16 w-full bg-white/5" />)}</div> : <>
 <TabsContent value="dj">
<DJWorkspace onChange={load} library={data} start={t => void start(t, data.tracks)} add={t => {
              setTarget(data.playlists[0]?.id ?? '');
              setAddTo({
                track: t
              });
            }} reorder={async (playlistId, revision, trackIds) => {
              await act({
                action: 'reorder',
                playlistId,
                revision,
                trackIds
              });
            }} />
</TabsContent>
 <TabsContent value="library">
<LibraryBrowser library={data} filters={filters} onChange={setFilters} isLiked={liked} renderTracks={trackTable} openSet={id => {
              setSelected(id);
              setTab('sets');
            }} createSet={() => openModal('playlist')} />
</TabsContent>
 <TabsContent value="sets">
<Sets data={data} selectedPlaylist={selectedPlaylist} setTracks={setTracks} create={() => openModal('playlist')} select={setSelected} start={start} edit={set => {
              setEditing(set);
              setFormError('');
              setModal('playlist');
            }} remove={setDeleting} browse={() => setTab('library')} trackTable={trackTable} />
</TabsContent>
 <TabsContent value="analytics">
<Insights data={data} add={addTrack} />
</TabsContent>
</>}
 </Tabs>
<footer className="page-footer">
<span>campuscue <span> / </span> MADE FOR THE NEXT SET</span>
<span>Georgia Tech campus DJ workspace</span>
</footer>
</div>
 <Player {...playback} liked={liked} busy={busy} favorite={favorite} />
 <audio {...playback.audioProps} />
 <PrepDialog track={quickPrep} close={() => setQuickPrep(null)} refresh={load} />
 <CreateDialog modal={modal} setModal={() => {
      pendingTrack.current = null;
      setModal(null);
    }} busy={busy} editing={editing} formError={formError} submit={submit} />
 <AddToSet track={addTo?.track ?? null} data={data} target={target} setTarget={setTarget} busy={busy} close={() => setAddTo(null)} add={() => void act({
      action: 'addTrack',
      playlistId: target,
      trackId: addTo?.track.id
    }).then(() => {
      setAddTo(null);
      toast.success('Track added to set.');
    }).catch(() => {})} create={() => {
      pendingTrack.current = addTo?.track ?? null;
      setAddTo(null);
      openModal('playlist');
    }} />
 <DeleteSet playlist={deleting} busy={busy} close={() => setDeleting(null)} remove={() => void act({
      action: 'deletePlaylist',
      id: deleting?.id
    }).then(() => {
      setDeleting(null);
      setSelected('');
      toast.success('Set deleted.');
    }).catch(() => {})} />
 </div>;
}
