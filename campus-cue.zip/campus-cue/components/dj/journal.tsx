'use client';

import { useState } from 'react';
import { History, Trash2 } from 'lucide-react';
import TrackPicker from '@/components/library/track-picker';
import { parseHistory, type HistoryEntry } from '@/lib/dj-history';
import { techniques, type DJData } from '@/lib/dj-model';
import type { Track } from '@/lib/types';
type Props = {
  tracks: Track[];
  data: DJData;
  total: number;
  busy: boolean;
  from: string;
  to: string;
  setFrom: (id: string) => void;
  setTo: (id: string) => void;
  record: (entries: HistoryEntry[]) => Promise<boolean>;
  save: (body: unknown) => Promise<boolean>;
};
export default function Journal({
  tracks,
  data,
  total,
  busy,
  from,
  to,
  setFrom,
  setTo,
  record,
  save
}: Props) {
  const [imports, setImports] = useState(''),
    [historyLimit, setHistoryLimit] = useState(20),
    [rating, setRating] = useState(''),
    [error, setError] = useState('');
  const importHistory = async () => {
    try {
      setError('');
      if (await record(parseHistory(imports, tracks))) setImports('');
    } catch (error) {
      setError((error as Error).message);
    }
  };
  return <section className="dj-card" id="transition-journal">
<h3>
<History size={19} /> Transition journal</h3>
<p className="muted">Record a transition you actually tried. Rate each direction separately. 1 = poor, 3 = workable, 5 = excellent.</p>
<form onSubmit={async e => {
      e.preventDefault();
      const form = e.currentTarget;
      const f = new FormData(form);
      setError('');
      if (await record([{
        fromId: from,
        toId: to,
        rating: Number(f.get('rating')),
        technique: String(f.get('technique')),
        notes: String(f.get('notes') ?? '')
      }])) {
        form.reset();
        setRating('');
      }
    }}>
<div className="dj-form-grid journal-fields">
<TrackPicker label="From" tracks={tracks} value={from} onChange={setFrom} />
<TrackPicker label="Into" tracks={tracks} value={to} onChange={setTo} />
<fieldset className="rating-input">
<legend>How did the mix sound?</legend>
<input type="hidden" name="rating" value={rating} />
<div className="rating-buttons">{['Poor', 'Rough', 'Okay', 'Good', 'Great'].map((label, i) => <button type="button" key={label} aria-pressed={rating === String(i + 1)} onClick={() => setRating(String(i + 1))}>
<strong>{i + 1}</strong>
<span>{label}</span>
</button>)}</div>
</fieldset>
<label>Technique<select name="technique">{techniques.map(t => <option key={t}>{t}</option>)}</select>
</label>
</div>
<label>Notes · optional<textarea name="notes" maxLength={500} placeholder="Phrase timing, vocal overlap, crowd response, and how you mixed it." />
</label>{from === to && <p className="muted">Choose a different song for “Into”.</p>}<button className="primary" disabled={busy || !rating || from === to || !from || !to}>Record transition</button>
</form>
 {error && <p className="form-error" role="alert">{error}</p>}<details className="dj-import">
<summary>Import past transitions</summary>
<p>One row per mix: From title | To title | Rating 1–5 | Technique | Note. Accents and punctuation are flexible. Use Title — Artist to distinguish songs with the same title. Technique and note are optional.</p>
<p>Techniques: {techniques.join(', ')}. Rate what you heard; a tracklist alone cannot establish mix quality.</p>
<textarea aria-label="Past transition rows" value={imports} onChange={e => setImports(e.target.value)} placeholder="From title | To title | Rating | Technique | Note" rows={5} />
<button className="secondary" disabled={busy || !imports.trim()} onClick={() => void importHistory()}>Import rated transitions</button>
</details>
 <div className="dj-history">{data.transitions.slice(0, historyLimit).map(t => <div className="dj-history-row" key={t.id}>
<span className="rating-chip">{t.rating}/5</span>
<div>
<strong>{tracks.find(s => s.id === t.from_id)?.title ?? 'Unavailable'} → {tracks.find(s => s.id === t.to_id)?.title ?? 'Unavailable'}</strong>
<small>{t.technique} · {t.created_at.slice(0, 10)}</small>{t.notes && <p>{t.notes}</p>}</div>
<button className="icon-button" disabled={busy} aria-label="Delete this transition rating" onClick={() => void save({
          action: 'delete',
          id: t.id
        })}>
<Trash2 size={16} />
</button>
</div>)}{!data.transitions.length && <p className="empty-small">No transition history yet. Your first recorded mix starts the journal.</p>}</div>{data.transitions.length > historyLimit && <button className="secondary" onClick={() => setHistoryLimit(value => value + 20)}>Show more history</button>}{data.transitions.length > 0 && <p className="muted history-count">Showing {Math.min(historyLimit, data.transitions.length)} of {data.transitions.length} loaded ratings{total > 500 ? ` · ${total} saved; latest 500 available here` : ''}.</p>}</section>;
}
