export default function Method() {
  return <details className="dj-card dj-method">
<summary>How recommendations work</summary>
<p>Metadata rules compare tempo, Camelot key, genre, and your energy ratings. Tempo compares normal, half, and double time. Once enough varied ratings exist, regularized logistic regression learns weights from your frozen metadata at recording time. Exact directed-pair ratings also adjust ranking. Optional groove and section vocals add small, fixed ranking adjustments; phrase length informs the transition plan. These rhythm rules are separate from learned weights. Unknown fields remain unknown. The score is a ranking aid, not a probability that a mix will sound good.</p>
<p>History contains only transitions you enter. No famous DJ sets or commercial recordings are used to train this model. Spotify audio is not analyzed. Tap tempo is a manual estimate; groove and vocal details come from your prep. Timing, edits, and crowd response still need your judgment. Technique and notes are saved for reference; the model does not analyze them.</p>
<p>Harmonic rules: <a href="https://mixedinkey.com/harmonic-mixing-guide/" target="_blank" rel="noopener noreferrer">Mixed In Key’s official guide</a>.</p>
</details>;
}
