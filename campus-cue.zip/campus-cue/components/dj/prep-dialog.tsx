'use client';

import { useEffect, useRef, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import type { Track } from '@/lib/types';
import type { DJData } from '@/lib/dj-model';
import { toast } from 'sonner';
import PrepEditor from './prep-editor';
export default function PrepDialog({
  track,
  close,
  refresh
}: {
  track: Track | null;
  close: () => void;
  refresh: () => Promise<unknown>;
}) {
  const saving = useRef(false);
  const [data, setData] = useState<DJData | null>(null),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!track) return;
    const abort = new AbortController();
    setData(null);
    setError('');
    fetch('/api/dj', {
      cache: 'no-store',
      signal: abort.signal
    }).then(async response => {
      const data = (await response.json()) as DJData & {
        error?: string;
      };
      if (!response.ok) throw new Error(data.error || 'Could not load track info.');
      setData(data);
    }).catch(error => {
      if (!abort.signal.aborted) setError(error.message);
    });
    return () => abort.abort();
  }, [track?.id]);
  return <Dialog open={!!track} onOpenChange={open => {
    if (!open && !busy) close();
  }}>
<DialogContent>
    <DialogHeader>
<DialogTitle>{track?.title}</DialogTitle>
<DialogDescription>{track?.creator} · Track info</DialogDescription>
</DialogHeader>
    {error && <p className="form-error" role="alert">{error}</p>}
    {!data && !error && <p role="status">Loading track info…</p>}
    {track && data && <PrepEditor key={track.id} track={track} prep={data.prep} busy={busy} save={async body => {
        if (saving.current) return false;
        saving.current = true;
        setBusy(true);
        setError('');
        try {
          const response = await fetch('/api/dj', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(body)
          });
          const result = (await response.json()) as {
            error?: string;
          };
          if (!response.ok) throw new Error(result.error || 'Could not save track info.');
          try {
            await refresh();
            toast.success('Track info saved.');
            close();
          } catch {
            toast.error('Track info saved. Reload to refresh your library.');
            close();
          }
          return true;
        } catch (error) {
          setError((error as Error).message);
          return false;
        } finally {
          saving.current = false;
          setBusy(false);
        }
      }} />}
  </DialogContent>
</Dialog>;
}
