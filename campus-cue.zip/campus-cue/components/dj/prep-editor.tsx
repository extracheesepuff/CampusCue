'use client';

import RhythmFields from './rhythm-fields';
import { useState } from 'react';
import { metadata, camelotKeys, type Prep } from '@/lib/dj-model';
import { formatCue, prepRequest } from '@/lib/prep-form';
import type { Track } from '@/lib/types';
type Props = {
  track: Track;
  prep: Prep[];
  busy: boolean;
  save: (body: unknown) => Promise<boolean>;
};
export default function PrepEditor({
  track,
  prep,
  busy,
  save
}: Props) {
  const details = metadata(track, prep);
  const [energy, setEnergy] = useState(details.energy == null ? '' : String(details.energy));
  const [bpm, setBpm] = useState(details.bpm == null ? '' : String(details.bpm));
  const [error, setError] = useState('');
  return <form className="prep-editor" onSubmit={async event => {
    event.preventDefault();
    setError('');
    try {
      await save(prepRequest(new FormData(event.currentTarget), track, details.prep));
    } catch (error) {
      setError((error as Error).message);
    }
  }}>
    <p className="muted">All fields are optional. Enter only what you know.</p>
    <div className="form-grid">
      <label>BPM<input name="bpm" type="number" inputMode="decimal" min="40" max="240" step=".01" value={bpm} onChange={event => setBpm(event.target.value)} placeholder="e.g. 124" />
</label>
      <label>Musical key<select name="key" defaultValue={details.key ?? ''}>
<option value="">Unknown</option>{camelotKeys.map(key => <option key={key}>{key}</option>)}</select>
<small>Camelot code from your DJ software.</small>
</label>
    </div>
    <fieldset className="energy-input">
<legend>Energy <span>{energy ? `${energy}/10` : 'Unrated'}</span>
</legend>
      <input type="hidden" name="energy" value={energy} />
      <div className="energy-presets">{[{
          name: 'Chill',
          value: 3
        }, {
          name: 'Steady',
          value: 6
        }, {
          name: 'Peak',
          value: 9
        }].map(item => <button type="button" key={item.value} aria-pressed={Number(energy) === item.value} onClick={() => setEnergy(String(item.value))}>{item.name} · {item.value}</button>)}<button type="button" onClick={() => setEnergy('')}>Clear</button>
</div>
      {energy && <input type="range" aria-label="Adjust track energy from 1 to 10" min="1" max="10" value={energy} onChange={event => setEnergy(event.target.value)} />}
    </fieldset>
    <RhythmFields saved={details.prep} applyBpm={value => setBpm(String(value))} />
    <label>Notes<textarea name="notes" maxLength={1000} rows={3} defaultValue={details.prep?.notes ?? ''} placeholder="Version, clean intro, vocal entry, or useful loop…" />
</label>
    <details className="cue-details" open={details.prep?.cue_in != null || details.prep?.cue_out != null}>
      <summary>Mix-in and mix-out cues <span>Optional</span>
</summary>
      <p className="muted">Enter seconds or m:ss. Cues are planning notes and do not control Spotify.</p>
      <div className="form-grid">
<label>Mix-in<input name="cueIn" defaultValue={formatCue(details.prep?.cue_in)} placeholder="32 or 0:32" />
</label>
<label>Mix-out<input name="cueOut" defaultValue={formatCue(details.prep?.cue_out)} placeholder="180 or 3:00" />
</label>
</div>
    </details>
    {error && <p className="form-error" role="alert">{error}</p>}
    <button className="primary" disabled={busy}>{busy ? 'Saving…' : 'Save track info'}</button>
  </form>;
}
