'use client';

import { useState } from 'react';
import { grooves, vocalLevels, tappedBpm, type Rhythm } from '@/lib/rhythm';
export default function RhythmFields({
  saved,
  applyBpm
}: {
  saved?: Rhythm;
  applyBpm: (bpm: number) => void;
}) {
  const [taps, setTaps] = useState<number[]>([]);
  const bpm = tappedBpm(taps);
  return <details className="cue-details">
    <summary>Rhythm & mix sections <span>Optional</span>
</summary>
    <p className="muted">Listen to your chosen mix-in and mix-out sections. Clear means no lead vocal in that section.</p>
    <div className="form-grid">
      <label>Drum groove<select name="groove" defaultValue={saved?.groove ?? ''}>
<option value="">Unknown</option>{grooves.map(value => <option key={value}>{value}</option>)}</select>
</label>
      <label>Phrase length<select name="phraseBars" defaultValue={saved?.phrase_bars ?? ''}>
<option value="">Unknown</option>{[8, 16, 32].map(value => <option key={value} value={value}>{value} bars</option>)}</select>
<small>Use for tracks in 4/4 time; check the phrase by ear.</small>
</label>
      <label>Mix-in vocals<select name="introVocals" defaultValue={saved?.intro_vocals ?? ''}>
<option value="">Unknown</option>{vocalLevels.map(value => <option key={value}>{value}</option>)}</select>
</label>
      <label>Mix-out vocals<select name="outroVocals" defaultValue={saved?.outro_vocals ?? ''}>
<option value="">Unknown</option>{vocalLevels.map(value => <option key={value}>{value}</option>)}</select>
</label>
    </div>
    <div className="tap-tempo">
      <button type="button" className="secondary" onClick={() => {
        const now = performance.now();
        setTaps(previous => !previous.length || now - previous[previous.length - 1] > 2000 ? [now] : [...previous, now].slice(-9));
      }}>Tap the beat</button>
      <span role="status">{bpm ? `${bpm} BPM · tapped estimate` : 'Tap at least 4 beats'}</span>
      {bpm && <button type="button" className="text-button" onClick={() => applyBpm(bpm)}>Use BPM</button>}
      {!!taps.length && <button type="button" className="text-button" onClick={() => setTaps([])}>Reset</button>}
    </div>
    <small className="muted">Tap once per beat. Confirm by ear; half-time tapping gives half the tempo.</small>
  </details>;
}
