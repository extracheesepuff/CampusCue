'use client';

import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { Download, Check, SlidersHorizontal } from 'lucide-react';
import { optimize, evaluate, metadata, train, type DJData } from '@/lib/dj-model';
import { formatCue as clock } from '@/lib/prep-form';
import type { Track, Playlist } from '@/lib/types';
type Props = {
  members: Track[];
  selected?: Playlist;
  data: DJData;
  model: ReturnType<typeof train>;
  goal: string;
  busy: boolean;
  prepare: (track: Track) => void;
  reorder: (id: string, revision: number, ids: string[]) => Promise<void>;
};
export default function SetPlanner({
  members,
  selected,
  data,
  model,
  goal,
  busy,
  prepare,
  reorder
}: Props) {
  const [draft, setDraft] = useState<Track[] | null>(null),
    [draftRevision, setDraftRevision] = useState<number | null>(null),
    [applying, setApplying] = useState(false);
  useEffect(() => setDraft(null), [members, data.prep, data.transitions, goal, selected?.revision]);
  const exportSet = () => {
    const tracks = draft ?? members;
    const lines = ['# Campus Cue set sheet', `# ${selected?.name ?? 'Music library'}`, ...tracks.map((t, i) => {
      const m = metadata(t, data.prep);
      return `${i + 1}. ${t.title} — ${t.creator}\n   BPM ${m.bpm ?? 'unknown'} | Key ${m.key ?? 'unknown'} | Energy ${m.energy ?? 'unrated'} | In ${clock(m.prep?.cue_in) || 'unset'} | Out ${clock(m.prep?.cue_out) || 'unset'}\n   ${m.prep?.notes ?? ''}`;
    })];
    const url = URL.createObjectURL(new Blob([lines.join('\n\n')], {
      type: 'text/plain'
    }));
    const a = document.createElement('a');
    a.href = url;
    a.download = 'campus-cue-set-sheet.txt';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  return <section className="dj-card">
<h3>Set order</h3>
<p className="muted">Choose a saved set above. Its first track stays pinned. Review the proposal before saving.</p>
<div className="dj-actions">
<button className="primary" disabled={busy || applying || !selected || members.length < 3 || members.length > 50} onClick={() => {
        if (!selected) return;
        const result = optimize(members, data, goal, model);
        if (result.every((t, i) => t.id === members[i].id)) {
          toast.info('No better order found. Current order kept.');
          setDraft(null);
          return;
        }
        setDraft(result);
        setDraftRevision(selected.revision);
      }}>Suggest order</button>
<button className="secondary" disabled={!members.length} onClick={exportSet}>
<Download size={16} /> Set sheet</button>
</div>{members.length > 50 && <p className="muted">Order suggestions support sets of up to 50 tracks.</p>}
 {selected && <div className="dj-energy-profile">
<span>Energy shape · your ratings</span>
<div className="dj-energy-bars" role="img" aria-label={(draft ?? members).map((t, i) => `${i + 1}. ${t.title}: energy ${metadata(t, data.prep).energy ?? 'unrated'}`).join('; ')}>{(draft ?? members).map((t, i) => {
          const energy = metadata(t, data.prep).energy;
          return <div key={t.id} title={`${t.title}: ${energy ?? 'unrated'}`}>
<span>{energy ?? '—'}</span>
<div className={`dj-energy-bar ${energy === null ? 'unknown' : ''}`} style={{
              height: energy === null ? 12 : energy * 8
            }} />
<small>{i + 1}</small>
</div>;
        })}</div>
</div>}
 {(draft ?? (selected ? members : [])).map((t, i, arr) => {
      const m = metadata(t, data.prep),
        fit = i ? evaluate(arr[i - 1], t, data, model, goal) : null;
      return <div className="dj-set-track" key={t.id}>
<span className="mono">{String(i + 1).padStart(2, '0')}</span>
<div>
<strong>{t.title}</strong>
<small>{m.bpm ?? '—'} BPM · {m.key ?? 'Key unknown'} · Energy {m.energy ?? '—'}{fit?.score != null ? ` · Fit ${fit.score}/100` : ''}</small>
<small>{clock(m.prep?.cue_in) ? `In ${clock(m.prep?.cue_in)}` : 'Mix-in unset'} · {clock(m.prep?.cue_out) ? `Out ${clock(m.prep?.cue_out)}` : 'Mix-out unset'}</small>{m.prep?.notes && <p>{m.prep.notes}</p>}</div>
<button className="icon-button" aria-label={`Prepare ${t.title}`} onClick={() => prepare(t)}>
<SlidersHorizontal size={16} />
</button>
</div>;
    })}
 {!selected && <div className="empty-small">Select a set in “Choose from” to plan its sequence.</div>}{draft && <div className="dj-actions">
<button className="primary" disabled={busy || applying || draftRevision !== selected?.revision} onClick={async () => {
        if (!selected || draftRevision === null) return;
        setApplying(true);
        try {
          await reorder(selected.id, draftRevision, draft.map(t => t.id));
          setDraft(null);
          toast.success('Set order saved.');
        } catch (e) {
          toast.error((e as Error).message);
          setDraft(null);
        } finally {
          setApplying(false);
        }
      }}>
<Check size={16} /> Apply order</button>
<button className="secondary" onClick={() => setDraft(null)}>Discard proposal</button>{draftRevision !== selected?.revision && <p role="alert">Set changed. Generate a fresh proposal.</p>}</div>}</section>;
}
