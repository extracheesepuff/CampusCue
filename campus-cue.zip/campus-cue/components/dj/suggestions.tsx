'use client';

import { BrainCircuit, Headphones, Plus, SlidersHorizontal, History } from 'lucide-react';
import type { Track } from '@/lib/types';
import type { evaluate } from '@/lib/dj-model';
export default function Suggestions({
  anchor,
  suggestions,
  start,
  prepare,
  log,
  add
}: {
  anchor?: Track;
  suggestions: ReturnType<typeof evaluate>[];
  start: (track: Track) => void;
  prepare: (track: Track) => void;
  log: (track: Track) => void;
  add: (track: Track) => void;
}) {
  return <section className="dj-card dj-suggestions">
<div className="dj-section-title">
<h3>
<BrainCircuit size={19} /> Next up</h3>{anchor && <button className="text-button" onClick={() => prepare(anchor)}>
<SlidersHorizontal size={16} /> Prep current track</button>}</div>
<p className="muted">{anchor?.title} to your next pick. Audition every transition; scores do not measure seamlessness.</p>{!suggestions.length ? <p className="empty-small">Add another track to this pool.</p> : suggestions.map(s => <div className="dj-suggestion" key={s.track.id}>
<div className="dj-score">{s.score === null ? '—' : s.score}<small>{s.score === null ? 'NO DATA' : 'FIT / 100'}</small>
</div>
<div className="dj-suggestion-body">
<strong>{s.track.title}</strong>
<span>{s.track.creator}</span>
<div className="dj-reasons">{s.reasons.map(r => <span key={r}>{r}</span>)}</div>
<p className="mix-plan">{s.plan}</p>
<div className="dj-actions">
<button className="text-button" onClick={() => start(s.track)}>
<Headphones size={15} /> Audition</button>
<button className="text-button" onClick={() => prepare(s.track)}>
<SlidersHorizontal size={15} /> Prep</button>
<button className="text-button" onClick={() => {
            log(s.track);
          }}>
<History size={15} /> Log this mix</button>
<button className="icon-button" aria-label={`Add ${s.track.title} to a set`} onClick={() => add(s.track)}>
<Plus size={17} />
</button>
</div>
</div>
</div>)}</section>;
}
