'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import type { DJData } from '@/lib/dj-model';
import type { HistoryEntry } from '@/lib/dj-history';
const empty: DJData = {
  prep: [],
  transitions: []
};
async function send(body: unknown) {
  const r = await fetch('/api/dj', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  const d = (await r.json()) as {
    error?: string;
  };
  if (!r.ok) throw new Error(d.error || 'Could not save.');
}
export function useDJData(onChange: () => Promise<unknown>) {
  const [data, setData] = useState<DJData>(empty),
    [total, setTotal] = useState(0),
    [loaded, setLoaded] = useState(false),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  const operation = useRef(false);
  const pendingHistory = useRef<{
    signature: string;
    entries: (HistoryEntry & {
      id: string;
    })[];
  } | null>(null);
  const load = useCallback(async () => {
    const r = await fetch('/api/dj', {
        cache: 'no-store'
      }),
      d = (await r.json()) as DJData & {
        total: number;
        error?: string;
      };
    if (!r.ok) throw new Error(d.error);
    setData(d);
    setTotal(d.total);
    setLoaded(true);
    setError('');
  }, []);
  useEffect(() => {
    load().catch(e => setError(e.message));
  }, [load]);
  const save = async (body: unknown) => {
    if (operation.current) return false;
    operation.current = true;
    setBusy(true);
    try {
      await send(body);
      try {
        await Promise.all([load(), onChange()]);
        toast.success('Saved. Library and suggestions updated.');
      } catch {
        toast.error('Saved, but the view could not refresh. Reload to see the change.');
      }
      return true;
    } catch (error) {
      toast.error((error as Error).message);
      return false;
    } finally {
      operation.current = false;
      setBusy(false);
    }
  };
  // Reuse IDs after an uncertain network result so a retry cannot duplicate ratings.
  const record = async (entries: HistoryEntry[]) => {
    if (operation.current) return false;
    const signature = JSON.stringify(entries);
    if (pendingHistory.current?.signature !== signature) {
      pendingHistory.current = {
        signature,
        entries: entries.map(entry => ({
          ...entry,
          id: crypto.randomUUID()
        }))
      };
    }
    const saved = await save({
      action: 'record',
      entries: pendingHistory.current.entries
    });
    if (saved) pendingHistory.current = null;
    return saved;
  };
  return {
    data,
    total,
    loaded,
    error,
    busy,
    load,
    save,
    record,
    retry: () => load().catch(error => setError(error.message))
  };
}
