'use client';

import { useMemo, useState } from 'react';
import { BrainCircuit } from 'lucide-react';
import { train, recommend } from '@/lib/dj-model';
import type { Library, Track } from '@/lib/types';
import TrackPicker from '@/components/library/track-picker';
import PrepDialog from './prep-dialog';
import Journal from './journal';
import SetPlanner from './set-planner';
import Suggestions from './suggestions';
import Method from './method';
import { useDJData } from './use-dj-data';
type Props = {
  library: Library;
  start: (track: Track) => void;
  add: (track: Track) => void;
  reorder: (id: string, revision: number, ids: string[]) => Promise<void>;
  onChange: () => Promise<unknown>;
};
export default function DJWorkspace({
  library,
  start,
  add,
  reorder,
  onChange
}: Props) {
  const dj = useDJData(onChange);
  const [from, setFrom] = useState(library.tracks[0]?.id ?? '');
  const [to, setTo] = useState(library.tracks[1]?.id ?? '');
  const [goal, setGoal] = useState('steady'),
    [scope, setScope] = useState('all');
  const [editing, setEditing] = useState<Track | null>(null);
  const model = useMemo(() => train(dj.data.transitions), [dj.data.transitions]);
  const anchor = library.tracks.find(track => track.id === from);
  const selected = library.playlists.find(set => set.id === scope);
  const members = useMemo(() => scope === 'all' ? library.tracks : library.items.filter(item => item.playlist_id === scope).map(item => library.tracks.find(track => track.id === item.track_id)).filter((track): track is Track => !!track), [scope, library.items, library.tracks]);
  const suggestions = useMemo(() => anchor ? recommend(anchor, members, dj.data, goal, model).slice(0, 5) : [], [anchor, members, dj.data, goal, model]);
  if (dj.error) return <div className="error-state" role="alert">
<p>{dj.error}</p>
<button className="secondary" onClick={() => void dj.retry()}>Retry</button>
</div>;
  if (!dj.loaded) return <p role="status">Loading mix history…</p>;
  return <div className="dj-workspace">
    <div className="dj-heading">
<div>
<h2>Mix planner</h2>
<p>Pick your starting song, prepare track info, and log mixes you tried.</p>
</div>
<span className="model-badge">
<BrainCircuit size={18} />{model.trained ? 'Personal ML model' : 'Metadata suggestions'}</span>
</div>
    <details className="dj-learning">
<summary>{model.samples} rated mixes · {model.pairs} different pairs</summary>
<p>{model.trained ? 'Suggestions learn from your ratings. Predictive accuracy has not been measured.' : 'Personal ML starts after 8 varied ratings across 3 pairs. Until then, metadata rules guide suggestions.'}{dj.total > 500 ? ' Learning uses the latest 500 records.' : ''}</p>
</details>
    <div className="dj-control-strip">
      <TrackPicker label="Starting song" tracks={library.tracks} value={from} onChange={setFrom} />
      <label>Energy direction<select value={goal} onChange={event => setGoal(event.target.value)}>
<option value="steady">Keep it steady</option>
<option value="build">Build energy</option>
<option value="cool">Cool it down</option>
</select>
</label>
      <label>Choose from<select value={scope} onChange={event => setScope(event.target.value)}>
<option value="all">All tracks</option>{library.playlists.map(set => <option key={set.id} value={set.id}>{set.name}</option>)}</select>
</label>
    </div>
    <div className="dj-grid">
      <Suggestions anchor={anchor} suggestions={suggestions} start={start} prepare={setEditing} add={add} log={track => {
        setTo(track.id);
        document.getElementById('transition-journal')?.scrollIntoView({
          block: 'start'
        });
      }} />
      <SetPlanner key={`${scope}-${goal}`} members={members} selected={selected} data={dj.data} model={model} goal={goal} busy={dj.busy} prepare={setEditing} reorder={reorder} />
    </div>
    <Journal tracks={library.tracks} data={dj.data} total={dj.total} busy={dj.busy} from={from} to={to} setFrom={setFrom} setTo={setTo} record={dj.record} save={dj.save} />
    <PrepDialog track={editing} close={() => setEditing(null)} refresh={async () => {
      await Promise.all([dj.load(), onChange()]);
    }} />
    <Method />
  </div>;
}
