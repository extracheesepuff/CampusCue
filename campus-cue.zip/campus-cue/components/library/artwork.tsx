'use client';

import { useState } from 'react';
import { Music2 } from 'lucide-react';
import type { Track } from '@/lib/types';
export default function Artwork({
  track,
  className = ''
}: {
  track: Track;
  className?: string;
}) {
  const [failed, setFailed] = useState(false);
  return <div className={`artwork ${className}`}>{track.spotify_id && !failed ? <img src={`/api/artwork/${track.id}`} alt={`${track.title} artwork`} loading="lazy" decoding="async" width="48" height="48" onError={() => setFailed(true)} /> : <Music2 size={22} />}</div>;
}
