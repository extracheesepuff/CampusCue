'use client';
import { useDeferredValue, useEffect, useMemo, useState, type ReactNode } from 'react';
import { Search, X, Heart, Plus, ListMusic, ArrowUpRight } from 'lucide-react';
import type { SearchScope } from '@/lib/search';
import { catalogContext, collections } from '@/lib/catalog-context';
import { libraryResults, eraLabel, eraMatches, genreLabel, defaultFilters, type LibraryFilters } from '@/lib/library-view';
export { defaultFilters, type LibraryFilters } from '@/lib/library-view';
import type { Library, Track } from '@/lib/types';

type Props = {
  library: Library; filters: LibraryFilters; onChange: (filters: LibraryFilters) => void;
  isLiked: (id: string) => boolean; renderTracks: (tracks: Track[]) => ReactNode;
  openSet: (id: string) => void; createSet: () => void;
};

export default function LibraryBrowser({ library, filters, onChange, isLiked, renderTracks, openSet, createSet }: Props) {
  const [limit, setLimit] = useState(40);
  useEffect(() => setLimit(40), [filters]);
  const update = (patch: Partial<LibraryFilters>) => onChange({ ...filters, ...patch });
  const genres = useMemo(() => [...new Set(library.tracks.map(track => track.genre))].sort(), [library.tracks]);
  const searchFilters = useDeferredValue(filters);
  const results = useMemo(() => libraryResults(library.tracks, searchFilters, isLiked), [library.tracks, searchFilters, isLiked]);
  const counts = useMemo(() => Object.fromEntries(collections.map(item => [item.id,
    library.tracks.filter(track => catalogContext(track.id)?.collections.includes(item.id)).length
  ])), [library.tracks]);
  const collection = collections.find(item => item.id === filters.collection);
  const eras = ['all', ...(library.tracks.some(t => t.decade !== null && t.decade < 2000) ? ['classic'] : []), '2000', '2010', '2020'];
  const active = [
    ...(filters.query ? [{ label: `“${filters.query}”`, clear: () => update({ query: '' }) }] : []),
    ...(filters.era !== 'all' ? [{ label: eraLabel(filters.era), clear: () => update({ era: 'all' }) }] : []),
    ...(filters.genre !== 'all' ? [{ label: filters.genre, clear: () => update({ genre: 'all' }) }] : []),
    ...(filters.source !== 'all' ? [{ label: filters.source === 'spotify' ? 'Spotify' : 'Your audio', clear: () => update({ source: 'all' }) }] : []),
    ...(collection ? [{ label: collection.name, clear: () => update({ collection: 'all' }) }] : []),
    ...(filters.liked ? [{ label: 'Liked only', clear: () => update({ liked: false }) }] : [])
  ];
  return <div className="library-layout">
    <section className="library-main" aria-label="Search your music library" aria-busy={filters !== searchFilters}>
      <div className="library-search-header"><div><h2>Find a track</h2><p>Search songs, artists, party picks, or prep notes.</p></div><kbd>⌘ / Ctrl K</kbd></div>
      <div className="search-row">
        <label className="search"><Search size={20}/><input id="library-search" aria-label="Search your music library" placeholder="Try frat, rap, Mr. Brightside, or Swag Surfing" value={filters.query} onChange={event => update({ query: event.target.value })} onKeyDown={event => { if (event.key === 'Escape') update({ query: '' }); }}/>{filters.query && <button aria-label="Clear search" onClick={() => update({ query: '' })}><X size={18}/></button>}</label>
        <label className="filter-field">Search in<select value={filters.scope} onChange={event => update({ scope: event.target.value as SearchScope })}><option value="all">Everything</option><option value="title">Song titles</option><option value="artist">Artists</option></select></label>
      </div>
      <div className="collection-strip" aria-label="Browse curated selections">
        <button className={filters.collection === 'all' ? 'selected' : ''} aria-pressed={filters.collection === 'all'} onClick={() => update({ collection: 'all' })}>All tracks</button>
        {collections.map(item => <button key={item.id} className={filters.collection === item.id ? 'selected' : ''} aria-pressed={filters.collection === item.id} onClick={() => onChange({ ...defaultFilters, collection: item.id })}>{item.name}<span>{counts[item.id]}</span></button>)}
      </div>
      {collection && <p className="collection-note">{collection.description} Sources are under “Why this pick.”</p>}
      <div className="era-strip" aria-label="Filter by decade">
        {eras.map(era => <button key={era} className={`era-pill ${filters.era === era ? 'selected' : ''}`} aria-pressed={filters.era === era} onClick={() => update({ era })}>{era === 'all' ? 'Every era' : eraLabel(era)}<span>{library.tracks.filter(track => eraMatches(track, era)).length}</span></button>)}
      </div>
      <div className="library-filter-row">
        <label className="filter-field">Genre<select value={filters.genre} onChange={event => update({ genre: event.target.value })}><option value="all">All genres</option>{genres.map(genre => <option key={genre} value={genre}>{genreLabel(genre)}</option>)}</select></label>
        <label className="filter-field">Source<select value={filters.source} onChange={event => update({ source: event.target.value })}><option value="all">All sources</option><option value="spotify">Spotify songs</option><option value="upload">Your audio</option></select></label>
        <label className="filter-field">Sort by<select value={filters.sort} onChange={event => update({ sort: event.target.value })}><option value="match">Best match</option><option value="recent">Recently added</option><option value="title">Title: A–Z</option><option value="bpm">BPM: low to high</option><option value="popular">Most played / liked</option></select></label>
        <button className={`secondary like-filter ${filters.liked ? 'liked' : ''}`} aria-pressed={filters.liked} onClick={() => update({ liked: !filters.liked })}><Heart size={17}/> Liked only</button>
      </div>
      {active.length > 0 && <div className="active-filters" aria-label="Active filters">{active.map(item => <button key={item.label} onClick={item.clear} aria-label={`Remove ${item.label} filter`}>{item.label}<X size={14}/></button>)}<button className="reset-filters" onClick={() => onChange(defaultFilters)}>Reset all</button></div>}
      <div className="section-title results-title"><h2>{filters.liked ? 'Liked tracks' : 'Your collection'}</h2><span role="status" aria-live="polite">{filters !== searchFilters ? 'Searching… · ' : ''}{results.length} of {library.tracks.length} tracks</span></div>
      {results.length ? renderTracks(results.slice(0, limit)) : <div className="empty-state"><Search/><h3>No matching tracks</h3><p>Try fewer words or clear a filter. Artist and song words can be in any order.</p><button className="secondary" onClick={() => onChange(defaultFilters)}>Reset search and filters</button></div>}
      {results.length > limit && <button className="secondary show-more" onClick={() => setLimit(value => value + 40)}>Show more tracks ({results.length - limit} remaining)</button>}
      <div className="table-foot"><span>Showing {Math.min(limit, results.length)} of {results.length}</span><span>BPM and key come from your saved preparation.</span></div>
    </section>
    <aside className="rail"><div className="rail-section-title"><h3>Your sets</h3><button className="icon-button" aria-label="Create a DJ set" onClick={createSet}><Plus size={19}/></button></div>
      {library.playlists.slice(0, 6).map((playlist, i) => <button className="set-link" key={playlist.id} onClick={() => openSet(playlist.id)}><span className={`mini-set tone-${i % 4}`}><ListMusic size={20}/></span><span><strong>{playlist.name}</strong><small>{library.items.filter(item => item.playlist_id === playlist.id).length} tracks</small></span><ArrowUpRight size={17}/></button>)}
      {library.playlists.length > 6 && <button className="secondary" onClick={() => openSet('')}>View all {library.playlists.length} sets</button>}
      {!library.playlists.length && <p className="muted">Create a set, then add tracks with the + button.</p>}
      <div className="library-tip"><span className="eyebrow">READY FOR THE BOOTH</span><h3>Prep once. Find it fast.</h3><p>Save BPM, key, energy, and version notes in Mix planner. They’ll appear here and guide your next-track suggestions.</p><p>Click an artist to browse their songs. Press / to jump back to search.</p></div>
    </aside>
  </div>;
}
