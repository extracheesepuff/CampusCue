import { catalogContext } from '@/lib/catalog-context';
export default function CatalogSource({ id }: { id: string }) {
  const context = catalogContext(id);
  if (!context) return null;
  return <details className="catalog-source">
    <summary>Why this pick</summary>
    <p>{context.source.note}</p>
    <a href={context.source.url} target="_blank" rel="noopener noreferrer">{context.source.label}</a>
  </details>;
}
