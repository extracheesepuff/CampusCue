'use client';
import { useDeferredValue, useId, useMemo, useState } from 'react';
import { Search, ChevronsUpDown, Check } from 'lucide-react';
import { Dialog, DialogTrigger, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { searchTracks } from '@/lib/search';
import type { Track } from '@/lib/types';

export default function TrackPicker({ tracks, value, onChange, label }: {
  tracks: Track[]; value: string; onChange: (id: string) => void; label: string;
}) {
  const [open, setOpen] = useState(false), [query, setQuery] = useState('');
  const id = useId(), selected = tracks.find(track => track.id === value);
  const search = useDeferredValue(query);
  const results = useMemo(() => open ? searchTracks(tracks, search) : [], [open, tracks, search]);
  return <div className="track-picker">
    <span id={id} className="picker-label">{label}</span>
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><button type="button" className="track-picker-trigger" aria-labelledby={`${id} ${id}-value`} onClick={() => setQuery('')}><span id={`${id}-value`}>{selected ? `${selected.title} — ${selected.creator}` : 'Choose a track'}</span><ChevronsUpDown size={17}/></button></DialogTrigger>
      <DialogContent className="track-picker-dialog"><DialogHeader><DialogTitle>{label}</DialogTitle><DialogDescription>Find a song by title or artist.</DialogDescription></DialogHeader>
      <label className="search"><Search size={18}/><input autoFocus aria-label={`Search tracks for ${label}`} value={query} onChange={event => setQuery(event.target.value)} placeholder="Song or artist"/></label>
      <p className="muted" role="status">{results.length} tracks</p>
      <div className="picker-results">{results.map(track => <button type="button" key={track.id} className="picker-result" aria-pressed={track.id === value} onClick={() => { onChange(track.id); setOpen(false); }}><span><strong>{track.title}</strong><small>{track.creator} · {track.decade ? `${track.decade}s` : 'Your audio'}</small></span>{track.id === value && <Check size={18}/>}</button>)}{!results.length && <p className="empty-small">No matches. Try fewer words.</p>}</div>
    </DialogContent></Dialog>
  </div>;
}
