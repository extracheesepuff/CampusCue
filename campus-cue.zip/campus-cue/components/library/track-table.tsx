'use client';

import { AudioLines, Play, Heart, Plus, ChevronUp, ChevronDown, X, SlidersHorizontal } from 'lucide-react';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from '@/components/ui/table';
import type { Track } from '@/lib/types';
import Artwork from './artwork';
import CatalogSource from './catalog-source';
type Props = {
  tracks: Track[];
  inSet?: boolean;
  current: Track | null;
  playing: boolean;
  busy: boolean;
  liked: (id: string) => boolean;
  favorite: (track: Track) => void;
  start: (track: Track, list: Track[]) => Promise<void>;
  browseArtist: (artist: string) => void;
  move: (index: number, delta: number) => void;
  remove: (track: Track) => void;
  add: (track: Track) => void;
  prepare: (track: Track) => void;
};
export default function TrackTable({
  tracks,
  inSet = false,
  current,
  playing,
  busy,
  liked,
  favorite,
  start,
  browseArtist,
  move,
  remove,
  add,
  prepare
}: Props) {
  return <Table className="track-table">
<TableHeader>
<TableRow>
<TableHead className="number">#</TableHead>
<TableHead>Track / Creator</TableHead>
<TableHead className="genre-column">Genre</TableHead>
<TableHead className="era-column">Era</TableHead>
<TableHead className="key-column">Key</TableHead>
<TableHead className="duration-column">BPM</TableHead>
<TableHead>
<span className="sr-only">Actions</span>
</TableHead>
</TableRow>
</TableHeader>
<TableBody>{tracks.map((t, i) => <TableRow key={t.id} className={current?.id === t.id ? 'active-track' : ''}>
<TableCell className="number">
<button className="row-play" aria-label={`${t.spotify_id ? 'Open Spotify player for' : current?.id === t.id && playing ? 'Pause' : 'Play'} ${t.title}`} onClick={() => void start(t, tracks)}>{current?.id === t.id && playing ? <AudioLines size={18} /> : <>
<span>{String(i + 1).padStart(2, '0')}</span>
<Play size={15} />
</>}</button>
</TableCell>
<TableCell>
<div className="track-name">
<Artwork track={t} className={`track-icon tone-${i % 4}`} />
<div>
<strong>{t.title}</strong>
<button className="artist-link" onClick={() => {
                browseArtist(t.creator);
              }} aria-label={`Browse songs by ${t.creator}`}>{t.creator}</button>
<CatalogSource id={t.id} />
<small className="mobile-prep">{t.bpm ?? '—'} BPM · {t.musical_key || 'Key unknown'}</small>
</div>
</div>
</TableCell>
<TableCell className="genre-column">
<span className="genre-pill">{t.genre}</span>
</TableCell>
<TableCell className="mono era-column">{t.decade ? `${t.decade}s` : "Upload"}</TableCell>
<TableCell className="key-column">
<span className="mono">{t.musical_key || "—"}</span>
</TableCell>
<TableCell className="duration-column mono">{t.bpm ?? "—"}</TableCell>
<TableCell>
<div className="row-actions">
<button className="icon-button" aria-label={`Edit info for ${t.title}`} onClick={() => prepare(t)}>
<SlidersHorizontal size={17} />
</button>
<button className={liked(t.id) ? 'liked icon-button' : 'icon-button'} aria-label={`${liked(t.id) ? 'Unlike' : 'Like'} ${t.title}`} aria-pressed={liked(t.id)} disabled={busy} onClick={() => favorite(t)}>
<Heart size={17} fill={liked(t.id) ? 'currentColor' : 'none'} />
</button>{inSet ? <>
<button className="icon-button" disabled={busy || i === 0} aria-label={`Move ${t.title} up`} onClick={() => move(i, -1)}>
<ChevronUp size={17} />
</button>
<button className="icon-button" disabled={busy || i === tracks.length - 1} aria-label={`Move ${t.title} down`} onClick={() => move(i, 1)}>
<ChevronDown size={17} />
</button>
<button className="icon-button" disabled={busy} aria-label={`Remove ${t.title} from set`} onClick={() => remove(t)}>
<X size={17} />
</button>
</> : <button className="icon-button" disabled={busy} aria-label={`Add ${t.title} to set`} onClick={() => {
              add(t);
            }}>
<Plus size={18} />
</button>}</div>
</TableCell>
</TableRow>)}</TableBody>
</Table>;
}
