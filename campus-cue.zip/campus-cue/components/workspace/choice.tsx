'use client';

import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
export default function Choice({
  value,
  onChange,
  options,
  label
}: {
  value: string;
  onChange: (s: string) => void;
  options: {
    value: string;
    label: string;
  }[];
  label: string;
}) {
  return <Select value={value} onValueChange={onChange}>
<SelectTrigger aria-label={label} className="choice">
<SelectValue />
</SelectTrigger>
<SelectContent>{options.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}</SelectContent>
</Select>;
}
