'use client';

import { Upload } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import type { FormEvent } from 'react';
import type { Playlist } from '@/lib/types';
import { genres } from '@/lib/genres';
const keys = ['C major', 'C minor', 'C# major', 'C# minor', 'D major', 'D minor', 'D# major', 'D# minor', 'E major', 'E minor', 'F major', 'F minor', 'F# major', 'F# minor', 'G major', 'G minor', 'G# major', 'G# minor', 'A major', 'A minor', 'A# major', 'A# minor', 'B major', 'B minor'];
export default function CreateDialog({
  modal,
  setModal,
  busy,
  editing,
  formError,
  submit
}: {
  modal: 'upload' | 'playlist' | 'listener' | null;
  setModal: (value: null) => void;
  busy: boolean;
  editing: Playlist | null;
  formError: string;
  submit: (event: FormEvent<HTMLFormElement>) => Promise<void>;
}) {
  return <Dialog open={!!modal} onOpenChange={o => {
    if (!o && !busy) setModal(null);
  }}>
<DialogContent>
<DialogHeader>
<DialogTitle>{modal === 'upload' ? 'Add audio' : modal === 'listener' ? 'Add listener profile' : editing ? 'Edit DJ set' : 'Create DJ set'}</DialogTitle>
<DialogDescription>{modal === 'upload' ? 'Add your own audio and the metadata you use to plan a set.' : modal === 'listener' ? 'Keep likes and listening history separate for each listener.' : 'Give this set a name and a direction.'}</DialogDescription>
</DialogHeader>
<form onSubmit={submit} className="modal-form" key={`${modal}-${editing?.id ?? ''}`}>{modal === 'upload' ? <>
<label className="file-picker">
<Upload size={24} />
<strong>Choose audio file</strong>
<span>MP3, WAV, OGG or M4A · up to 20 MB</span>
<input type="file" name="audio" accept=".mp3,.wav,.ogg,.m4a" required />
</label>
<label>Track title<input name="title" maxLength={100} required placeholder="Track name" />
</label>
<label>Creator<input name="creator" maxLength={100} required placeholder="Artist or producer" />
</label>
<div className="form-grid">
<label>Genre<select name="genre" defaultValue="Pop">{genres.map(genre => <option key={genre}>{genre}</option>)}</select>
</label>
<label>BPM<input name="bpm" type="number" min={40} max={240} required step=".01" placeholder="Enter BPM" />
</label>
</div>
<label>Musical key<select name="key" defaultValue="" required>
<option value="" disabled>Choose key</option>{keys.map(key => <option key={key}>{key}</option>)}</select>
</label>
<p className="muted">BPM and key are entered manually. Add audio you have permission to use.</p>
</> : <>
<label>{modal === 'listener' ? 'Listener name' : 'Set name'}<input name="name" maxLength={100} defaultValue={editing?.name ?? ''} required placeholder={modal === 'listener' ? 'Name' : 'e.g. Friday at Tech Green'} />
</label>{modal === 'playlist' && <label>Description<textarea name="description" maxLength={240} defaultValue={editing?.description ?? ''} placeholder="What’s the mood?" rows={3} />
</label>}</>}{formError && <p role="alert" className="form-error">{formError}</p>}<button className="primary" type="submit" disabled={busy}>{busy ? 'Saving…' : modal === 'upload' ? 'Add to library' : modal === 'listener' ? 'Add listener' : editing ? 'Save changes' : 'Create set'}</button>
</form>
</DialogContent>
</Dialog>;
}
