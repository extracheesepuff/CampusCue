'use client';

import { AudioLines, Disc3, Plus, Headphones, Music2, BarChart3, ListMusic, Upload, SlidersHorizontal } from 'lucide-react';
import { TabsList, TabsTrigger } from '@/components/ui/tabs';
import Choice from './choice';
import type { Library } from '@/lib/types';
export function TopBar() {
  return <header className="topbar">
<a className="brand" href="/" aria-label="Campus Cue home">
<span className="brand-mark">
<AudioLines size={25} />
</span>campus<span className="brand-light">cue</span>
<span className="brand-period">.</span>
</a>
<span className="workspace-label">GEORGIA TECH <span>/</span> DJ WORKSPACE</span>
<div className="account">
<span className="avatar">BC</span>
<span>Brad’s workspace<small>Private library</small>
</span>
</div>
</header>;
}
export function Heading({
  data,
  busy,
  upload
}: {
  data: Library | null;
  busy: boolean;
  upload: () => void;
}) {
  return <>
<div className="page-heading dj-page-heading">
<div>
<div className="eyebrow">THE CAMPUS AFTERPARTY</div>
<h1>Plan the next set<span>.</span>
</h1>
<p>Your music, preparation notes, and mix history.</p>
</div>
<button className="primary" disabled={busy || !data} onClick={() => upload()}>
<Upload size={17} /> Add audio</button>
</div>
<div className="metrics">
<div>
<Music2 />
<span>Tracks in library<strong>{data?.tracks.length ?? '—'}</strong>
</span>
</div>
<div>
<ListMusic />
<span>DJ sets<strong>{data?.playlists.length ?? '—'}</strong>
</span>
</div>
<div>
<Headphones />
<span>Local plays<strong>{data?.stats.plays ?? '—'}</strong>
</span>
</div>
<div>
<Disc3 />
<span>Decades in rotation<strong>3</strong>
</span>
</div>
</div>
</>;
}
export function Navigation({
  data,
  busy,
  user,
  onListener,
  addListener
}: {
  data: Library | null;
  busy: boolean;
  user: string;
  onListener: (id: string) => Promise<void>;
  addListener: () => void;
}) {
  return <div className="navigation">
<TabsList className="view-tabs" variant="line">
<TabsTrigger value="library">
<Music2 size={17} /> Library</TabsTrigger>
<TabsTrigger value="dj">
<SlidersHorizontal size={17} /> Mix planner</TabsTrigger>
<TabsTrigger value="sets">
<ListMusic size={17} /> DJ sets</TabsTrigger>
<TabsTrigger value="analytics">
<BarChart3 size={17} /> Insights</TabsTrigger>
</TabsList>
<div className="listener-choice">
<span>Listening as</span>
<Choice value={user} onChange={onListener} label="Active listener" options={(data?.users ?? [{
        id: 'owner',
        name: 'Brad'
      }]).map(u => ({
        value: u.id,
        label: u.name
      }))} />
<button className="icon-button" aria-label="Add listener" disabled={!data || busy} onClick={() => addListener()}>
<Plus size={17} />
</button>
</div>
</div>;
}
