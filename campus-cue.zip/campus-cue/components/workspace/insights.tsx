'use client';

import { Plus } from 'lucide-react';
import { Table, TableHeader, TableHead, TableBody, TableRow, TableCell } from '@/components/ui/table';
import type { Library, Track } from '@/lib/types';
export default function Insights({
  data,
  add
}: {
  data: Library;
  add: (track: Track) => void;
}) {
  return <>
<div className="set-toolbar">
<div>
<h2>Know your listeners</h2>
<p>Likes include Spotify songs. Play counts measure uploaded audio only; embedded Spotify plays are not measured.</p>
</div>
<span className="pill">ALL LISTENERS</span>
</div>
<div className="insight-metrics">
<div>
<span>Listening time</span>
<strong>{(data.stats.seconds / 60).toFixed(1)} <small>min</small>
</strong>
</div>
<div>
<span>Active listeners</span>
<strong>{data.stats.listeners}</strong>
</div>
<div>
<span>Track likes</span>
<strong>{data.favorites.length}</strong>
</div>
</div>
<div className="insights-grid">
<section className="insight-card">
<h3>Genre preferences</h3>
<p>Local audio plays only; Spotify playback stays in Spotify.</p>{data.genres.length ? data.genres.map((g, i) => <div className="genre-bar" key={g.genre}>
<div>
<span>{g.genre}</span>
<strong>{g.plays} {g.plays === 1 ? 'play' : 'plays'}</strong>
</div>
<div className="bar-track">
<div style={{
              width: `${100 * g.plays / Math.max(...data.genres.map(g => g.plays))}%`,
              background: i === 0 ? 'var(--primary)' : '#758854'
            }} />
</div>
</div>) : <div className="empty-small">Play a track to start collecting genre preferences.</div>}</section>
<section className="insight-card">
<h3>Set selection shortlist</h3>
<p>Sorted by local plays, then likes</p>{[...data.tracks].filter(t => t.plays || t.likes).sort((a, b) => b.plays - a.plays || b.likes - a.likes).slice(0, 5).map((t, i) => <div className="ranked-track" key={t.id}>
<span className="rank">0{i + 1}</span>
<div>
<strong>{t.title}</strong>
<small>{t.decade ? `${t.decade}s · Spotify` : `${t.bpm} BPM · ${t.musical_key}`}</small>
</div>
<span>{t.plays} plays<br />{t.likes} likes</span>
<button className="icon-button" aria-label={`Add ${t.title} to set`} onClick={() => {
            add(t);
          }}>
<Plus size={18} />
</button>
</div>)}{!data.tracks.some(t => t.plays || t.likes) && <div className="empty-small">Play or like tracks to build your shortlist.</div>}</section>
<section className="insight-card listener-card">
<h3>Listener activity</h3>
<p>Profiles represent listeners you manage in this private workspace.</p>
<Table>
<TableHeader>
<TableRow>
<TableHead>Listener</TableHead>
<TableHead>Plays</TableHead>
<TableHead>Minutes</TableHead>
<TableHead>Favorite genre</TableHead>
</TableRow>
</TableHeader>
<TableBody>{data.listeners.map(l => {
              const counts: Record<string, number> = {};
              data.favorites.filter(f => f.user_id === l.id).forEach(f => {
                const t = data.tracks.find(t => t.id === f.track_id);
                if (t) counts[t.genre] = (counts[t.genre] ?? 0) + 1;
              });
              return <TableRow key={l.id}>
<TableCell>{l.name}</TableCell>
<TableCell>{l.plays}</TableCell>
<TableCell>{(l.seconds / 60).toFixed(1)}</TableCell>
<TableCell>{Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] ?? 'No likes yet'}</TableCell>
</TableRow>;
            })}</TableBody>
</Table>
</section>
</div>
</>;
}
