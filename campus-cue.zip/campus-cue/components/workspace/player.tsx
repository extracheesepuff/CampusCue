'use client';

import { useSyncExternalStore } from 'react';
import type { PlaybackClock } from '@/lib/playback-clock';
import { Disc3, Heart, X, ArrowUpRight, Headphones, Pause, Play, SkipForward, Volume2 } from 'lucide-react';
import { Slider } from '@/components/ui/slider';
import Artwork from '@/components/library/artwork';
import type { Track } from '@/lib/types';
const fmt = (n: number) => `${Math.floor(n / 60)}:${String(Math.floor(n % 60)).padStart(2, '0')}`;
type Props = {
  current: Track | null;
  embedOpen: boolean;
  setEmbedOpen: (open: boolean) => void;
  liked: (id: string) => boolean;
  busy: boolean;
  favorite: (track: Track) => void;
  toggle: () => void;
  playing: boolean;
  canNext: boolean;
  next: () => Promise<void>;
  clock: PlaybackClock;
  seek: (seconds: number) => void;
  volume: number;
  setVolume: (volume: number) => void;
};
export default function Player({
  current,
  embedOpen,
  setEmbedOpen,
  liked,
  busy,
  favorite,
  toggle,
  playing,
  canNext,
  next,
  clock,
  seek,
  volume,
  setVolume
}: Props) {
  const time = useSyncExternalStore(clock.subscribe, clock.getSnapshot, () => 0);
  return <>{current?.spotify_id && embedOpen && <div className="spotify-dock">
<div className="spotify-dock-header">
<span>SPOTIFY PLAYER</span>
<button className="icon-button" aria-label="Close Spotify player" onClick={() => setEmbedOpen(false)}>
<X size={16} />
</button>
</div>
<iframe key={current.spotify_id} src={`https://open.spotify.com/embed/track/${current.spotify_id}?theme=0`} title={`Listen to ${current.title} on Spotify`} width="100%" height="152" style={{
        border: 0,
        borderRadius: 12
      }} allow="autoplay; clipboard-write; encrypted-media; fullscreen; picture-in-picture" loading="lazy" />
<a href={`https://open.spotify.com/track/${current.spotify_id}`} target="_blank" rel="noopener noreferrer">Open in Spotify <ArrowUpRight size={13} />
</a>
<p>Playback availability depends on Spotify and your account.</p>
</div>}<div className="player">
<div className="now-playing">
<span className="player-icon">{current ? <Artwork key={current.id} track={current} /> : <Disc3 size={24} />}</span>
<div>
<strong>{current?.title ?? 'Nothing playing yet'}</strong>
<span>{current ? `${current.creator}${current.spotify_id ? ' · Spotify' : ''}` : 'Pick a track from your collection'}</span>
</div>{current && <button className={`icon-button ${liked(current.id) ? 'liked' : ''}`} aria-label="Like current track" disabled={busy} onClick={() => favorite(current)}>
<Heart size={17} fill={liked(current.id) ? 'currentColor' : 'none'} />
</button>}</div>
<div className="playback">
<div className="playback-controls">
<button className="play-button" disabled={!current} onClick={toggle} aria-label={current?.spotify_id ? 'Toggle Spotify player' : playing ? 'Pause playback' : 'Resume playback'}>{current?.spotify_id ? <Headphones size={19} /> : playing ? <Pause size={19} fill="currentColor" /> : <Play size={19} fill="currentColor" />}</button>
<button className="icon-button" disabled={!current || !canNext} aria-label="Next track" onClick={() => void next()}>
<SkipForward size={18} />
</button>
</div>
<div className={`seek ${current?.spotify_id ? "external-seek" : ""}`}>{current?.spotify_id ? <span className="external-copy">Use the Spotify player to listen.</span> : <>
<span>{fmt(time)}</span>
<Slider aria-label="Playback position" value={[time]} min={0} max={current?.duration || 1} step={0.1} disabled={!current} onValueChange={v => {
              seek(v[0]);
            }} />
<span>{fmt(current?.duration ?? 0)}</span>
</>}</div>
</div>{!current?.spotify_id && <div className="volume">
<Volume2 size={18} />
<Slider aria-label="Volume" value={[volume]} onValueChange={v => setVolume(v[0])} min={0} max={100} />
<span>{volume}%</span>
</div>}</div>
</>;
}
