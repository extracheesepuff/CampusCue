'use client';

import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogContent, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel } from '@/components/ui/alert-dialog';
import Choice from './choice';
import type { Library, Track, Playlist } from '@/lib/types';
export function AddToSet({
  track,
  data,
  target,
  setTarget,
  busy,
  close,
  add,
  create
}: {
  track: Track | null;
  data: Library | null;
  target: string;
  setTarget: (id: string) => void;
  busy: boolean;
  close: () => void;
  add: () => void;
  create: () => void;
}) {
  return <Dialog open={!!track} onOpenChange={o => {
    if (!o && !busy) close();
  }}>
<DialogContent>
<DialogHeader>
<DialogTitle>Add to a DJ set</DialogTitle>
<DialogDescription>{track?.title} · {track?.creator}</DialogDescription>
</DialogHeader>{data?.playlists.length ? <>
<Choice label="Destination playlist" value={target} onChange={setTarget} options={data.playlists.map(p => ({
          value: p.id,
          label: p.name
        }))} />
<button className="primary" disabled={busy || !target || !!data.items.some(i => i.playlist_id === target && i.track_id === track?.id)} onClick={() => add()}>{data.items.some(i => i.playlist_id === target && i.track_id === track?.id) ? 'Already in this set' : 'Add track'}</button>
</> : <>
<p>Create a set before adding tracks.</p>
<button className="primary" onClick={() => {
          create();
        }}>Create set</button>
</>}</DialogContent>
</Dialog>;
}
export function DeleteSet({
  playlist,
  busy,
  close,
  remove
}: {
  playlist: Playlist | null;
  busy: boolean;
  close: () => void;
  remove: () => void;
}) {
  return <AlertDialog open={!!playlist} onOpenChange={o => {
    if (!o && !busy) close();
  }}>
<AlertDialogContent>
<AlertDialogTitle>Delete “{playlist?.name}”?</AlertDialogTitle>
<AlertDialogDescription>This removes the playlist. Its audio tracks remain in your library.</AlertDialogDescription>
<AlertDialogFooter>
<AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
<button className="danger" disabled={busy} onClick={() => remove()}>{busy ? 'Deleting…' : 'Delete set'}</button>
</AlertDialogFooter>
</AlertDialogContent>
</AlertDialog>;
}
