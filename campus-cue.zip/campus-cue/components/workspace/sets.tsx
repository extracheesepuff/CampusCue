'use client';

import { Plus, Play, ListMusic, Pencil, Trash2 } from 'lucide-react';
import type { ReactNode } from 'react';
import type { Library, Track, Playlist } from '@/lib/types';
type Props = {
  data: Library;
  selectedPlaylist?: Playlist;
  setTracks: Track[];
  create: () => void;
  select: (id: string) => void;
  start: (track: Track, list: Track[]) => Promise<void>;
  edit: (set: Playlist) => void;
  remove: (set: Playlist) => void;
  browse: () => void;
  trackTable: (tracks: Track[], inSet?: boolean) => ReactNode;
};
export default function Sets({
  data,
  selectedPlaylist,
  setTracks,
  create,
  select,
  start,
  edit,
  remove,
  browse,
  trackTable
}: Props) {
  return <>
<div className="set-toolbar">
<div>
<h2>Your DJ sets</h2>
<p>Arrange tracks in the order you want to play them.</p>
</div>
<button className="primary" onClick={() => create()}>
<Plus size={17} /> New set</button>
</div>
<div className="playlist-grid">{data.playlists.map((p, i) => <button key={p.id} className={`playlist-card tone-${i % 4} ${selectedPlaylist?.id === p.id ? 'selected' : ''}`} onClick={() => select(p.id)}>
<ListMusic size={25} />
<strong>{p.name}</strong>
<span>{data.items.filter(t => t.playlist_id === p.id).length} tracks{p.id.startsWith('dj-') ? ' · Artist collection' : ''}</span>
</button>)}</div>{selectedPlaylist ? <section className="set-editor">
<div className="section-title">
<div>
<h2>{selectedPlaylist.name}</h2>
<p>{selectedPlaylist.description}</p>
<span className="muted">{setTracks.length} tracks · {setTracks.filter(t => t.spotify_id).length} Spotify songs</span>
</div>
<div className="row-actions">
<button className="secondary" disabled={!setTracks.length} onClick={() => void start(setTracks[0], setTracks)}>
<Play size={16} /> Play set</button>
<button className="icon-button" aria-label="Edit set" onClick={() => {
            edit(selectedPlaylist);
          }}>
<Pencil size={18} />
</button>
<button className="icon-button" aria-label="Delete set" onClick={() => remove(selectedPlaylist)}>
<Trash2 size={18} />
</button>
</div>
</div>{setTracks.length ? trackTable(setTracks, true) : <div className="empty-state">
<ListMusic />
<h3>This set is ready for tracks.</h3>
<p>Add tracks from the music library using the plus button.</p>
<button className="secondary" onClick={() => browse()}>Browse library</button>
</div>}</section> : <div className="empty-state">
<ListMusic />
<h3>No sets yet</h3>
<p>Create a set to start planning your playlist.</p>
</div>}</>;
}
