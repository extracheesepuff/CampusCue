'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';
import type { Track } from '@/lib/types';
import { createPlaybackClock } from '@/lib/playback-clock';
import { request } from '@/lib/library-api';
export function usePlayback(user: string, load: () => Promise<unknown>) {
  const [current, setCurrent] = useState<Track | null>(null),
    [playing, setPlaying] = useState(false),
    [volume, setVolume] = useState(70),
    [playerUser, setPlayerUser] = useState('owner'),
    [embedOpen, setEmbedOpen] = useState(true);
  const [clock] = useState(createPlaybackClock);
  const [queue, setQueue] = useState<Track[]>([]);
  const sourceRevision = useRef(0);
  const audio = useRef<HTMLAudioElement | null>(null),
    eventId = useRef(''),
    listened = useRef(0),
    lastTime = useRef(0),
    lastWall = useRef(0),
    recorded = useRef(false);
  const report = useCallback(async () => {
    if (!current || current.spotify_id || recorded.current || listened.current < 2) return;
    recorded.current = true;
    const sentEvent = eventId.current;
    try {
      await request({
        action: 'listen',
        trackId: current.id,
        userId: playerUser,
        seconds: Math.min(listened.current, current.duration),
        eventId: sentEvent
      });
      await load().catch(() => {});
    } catch (e) {
      if (eventId.current === sentEvent) recorded.current = false;
      toast.error('Listening activity was not saved. Try playing the track again.');
    }
  }, [current, playerUser, load]);
  const reportRef = useRef(report);
  reportRef.current = report;
  useEffect(() => {
    const finish = () => {
      if (current && !current.spotify_id && !recorded.current && listened.current >= 2) {
        fetch('/api/library', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            action: 'listen',
            trackId: current.id,
            userId: playerUser,
            seconds: Math.min(listened.current, current.duration),
            eventId: eventId.current
          }),
          keepalive: true
        }).catch(() => {});
        recorded.current = true;
      }
    };
    window.addEventListener('pagehide', finish);
    return () => window.removeEventListener('pagehide', finish);
  }, [current, playerUser]);
  useEffect(() => {
    if (current && audio.current && !current.spotify_id) {
      listened.current = 0;
      lastTime.current = 0;
      lastWall.current = performance.now();
      recorded.current = false;
      eventId.current = crypto.randomUUID();
      clock.set(0);
      audio.current.load();
      const revision = sourceRevision.current;
      audio.current.play().catch(() => {
        if (revision !== sourceRevision.current) return;
        setPlaying(false);
        toast.error('Playback could not start. Press play to retry.');
      });
    }
  }, [current, clock]);
  useEffect(() => {
    if (audio.current) audio.current.volume = volume / 100;
  }, [volume]);
  const start = async (track: Track, list: Track[]) => {
    setQueue(list);
    if (current?.id === track.id) {
      if (track.spotify_id) setEmbedOpen(true);else toggle();
      return;
    }
    sourceRevision.current++;
    void report();
    audio.current?.pause();
    setPlaying(false);
    setEmbedOpen(true);
    setPlayerUser(user);
    setCurrent(track);
  };
  const toggle = () => {
    if (current?.spotify_id) {
      setEmbedOpen(!embedOpen);
      return;
    }
    const a = audio.current;
    if (!a) return;
    if (a.paused) {
      if (recorded.current) {
        eventId.current = crypto.randomUUID();
        recorded.current = false;
        listened.current = 0;
      }
      lastTime.current = a.currentTime;
      lastWall.current = performance.now();
      const revision = sourceRevision.current;
      a.play().catch(() => {
        if (revision === sourceRevision.current) toast.error('Audio playback failed.');
      });
    } else a.pause();
  };
  const next = async () => {
    const i = queue.findIndex(t => t.id === current?.id);
    if (i >= 0 && i + 1 < queue.length) await start(queue[i + 1], queue);else {
      audio.current?.pause();
      await report();
    }
  };
  const stop = async () => {
    sourceRevision.current++;
    audio.current?.pause();
    void report();
    setCurrent(null);
    setPlaying(false);
  };
  const seek = (seconds: number) => {
    if (audio.current) {
      audio.current.currentTime = seconds;
      lastTime.current = seconds;
      lastWall.current = performance.now();
      clock.set(seconds);
    }
  };
  return {
    current,
    playing,
    clock,
    volume,
    embedOpen,
    setVolume,
    setEmbedOpen,
    start,
    toggle,
    next,
    stop,
    seek,
    canNext: !!current && queue.some((track, index) => track.id === current.id && index < queue.length - 1),
    audioProps: {
      ref: audio,
      src: current && !current.spotify_id ? current.demo_url ?? `/api/audio/${current.id}` : undefined,
      onPlay: () => {
        setPlaying(true);
        lastWall.current = performance.now();
        lastTime.current = audio.current?.currentTime ?? 0;
      },
      onPause: () => {
        setPlaying(false);
        void reportRef.current();
      },
      onTimeUpdate: () => {
        const a = audio.current;
        if (!a) return;
        const delta = a.currentTime - lastTime.current,
          elapsed = (performance.now() - lastWall.current) / 1000;
        if (!a.paused && delta > 0 && delta <= elapsed + 0.75) listened.current += Math.min(delta, elapsed + 0.1);
        lastTime.current = a.currentTime;
        lastWall.current = performance.now();
        clock.set(a.currentTime);
      },
      onEnded: () => {
        setPlaying(false);
        void next();
      },
      onError: () => {
        if (current && !current.spotify_id) {
          setPlaying(false);
          toast.error('Audio could not be loaded. Try again or upload a compatible file.');
        }
      },
      preload: 'metadata' as const
    }
  };
}
