'use client';

import { useEffect } from 'react';
export function usePlaylistTool(act: (body: unknown) => Promise<{
  id: string;
}>, openSet: (id: string) => void) {
  useEffect(() => {
    const ctx = (document as unknown as {
      modelContext?: {
        registerTool: (t: unknown, o: unknown) => Promise<void>;
      };
    }).modelContext;
    if (!ctx) return;
    const abort = new AbortController();
    Promise.resolve(ctx.registerTool({
      name: 'create_dj_playlist',
      title: 'Create DJ playlist',
      description: 'Create a saved playlist and open it in the set editor.',
      inputSchema: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            minLength: 1,
            maxLength: 100
          },
          description: {
            type: 'string',
            maxLength: 240
          }
        },
        required: ['name'],
        additionalProperties: false
      },
      annotations: {
        readOnlyHint: false
      },
      execute: async (input: unknown) => {
        const a = input as {
          name: string;
          description?: string;
        };
        if (!a || typeof a.name !== 'string' || !a.name.trim() || a.name.length > 100) throw new Error('A playlist name is required.');
        const r = await act({
          action: 'createPlaylist',
          name: a.name,
          description: a.description ?? ''
        });
        openSet(r.id);
        return {
          id: r.id,
          name: a.name
        };
      }
    }, {
      signal: abort.signal
    })).catch(() => {});
    return () => abort.abort();
  }, [act, openSet]);
}
