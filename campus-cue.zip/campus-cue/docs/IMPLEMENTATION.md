# Campus Cue

A private campus DJ music library with SQL persistence, era-based vocal song crates, and uploaded audio playback.

## Features

- 138 vocal songs: the original 90, eight DJ vocal releases, and 40 researched Atlanta and multi-genre additions. Decades reflect original releases, including eight pre-2000 selections.
- Spotify embedded players, official track links, and provider album-art lookup with an icon fallback.
- Dark collection browser with compact decade, genre, source, and liked filters; title/artist search scopes; removable filters; and keyboard search shortcuts.
- Create, rename, delete, and reorder playlists; manage listener profiles and track likes.
- Upload MP3, WAV, OGG, or M4A files (20 MB maximum); stream them through R2 with byte ranges.
- SQL-backed summaries of local audio activity and track likes.

The catalog uses the original recording artists, not karaoke or instrumental covers. Era classifications refer to original song eras rather than later compilation dates. Genre tags are editorial categories for organizing sets.

Spotify content is played inside Spotify's own player. Availability, preview length, authentication, and full-track access are controlled by Spotify. This app does not store, rip, or mix those recordings. Full audio files that you have permission to use can be uploaded for direct playback. A link selection or embedded player opening is not counted as a listen.

## Sources

Each title and artist was checked against the official Spotify track page linked by `lib/catalog.ts` and `lib/expanded-catalog.ts`. Spotify embed behavior and artwork fields follow:

- https://developer.spotify.com/documentation/embeds
- https://developer.spotify.com/documentation/embeds/tutorials/using-the-oembed-api

Album art is requested from Spotify's oEmbed service, limited to HTTPS `i.scdn.co` thumbnail redirects. Failed lookup displays a music icon. This external lookup and browser playback were not verified end-to-end in the execution environment.

This is not an official Georgia Tech service and does not establish prior use on campus.

## Data model and preservation

`users` → `playlists` → `playlist_tracks` → `tracks` → `creators`

`users` → `favorites` / `listens` → `tracks`

D1 enforces keys, foreign keys, uniqueness, indexes, and numeric constraints. R2 stores uploaded audio separately. Versioned Drizzle migrations own the schema. The catalog update only adds nullable `spotify_id` and `decade` columns, preserving existing records.

The original schema required BPM, key, and duration on every track. External catalog records use explicitly documented storage sentinels to satisfy that legacy schema without rebuilding a referenced table. Saved preparation overlays BPM, key, energy, and notes in the Library, search, and sorting. For unprepared catalog songs, the API returns unknown BPM as `null`, unknown key as an empty string, and unavailable native duration as `0`; these are never shown as measured song values. Catalog records cannot produce local listening events. Manually supplied metadata on uploaded tracks is preserved.

Original synth demo records remain stored to preserve history but are excluded from the visible catalog. Unchanged demo-only starter playlists are hidden; custom playlists and uploads remain visible. Initialization flags prevent deleted era playlists from being recreated on refresh.

## Analytics

A local play is an observed playback segment of at least two seconds. Unique event IDs prevent duplicate counts; counted seconds are capped at the uploaded track duration. Pausing, changing tracks, completion, or page exit ends a segment. Seeking is not counted as listening. Browser shutdown or network loss can drop a final event.

Like counts include both catalog and uploaded tracks. Spotify playback remains outside local play totals. Genre playback charts reflect local audio only. Favorite genre per listener is based on likes. These listener summaries are descriptive; the separate DJ intelligence view learns from explicitly rated transitions.

## Development and verification

Use the project's configured package manager and scripts. Generate future schema changes with `db:generate`; apply pending migrations in order for a local D1 preview. Hosted publication applies production migrations separately.

- TypeScript: `node node_modules/typescript/bin/tsc --noEmit`
- Build: `node /root/.codex/plugins/cache/openai-curated-remote/sites/0.1.75/scripts/build-site.mjs`
- Isolated integration checks: `node scripts/verify-built.mjs`

- Search and import checks: `node --experimental-strip-types scripts/verify-search.mjs`

The verification script tests the compiled Worker against isolated databases and buckets, including preservation of pre-update records. Browser interaction, visual inspection, external Spotify playback, and WebMCP execution are unverified where the browser preview is unavailable.



## DJ intelligence

The Library opens by default. Mix planner provides next-track recommendations, a directional transition journal, preparation metadata, a proposed set order, a visualization of user-rated set energy, and a downloadable text set sheet. Preparation includes user-supplied BPM, Camelot key, energy (1–10), mix-in/mix-out cues, and phrase/vocal/version notes. Cues are planning notes and do not seek or mix the Spotify player. Metadata is not automatically measured from Spotify audio.

Record transitions you have heard, using ratings 1–5. Past transitions can be imported as one pipe-separated row per transition:

```text
From title | To title | Rating 1–5 | Technique | Note
```

Titles must identify a library track uniquely. Accents, apostrophes, case, and extra spaces are normalized. Use `Title — Artist` for duplicate titles. Technique and note are optional. Import up to 100 rows at once; invalid rows cause the whole batch to be rejected. Available techniques: Blend, Echo out, Cut, Loop transition, Wordplay. A list of tracks alone cannot establish seamless mix quality. No famous DJ mix histories or synthetic ratings are seeded into the user's training data.

### Learning method

`lib/dj-model.ts` implements regularized logistic regression without an external API/key. Tempo compatibility and its explanation both use the required incoming-track pitch adjustment, comparing normal, half, and double time. The feature vector is: intercept, tempo compatibility, harmonic compatibility, same genre, energy proximity, and three missing-data indicators. Tempo considers normal, half, and double time; key rules use same Camelot code, adjacent numbers in the same mode, and the relative major/minor. User notes and technique are saved for reference and are not analyzed by this model.

Before 8 ratings across at least 3 directed track pairs with varied outcomes, the general model uses explicit rule-based prior weights. After that gate, it minimizes soft-label cross entropy with rating target `(rating - 1) / 4`, using 400 full-batch gradient steps (learning rate 0.12) and L2 regularization (0.08) toward prior weights. This is a working personalization method, not a validated professional DJ model. Predictive accuracy has not been measured. Training uses at most the latest 500 records; older records remain stored.

Directed-pair history separately adjusts predictions with a three-observation prior. Metadata features are frozen when a rating is recorded, so later preparation edits do not alter past examples. User-selected energy direction adds a small ranking adjustment when both energy ratings are known. A displayed 0–100 fit score is an ordinal ranking aid, not a calibrated probability of a seamless transition. Missing BPM/key/energy is explicitly flagged; with no metadata or pair history no score is displayed.

Set ordering uses a width-32 beam search over 3–50 existing set members. The first track stays pinned. It preserves membership and only proposes an order when its ranking objective improves. It is not a guarantee of a globally optimal sequence or good audio mixing. Changes are previewed and applied through the existing revision-checked playlist endpoint; concurrent edits are rejected.

New additive D1 tables `dj_prep` and `dj_transitions` preserve all existing data. Prep updates use revision checks. The journal retains transition IDs after an uncertain response so an unchanged retry stays idempotent. Transition IDs prevent duplicate writes on retries with the same ID; repeated imports with new IDs are separate observations. Stored cues on uploaded audio cannot exceed its known duration.

Harmonic rules reference the provider's official guide: https://mixedinkey.com/harmonic-mixing-guide/ . Actual audio timing, vocal collisions, edit versions, beat grids, and crowd response still require auditioning in your DJ software. Research on extracting transitions from complete mix audio is distinct from this metadata/rating model: https://arxiv.org/abs/2008.10267 .

Model behavior checks: `node --experimental-strip-types scripts/verify-dj-model.mjs`. These use synthetic test fixtures only, never production history. Compiled endpoint checks: `node scripts/verify-built.mjs`. Browser interaction and external playback remain unverified in this environment.

The 72-song expansion appends catalog tracks once per decade and does not add, remove, reorder, or recreate saved playlist memberships. Existing transition ratings and track preparation remain unchanged. No new schema migration is required.

## Search and interface refinements

Search matches all words across the selected fields in any order, then ranks exact titles and prefixes first. It is deterministic, without an API call or another ML model. Everything scope searches title, artist, genre, decade, key, and saved preparation notes. Empty search defaults to alphabetical browsing; recently added and BPM/play sorting are separate choices. Result lists show 40 at a time with a Show more control. Filters stay visible, and Reset all clears query and filters together.

Ctrl/Cmd+K opens Library search; / focuses search when outside a text field or dialog. Escape clears the search input. Artist names open artist-scoped search. Song selectors in Mix planner use the same search helper. The journal can reveal additional pages of the latest 500 loaded ratings. An already-open Spotify row reopens its player rather than closing it.

Interface research used official Spotify search guidance and rekordbox's collection browser. These inspired search scopes, compact controls, and visible BPM/key columns; no product assets or proprietary interface code were copied:

- https://support.spotify.com/us/article/search/
- https://rekordbox.com/en/feature/overview/

Recommendation logic is split into named metadata, tempo, feature, training, evaluation, and ordering functions. Malformed feature arrays and invalid ratings are excluded before counting usable training pairs. Frozen historical vectors stay unchanged. Browser layout and third-party playback cannot be confirmed without a supported preview session.

## Simple input workflows

Use the Track info button in Library or Mix planner to open a short editor. BPM, Camelot key, energy, and notes are optional. Chill / Steady / Peak fill energy 3 / 6 / 9; the slider adjusts that personal rating and Clear removes it. Cues sit in an optional section and accept seconds or m:ss. A mix rating is selected with five labeled buttons; a rating and two different tracks are required. Import errors appear beside the import form.

Inputs are split into small components under `components/dj` and `components/workspace`. `use-dj-data` owns saved history and retry IDs; `use-playback` owns audio events. Recommendation mathematics stays in `lib/dj-model.ts`. `lib/prep-form.ts` converts optional values and cue formats; the server remains responsible for final validation. The upload endpoint accepts decimal BPM to match its input.

Input parser checks: `node --experimental-strip-types scripts/verify-inputs.mjs`. The compiled endpoint suite also checks fractional-BPM upload persistence. Browser interactions remain unverified where the managed preview is unavailable.

### Rhythm suggestions and DJ collections

- Optional groove, 8/16/32-bar phrase length, and incoming/outgoing section vocal density are stored in four nullable columns by additive migration `0003`. Older API clients preserve these fields when omitted; explicit null clears them. Phrase planning assumes 4/4; no meter is inferred.
- Matching grooves add .06 to ranking; differing grooves subtract .04. Busy outgoing and incoming lead vocals subtract .10; a clear section adds .04. These transparent fixed adjustments are separate from the existing eight-feature personal ML model. Historic training vectors remain unchanged. Phrase length informs the plan and does not award a score bonus.
- Next-track cards propose an audition plan: phrase-aligned blend, cut, or echo out according to available tempo and section data. The suggested 16-bar blend is labeled a starting point when phrase metadata is unknown. No beats, key, vocals, or rhythm are automatically inferred from commercial recordings.
- Tap tempo uses the median of recent beat intervals after four taps. A pause resets the estimate; applying the BPM is an explicit choice. Estimates require confirmation by ear and can reflect half/double time.
- Five editable artist collections contain selected vocal originals and collaborations by Calvin Harris (5), David Guetta (4), Avicii (3), Martin Garrix (3), and Tiësto (3). These are Campus Cue selections, not artist-curated playlists, recorded live sets, mashups, or model training examples. The one-time atomic seed preserves later edits and deletions. Each song links to its official Spotify listing; new listings are recorded in `lib/dj-catalog.ts`.
- New source listings: [Scared To Be Lonely](https://open.spotify.com/track/035PPqAV8y4m8SqLHBCvdb), [In the Name of Love](https://open.spotify.com/track/5GvA4vzyf0OGE4oTRfaON2), [High On Life](https://open.spotify.com/track/4ut5G4rgB1ClpMTMfjoIuy), [The Business](https://open.spotify.com/track/0wi0wJ2SLulCX9HILTMnD1), [The Motto](https://open.spotify.com/track/18asYwWugKjjsihZ0YvRxO), [Red Lights](https://open.spotify.com/track/4VkryxEIts4X44bjdtvlYy), [One Kiss](https://open.spotify.com/track/4ubENH7RNQsbmv2d8u0B1J), [Feel So Close](https://open.spotify.com/track/5oYlWIGXw8UbmneXjR0gzp). Search listings verified artist/title; Spotify rate-limited direct opens for High On Life and The Motto. Regional availability and actual Spotify playback remain unverified.
- Verification: production build and TypeScript check; 153 compiled Worker/database checks, 39 model checks, 26 search checks, 15 input checks, and 16 rhythm checks. Synthetic tests verify behavior, not predictive mix quality. Browser UI QA is unavailable in this environment.

### Atlanta expansion and catalog cleanup

Forty new songs are defined in `lib/atlanta-catalog.ts`; each has a verified Spotify search listing matching its title and recording artist, plus a selection source in `lib/catalog-context.ts`. Existing “Hey Ya!” and “No Hands” recordings are reused in collections. The expansion keeps existing playlist order, likes, prep, history and track IDs intact. “Without You” now includes USHER’s featured credit.

- Atlanta game day: four songs with documented Tech event or Falcons celebration use. Historical reports are not a claim about a current stadium rotation.
- ATL party: local retrospective selections and published DJ tracklists, including crunk, snap, trap, Southern hip-hop and Atlanta bass.
- Singalongs: rock, alternative rock, country, disco and pop selections from published DJ tracklists.
- Global dance: Afrobeats, Latin dance and merengue selections from published DJ tracklists.

“Why this pick” shows the selection evidence in the interface. Published DJ sets can contain different remixes, clean edits or extended versions from the catalog recording. In particular, Tech’s 2009 “All the Way Turnt Up” report names an earlier Travis Porter version; the catalog entry is the Roscoe Dash commercial recording. No playlist popularity measurements, clean-version guarantees, automatic acoustic analysis or training examples are fabricated.

Research sources checked October 6, 2026:

- [AJC: Georgia Tech game day](https://www.ajc.com/sports/georgia-tech/georgia-tech-a-game-day-in-the-life-of-buzz-cheerleaders-and-ramblin-wreck/JPSK367AY5FRXO6E3TV7RJFBBA/) — Swag Surfin’ and Super Bass.
- [Andscape: Falcons celebrations](https://andscape.com/features/atlanta-falcons-super-bowl-jermaine-dupri-ludacris-the-migos/) — Welcome to Atlanta and Put On.
- [AJC: Atlanta hip-hop retrospective](https://open.spotify.com/playlist/3dWDXgowyCwf6TZHfdHVkz).
- [HBtheBosss: HBCU Homecoming](https://serato.com/playlists/HBtheBosss/hbcu-homecoming).
- [DJ Ryeski: published set](https://serato.com/playlists/ryeski/02-08-2025).
- [DJ Fragg: published set](https://serato.com/playlists/Your_Favorite_DJ/4-5-25).
- [Swaye: published set](https://serato.com/playlists/Swaye07/7-5-25).
- [Spotify: Without You featured-artist credit](https://open.spotify.com/embed/track/3UN6cIn3VIyg0z1LCuFSum).

The upload form and API share `lib/genres.ts`. Search filters live in `lib/library-view.ts`, with genre families, collection filters, an older-era filter, and existing listener likes. Search recognizes “Swag Surfing,” dotted initials and Atlanta collection terms. All sets remain accessible beyond the six shown in the library sidebar.

Planner fixes: phrase length alone no longer produces a fit score; an existing order proposal clears when ratings or playlist revision change. Additive selection metadata does not train the model or create listening activity.

Validation adds `scripts/verify-discovery.mjs` for search aliases, genre families, provenance coverage, collection combinations, older-era handling, nonmutating sorting, and the phrase-only score regression. Compiled endpoint checks cover all 40 additions, new upload genres, idempotence, existing data preservation, and corrected artist credit. Browser interaction and Spotify playback remain unverified.
