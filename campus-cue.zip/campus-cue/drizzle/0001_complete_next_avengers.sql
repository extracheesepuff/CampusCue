ALTER TABLE `tracks` ADD `spotify_id` text;--> statement-breakpoint
ALTER TABLE `tracks` ADD `decade` integer;