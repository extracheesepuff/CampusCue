CREATE TABLE `dj_prep` (
	`track_id` text PRIMARY KEY NOT NULL,
	`bpm` real,
	`camelot` text,
	`energy` integer,
	`cue_in` real,
	`cue_out` real,
	`notes` text DEFAULT '' NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`track_id`) REFERENCES `tracks`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "dj_bpm_range" CHECK("dj_prep"."bpm" IS NULL OR "dj_prep"."bpm" BETWEEN 40 AND 240),
	CONSTRAINT "dj_energy_range" CHECK("dj_prep"."energy" IS NULL OR "dj_prep"."energy" BETWEEN 1 AND 10),
	CONSTRAINT "dj_cue_in_range" CHECK("dj_prep"."cue_in" IS NULL OR "dj_prep"."cue_in" BETWEEN 0 AND 7200),
	CONSTRAINT "dj_cue_out_range" CHECK("dj_prep"."cue_out" IS NULL OR "dj_prep"."cue_out" BETWEEN 0 AND 7200),
	CONSTRAINT "dj_cue_order" CHECK("dj_prep"."cue_in" IS NULL OR "dj_prep"."cue_out" IS NULL OR "dj_prep"."cue_out" > "dj_prep"."cue_in")
);
--> statement-breakpoint
CREATE TABLE `dj_transitions` (
	`id` text PRIMARY KEY NOT NULL,
	`from_id` text NOT NULL,
	`to_id` text NOT NULL,
	`rating` integer NOT NULL,
	`technique` text NOT NULL,
	`notes` text DEFAULT '' NOT NULL,
	`features` text NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	FOREIGN KEY (`from_id`) REFERENCES `tracks`(`id`) ON UPDATE no action ON DELETE cascade,
	FOREIGN KEY (`to_id`) REFERENCES `tracks`(`id`) ON UPDATE no action ON DELETE cascade,
	CONSTRAINT "dj_rating_range" CHECK("dj_transitions"."rating" BETWEEN 1 AND 5),
	CONSTRAINT "dj_distinct_tracks" CHECK("dj_transitions"."from_id" <> "dj_transitions"."to_id")
);
--> statement-breakpoint
CREATE INDEX `idx_dj_transition_pair` ON `dj_transitions` (`from_id`,`to_id`);