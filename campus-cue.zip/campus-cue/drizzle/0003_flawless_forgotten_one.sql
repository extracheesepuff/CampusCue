ALTER TABLE `dj_prep` ADD `groove` text;--> statement-breakpoint
ALTER TABLE `dj_prep` ADD `phrase_bars` integer;--> statement-breakpoint
ALTER TABLE `dj_prep` ADD `intro_vocals` text;--> statement-breakpoint
ALTER TABLE `dj_prep` ADD `outro_vocals` text;