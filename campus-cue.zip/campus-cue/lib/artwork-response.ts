// A neutral music icon keeps unavailable covers from becoming broken images.
const placeholder = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48"><rect width="48" height="48" rx="8" fill="#252334"/><path d="M29 13v19m0-19 9-2v18M29 19l9-2" fill="none" stroke="#b7abc9" stroke-width="2"/><ellipse cx="25" cy="33" rx="4" ry="3" fill="#b7abc9"/><ellipse cx="34" cy="30" rx="4" ry="3" fill="#b7abc9"/></svg>';
export function artworkFallback() {
  return new Response(placeholder, { headers: {
    'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=300'
  } });
}
export async function artworkResponse(spotifyId: string, fetcher: typeof fetch = fetch) {
  try {
    const response = await fetcher(`https://open.spotify.com/oembed?url=${encodeURIComponent(`https://open.spotify.com/track/${spotifyId}`)}`, { signal: AbortSignal.timeout(2000) });
    if (!response.ok) return artworkFallback();
    const data = await response.json() as { thumbnail_url?: string };
    if (!data.thumbnail_url) return artworkFallback();
    const url = new URL(data.thumbnail_url);
    if (url.protocol !== 'https:' || url.hostname !== 'i.scdn.co') return artworkFallback();
    return new Response(null, { status: 302, headers: { Location: url.href, 'Cache-Control': 'public, max-age=86400' } });
  } catch { return artworkFallback(); }
}
