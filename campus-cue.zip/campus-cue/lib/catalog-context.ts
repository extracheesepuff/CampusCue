import { atlantaCatalog } from './atlanta-catalog.ts';
import { partyCatalog } from './party-catalog.ts';
export const collections = [
  { id: 'rap', name: 'Rap party', description: 'Rap and R&B party picks. Check sources and recording versions under each song.' },
  { id: 'bar', name: 'College bar', description: 'Party pop, rap and singalongs for your college-bar or frat set. Editorial picks; audition before playing.' },
  { id: 'game', name: 'Atlanta game day', description: 'Songs documented at Tech events and Falcons celebrations. Historical use, not a current stadium rotation.' },
  { id: 'atl', name: 'ATL party', description: 'Atlanta selections from local coverage and published DJ sets.' },
  { id: 'sing', name: 'Singalongs', description: 'Rock, country, pop and disco selections found in published DJ tracklists.' },
  { id: 'global', name: 'Global dance', description: 'Afrobeats and Latin dance selections found in published DJ tracklists.' }
] as const;
export const evidence = {
  tech: { label: 'AJC · Georgia Tech game day', url: 'https://www.ajc.com/sports/georgia-tech/georgia-tech-a-game-day-in-the-life-of-buzz-cheerleaders-and-ramblin-wreck/JPSK367AY5FRXO6E3TV7RJFBBA/', note: 'Reported at Georgia Tech’s 2023 game-day block party.' },
  falcons: { label: 'Andscape · Falcons celebrations', url: 'https://andscape.com/features/atlanta-falcons-super-bowl-jermaine-dupri-ludacris-the-migos/', note: 'Reported during Atlanta’s 2017 NFC Championship celebrations.' },
  ajc: { label: 'AJC · Atlanta hip-hop selections', url: 'https://open.spotify.com/playlist/3dWDXgowyCwf6TZHfdHVkz', note: 'Selected in the AJC’s Atlanta hip-hop retrospective. Recording versions may differ.' },
  homecoming: { label: 'HBtheBosss · HBCU Homecoming', url: 'https://serato.com/playlists/HBtheBosss/hbcu-homecoming', note: 'Song appears in a DJ-published HBCU Homecoming tracklist. Audition the linked recording for your crowd.' },
  turnt: { label: 'AJC · Georgia Tech, 2009', url: 'https://www.ajc.com/sports/college/players-video-fires-crowd-tech/WF4wzNtHxkl2fMxR2ZTnqL/', note: 'Tech’s 2009 coverage names an earlier Travis Porter version. This catalog links Roscoe Dash’s commercial release.' },
  ryeski: { label: 'DJ Ryeski · published set', url: 'https://serato.com/playlists/ryeski/02-08-2025', note: 'Song appears in DJ Ryeski’s published set. The catalog recording may differ from the listed DJ edit.' },
  fragg: { label: 'DJ Fragg · published set', url: 'https://serato.com/playlists/Your_Favorite_DJ/4-5-25', note: 'Song appears in DJ Fragg’s published set. The catalog recording may differ from the listed DJ edit.' },
  swaye: { label: 'Swaye · published set', url: 'https://serato.com/playlists/Swaye07/7-5-25', note: 'Song appears in Swaye’s published set. The catalog recording may differ from the listed DJ edit.' }
};
export type CatalogContext = { collections: string[]; source: typeof evidence[keyof typeof evidence] };
const contexts = new Map<string, CatalogContext>(atlantaCatalog.map(track => [track.id, {
  collections: track.collection === 'game' && track.id !== 'atl-super-bass' ? ['game', 'atl'] : [track.collection],
  source: evidence[track.evidence as keyof typeof evidence]
}]));
// Existing recordings are reused, preserving likes, preparation and set membership.
contexts.set('more-2000-04', { collections: ['atl', 'sing'], source: evidence.ajc });
contexts.set('more-2010-24', { collections: ['atl'], source: evidence.homecoming });
for (const track of partyCatalog) contexts.set(track.id, {
  collections: track.collection === 'bar' ? ['bar', 'sing'] : ['rap', 'bar'],
  source: evidence[track.evidence as keyof typeof evidence]
});
// Extend browsing tags without changing recording IDs or their saved preparation.
for (const [id, context] of contexts) {
  if (context.collections.includes('atl') || id === 'atl-super-bass') context.collections.push('rap');
  if (context.collections.some(tag => ['rap', 'sing'].includes(tag)) && !context.collections.includes('bar')) context.collections.push('bar');
}
for (const id of ['y2k-yeah', 'y2k-low', 'y2k-crazy']) contexts.set(id, { collections: ['rap', 'bar'], source: evidence.ryeski });
for (const id of ['2010-love', '2010-timber', '2010-uptown', 'y2k-toxic', '2020-espresso', 'more-2000-08', 'more-2010-03', 'more-2010-21']) contexts.set(id, { collections: ['bar'], source: evidence.ryeski });
export const catalogContext = (id: string) => contexts.get(id);
export const collectionWords = (id: string) => {
  const tags = catalogContext(id)?.collections ?? [];
  return collections.filter(item => tags.includes(item.id)).map(item => item.id === 'atl' ? 'Atlanta ATL party' : item.id === 'rap' ? 'rap hip hop party frat fraternity' : item.id === 'bar' ? 'college bar frat fraternity party' : item.name).join(' ');
};
