// Official vocal recordings. Each Spotify URL was opened and matched to its artist/title.
// Decades describe the original song era, not later compilation dates.
export const starterCatalog = [
 {id:'y2k-yeah',title:'Yeah!',artist:'USHER, Lil Jon, Ludacris',genre:'Hip-hop',decade:2000,spotify:'2UmuPygJ04wpFzvv76A3j7'},
 {id:'y2k-crazy',title:'Crazy In Love',artist:'Beyoncé, JAY-Z',genre:'R&B',decade:2000,spotify:'0WqIKmW4BTrj3eJFmnCKMv'},
 {id:'y2k-low',title:'Low',artist:'Flo Rida, T-Pain',genre:'Hip-hop',decade:2000,spotify:'0t2w4jQazlBggyZS4axpnw'},
 {id:'y2k-toxic',title:'Toxic',artist:'Britney Spears',genre:'Pop',decade:2000,spotify:'3z4vIp3wo8I34Z2V5ik3oA'},
 {id:'y2k-hips',title:"Hips Don’t Lie",artist:'Shakira, Wyclef Jean',genre:'Latin',decade:2000,spotify:'0yHhDpBAZWpd6dlZMQgU49'},
 {id:'y2k-feeling',title:'I Gotta Feeling',artist:'Black Eyed Peas',genre:'Dance pop',decade:2000,spotify:'4Mi388mi6c6jzzpyiWeRQW'},
 {id:'2010-love',title:'We Found Love',artist:'Rihanna, Calvin Harris',genre:'Dance pop',decade:2010,spotify:'14fmbvjYLqRZEXz1VZdM2M'},
 {id:'2010-party',title:'Party Rock Anthem',artist:'LMFAO, Lauren Bennett, GoonRock',genre:'Dance pop',decade:2010,spotify:'5YeniE7Fx0dGFdEMvVmrxA'},
 {id:'2010-uptown',title:'Uptown Funk',artist:'Mark Ronson, Bruno Mars',genre:'Funk',decade:2010,spotify:'4rmPQGwcLQjCoFq5NrTA0D'},
 {id:'2010-dance',title:'One Dance',artist:'Drake, Wizkid, Kyla',genre:'Dancehall',decade:2010,spotify:'1xznGGDReH1oQq0xzbwXa3'},
 {id:'2010-timber',title:'Timber',artist:'Pitbull, Kesha',genre:'Dance pop',decade:2010,spotify:'3cHyrEgdyYRjgJKSOiOtcS'},
 {id:'2010-start',title:'Don’t Start Now',artist:'Dua Lipa',genre:'Dance pop',decade:2010,spotify:'4U54mWY0leFsVzjNXys3pH'},
 {id:'2020-levitating',title:'Levitating',artist:'Dua Lipa',genre:'Dance pop',decade:2020,spotify:'39LLxExYz6ewLAcYrzQQyP'},
 {id:'2020-espresso',title:'Espresso',artist:'Sabrina Carpenter',genre:'Pop',decade:2020,spotify:'2qSkIjg1o9h3YT9RAgYN75'},
 {id:'2020-asitwas',title:'As It Was',artist:'Harry Styles',genre:'Pop',decade:2020,spotify:'4LRPiXqCikLlN15c3yImP7'},
 {id:'2020-soul',title:'BREAK MY SOUL',artist:'Beyoncé',genre:'Dance pop',decade:2020,spotify:'5pyoxDZ1PX0KxBxiRVxA4U'},
 {id:'2020-greedy',title:'greedy',artist:'Tate McRae',genre:'Pop',decade:2020,spotify:'3rUGC1vUpkDG9CZFHMur1t'},
 {id:'2020-hot',title:'HOT TO GO!',artist:'Chappell Roan',genre:'Pop',decade:2020,spotify:'4xdBrk0nFZaP54vvZj0yx7'},
] as const;

import { expandedCatalog } from "./expanded-catalog";
export { expandedCatalog };
import { djCatalog } from './dj-catalog';
import { atlantaCatalog } from './atlanta-catalog';
import { partyCatalog } from './party-catalog';
export const catalog = [...starterCatalog,...expandedCatalog,...djCatalog,...atlantaCatalog,...partyCatalog] as const;
