import { seedParty } from './seed-party';
import { seedAtlanta } from './seed-atlanta';
import { seedDJ } from './seed-dj';
import { env } from 'cloudflare:workers';
import { starterCatalog,expandedCatalog } from './catalog';
export const demoTracks = [
 ['demo-1','After Hours','House',124,'A minor',0],['demo-2','North Avenue','Deep House',118,'D minor',1],['demo-3','Gold Standard','House',128,'C minor',0],['demo-4','Midnight Circuit','Techno',132,'F minor',2],['demo-5','Courtyard','Lo-fi',86,'C major',1],['demo-6','Last Call','UK Garage',130,'G minor',2],['demo-7','Peachtree Drift','Deep House',120,'E minor',0],['demo-8','Daybreak','Electronic',110,'G major',1]
] as const;
export function database(): D1Database { const db = (env as unknown as {DB?:D1Database}).DB; if(!db) throw new Error('Database unavailable');return db; }
export function bucket(): R2Bucket { const b=(env as unknown as {BUCKET?:R2Bucket}).BUCKET;if(!b)throw new Error('Audio storage unavailable');return b; }
export async function initialize(){
 const db=database();
 const saved=await db.prepare('SELECT id FROM app_state').all<{id:string}>();
 const flags=new Set(saved.results.map(row=>row.id));
 if(!flags.has('vocal-catalog-v2')){
 await db.batch([
 db.prepare('INSERT OR IGNORE INTO users (id,name) VALUES (?,?)').bind('owner','Brad'),
 ...starterCatalog.map(t=>db.prepare('INSERT OR IGNORE INTO creators (id,name,normalized_name) VALUES (?,?,?)').bind(`artist-${t.id}`,t.artist,t.artist.toLowerCase())),
 // Legacy required numeric columns are storage sentinels for external songs.
 // They are never exposed as song metadata; the API projects unknown tempo/key/length.
 ...starterCatalog.map(t=>db.prepare('INSERT OR IGNORE INTO tracks (id,creator_id,title,genre,bpm,musical_key,duration,demo_url,is_demo,spotify_id,decade) SELECT ?,id,?,?,40,?,1,?,0,?,? FROM creators WHERE normalized_name=?').bind(t.id,t.title,t.genre,'Not analyzed',`https://open.spotify.com/track/${t.spotify}`,t.spotify,t.decade,t.artist.toLowerCase())),
 ...[2000,2010,2020].map((decade,i)=>db.prepare('INSERT OR IGNORE INTO playlists (id,user_id,name,description) VALUES (?,?,?,?)').bind(`era-${decade}`,'owner',['Y2K afterparty','2010s peak hour','New school rotation'][i],['The throwbacks everyone knows.','Big choruses. Bigger room.','The current rotation.'][i])),
 ...starterCatalog.map((t,i)=>db.prepare('INSERT OR IGNORE INTO playlist_tracks (playlist_id,track_id,position) VALUES (?,?,?)').bind(`era-${t.decade}`,t.id,i%6)),
 db.prepare('INSERT OR IGNORE INTO app_state (id) VALUES (?)').bind('initialized'),
 db.prepare('INSERT OR IGNORE INTO app_state (id) VALUES (?)').bind('vocal-catalog-v2')
 ]);
 }
 // Append library entries only. Existing set membership, order, prep, and ratings stay intact.
 for(const decade of [2000,2010,2020]){
 const flag=`vocal-expansion-v4-${decade}`;
 if(flags.has(flag))continue;
 const tracks=expandedCatalog.filter(t=>t.decade===decade);
 const creators=db.prepare(`INSERT OR IGNORE INTO creators (id,name,normalized_name) VALUES ${tracks.map(()=>'(?,?,?)').join(',')}`).bind(...tracks.flatMap(t=>[`artist-${t.id}`,t.artist,t.artist.toLowerCase()]));
 const inserts=[];
 // Small bulk statements keep the number of bound parameters below D1's per-query limit.
 for(let i=0;i<tracks.length;i+=10){const chunk=tracks.slice(i,i+10);
 inserts.push(db.prepare(`WITH input(id,title,genre,url,spotify,decade,artist) AS (VALUES ${chunk.map(()=>'(?,?,?,?,?,?,?)').join(',')}) INSERT OR IGNORE INTO tracks (id,creator_id,title,genre,bpm,musical_key,duration,demo_url,is_demo,spotify_id,decade) SELECT input.id,c.id,input.title,input.genre,40,'Not analyzed',1,input.url,0,input.spotify,input.decade FROM input JOIN creators c ON c.normalized_name=input.artist`).bind(...chunk.flatMap(t=>[t.id,t.title,t.genre,`https://open.spotify.com/track/${t.spotify}`,t.spotify,t.decade,t.artist.toLowerCase()])));
 }
 await db.batch([creators,...inserts,db.prepare('INSERT OR IGNORE INTO app_state (id) VALUES (?)').bind(flag)]);
 }
 await seedDJ(db,flags);
 await seedAtlanta(db,flags);
 await seedParty(db,flags);
}
export async function snapshot(){
 const db=database();
 const rs=await db.batch([
 db.prepare(`SELECT t.*,c.name AS creator,p.bpm AS prep_bpm,p.camelot AS prep_key,p.energy,p.notes AS dj_notes,(SELECT COUNT(*) FROM listens l WHERE l.track_id=t.id) AS plays,(SELECT COUNT(*) FROM favorites f WHERE f.track_id=t.id) AS likes FROM tracks t JOIN creators c ON c.id=t.creator_id LEFT JOIN dj_prep p ON p.track_id=t.id WHERE t.is_demo=0 ORDER BY t.created_at DESC,t.id ASC`),
 db.prepare(`SELECT p.* FROM playlists p WHERE NOT (((p.id='set-1' AND p.name='Campus warm-up') OR (p.id='set-2' AND p.name='After dark')) AND NOT EXISTS (SELECT 1 FROM playlist_tracks pt JOIN tracks t ON t.id=pt.track_id WHERE pt.playlist_id=p.id AND t.is_demo=0)) ORDER BY created_at DESC,id`),db.prepare('SELECT pt.* FROM playlist_tracks pt JOIN tracks t ON t.id=pt.track_id WHERE t.is_demo=0 ORDER BY playlist_id,position,track_id'),db.prepare('SELECT * FROM users ORDER BY created_at,id'),db.prepare('SELECT * FROM favorites'),
 db.prepare('SELECT COALESCE(SUM(seconds),0) AS seconds,COUNT(*) AS plays,COUNT(DISTINCT user_id) AS listeners FROM listens'),
 db.prepare(`SELECT t.genre,COUNT(*) AS plays,SUM(l.seconds) AS seconds FROM listens l JOIN tracks t ON t.id=l.track_id GROUP BY t.genre ORDER BY plays DESC,t.genre`),
 db.prepare(`SELECT u.id,u.name,COUNT(l.id) AS plays,COALESCE(SUM(l.seconds),0) AS seconds FROM users u LEFT JOIN listens l ON l.user_id=u.id GROUP BY u.id ORDER BY plays DESC`)
 ]);
 const tracks = (rs[0].results as Record<string,unknown>[]).map(row => {
   const { prep_bpm, prep_key, ...track } = row;
   return {
     ...track,
     bpm: prep_bpm ?? (track.spotify_id ? null : track.bpm),
     musical_key: prep_key ?? (track.spotify_id ? '' : track.musical_key),
     ...(track.spotify_id ? { duration: 0, demo_url: null } : {})
   };
 });
 return {tracks,playlists:rs[1].results,items:rs[2].results,users:rs[3].results,favorites:rs[4].results,stats:rs[5].results[0],genres:rs[6].results,listeners:rs[7].results};
}
