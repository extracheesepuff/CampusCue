// Vocal originals, matched to official Spotify listings. No live edits or mashups.
export const djCatalog = [
  { id: 'dj-scared', title: 'Scared To Be Lonely', artist: 'Martin Garrix, Dua Lipa', genre: 'Dance pop', decade: 2010, spotify: '035PPqAV8y4m8SqLHBCvdb' },
  { id: 'dj-name', title: 'In the Name of Love', artist: 'Martin Garrix, Bebe Rexha', genre: 'Dance pop', decade: 2010, spotify: '5GvA4vzyf0OGE4oTRfaON2' },
  { id: 'dj-high', title: 'High On Life (feat. Bonn)', artist: 'Martin Garrix, Bonn', genre: 'Dance pop', decade: 2010, spotify: '4ut5G4rgB1ClpMTMfjoIuy' },
  { id: 'dj-business', title: 'The Business', artist: 'Tiësto', genre: 'Dance pop', decade: 2020, spotify: '0wi0wJ2SLulCX9HILTMnD1' },
  { id: 'dj-motto', title: 'The Motto', artist: 'Tiësto, Ava Max', genre: 'Dance pop', decade: 2020, spotify: '18asYwWugKjjsihZ0YvRxO' },
  { id: 'dj-red', title: 'Red Lights', artist: 'Tiësto', genre: 'Dance pop', decade: 2010, spotify: '4VkryxEIts4X44bjdtvlYy' },
  { id: 'dj-kiss', title: 'One Kiss (with Dua Lipa)', artist: 'Calvin Harris, Dua Lipa', genre: 'Dance pop', decade: 2010, spotify: '4ubENH7RNQsbmv2d8u0B1J' },
  { id: 'dj-close', title: 'Feel So Close - Radio Edit', artist: 'Calvin Harris', genre: 'Dance pop', decade: 2010, spotify: '5oYlWIGXw8UbmneXjR0gzp' }
] as const;
export const djCollections = [
  { id: 'dj-calvin', artist: 'Calvin Harris', ids: ['dj-close', 'more-2010-14', 'dj-kiss', '2010-love', 'more-2010-15'] },
  { id: 'dj-guetta', artist: 'David Guetta', ids: ['more-2010-09', 'more-2010-10', 'more-2010-06', 'more-2020-07'] },
  { id: 'dj-avicii', artist: 'Avicii', ids: ['more-2010-11', 'more-2010-12', 'more-2010-13'] },
  { id: 'dj-garrix', artist: 'Martin Garrix', ids: ['dj-scared', 'dj-name', 'dj-high'] },
  { id: 'dj-tiesto', artist: 'Tiësto', ids: ['dj-red', 'dj-business', 'dj-motto'] }
] as const;
