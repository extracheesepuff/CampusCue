import { techniques } from './dj-model.ts';
import { normalizeSearch } from './search.ts';
import type { Track } from './types';

export type HistoryEntry = { fromId: string; toId: string; rating: number; technique: string; notes: string };

export function parseHistory(text: string, tracks: Track[]): HistoryEntry[] {
  const rows = text.split('\n').map((line, index) => ({ line: line.trim(), number: index + 1 })).filter(row => row.line);
  if (!rows.length || rows.length > 100) throw new Error('Paste between 1 and 100 transition rows.');
  const resolve = (name: string, row: number) => {
    const value = normalizeSearch(name);
    const found = tracks.filter(track => normalizeSearch(track.title) === value || normalizeSearch(`${track.title} — ${track.creator}`) === value);
    if (found.length !== 1) throw new Error(`Row ${row}: cannot uniquely match “${name}”. Use Title — Artist from the library.`);
    return found[0].id;
  };
  return rows.map(({ line, number }) => {
    const parts = line.split('|').map(part => part.trim());
    if (parts.length < 3 || parts.length > 5) throw new Error(`Row ${number}: use From title | To title | Rating | Technique | Note.`);
    const rating = Number(parts[2]), technique = parts[3] || 'Blend';
    if (!Number.isInteger(rating) || rating < 1 || rating > 5) throw new Error(`Row ${number}: rating must be 1–5.`);
    if (!techniques.includes(technique as typeof techniques[number])) throw new Error(`Row ${number}: choose a listed technique.`);
    const fromId = resolve(parts[0], number), toId = resolve(parts[1], number);
    if (fromId === toId) throw new Error(`Row ${number}: choose two different tracks.`);
    const notes = parts[4] ?? '';
    if (notes.length > 500) throw new Error(`Row ${number}: notes must be 500 characters or fewer.`);
    return { fromId, toId, rating, technique, notes };
  });
}
