import type { Track } from './types';
import { rhythmMatch, mixPlan, type Rhythm } from './rhythm.ts';

export type Prep = Rhythm & {
  track_id: string; bpm: number | null; camelot: string | null; energy: number | null;
  cue_in: number | null; cue_out: number | null; notes: string; revision: number;
};
export type Transition = {
  id: string; from_id: string; to_id: string; rating: number; technique: string;
  notes: string; features: string; created_at: string;
};
export type DJData = { prep: Prep[]; transitions: Transition[] };
export const techniques = ['Blend', 'Echo out', 'Cut', 'Loop transition', 'Wordplay'] as const;
export const camelotKeys = Array.from({ length: 12 }, (_, i) => [`${i + 1}A`, `${i + 1}B`]).flat();
const keyMap: Record<string, string> = {
  'B major': '1B', 'F# major': '2B', 'C# major': '3B', 'G# major': '4B', 'D# major': '5B',
  'A# major': '6B', 'F major': '7B', 'C major': '8B', 'G major': '9B', 'D major': '10B',
  'A major': '11B', 'E major': '12B', 'G# minor': '1A', 'D# minor': '2A', 'A# minor': '3A',
  'F minor': '4A', 'C minor': '5A', 'G minor': '6A', 'D minor': '7A', 'A minor': '8A',
  'E minor': '9A', 'B minor': '10A', 'F# minor': '11A', 'C# minor': '12A'
};

export function metadata(track: Track, prep: Prep[]) {
  const saved = prep.find(item => item.track_id === track.id);
  const key = camelotKeys.includes(track.musical_key) ? track.musical_key : keyMap[track.musical_key];
  return {
    bpm: saved?.bpm ?? track.bpm,
    key: saved?.camelot ?? key ?? null,
    energy: saved?.energy ?? track.energy ?? null,
    prep: saved
  };
}

export function harmonic(a: string, b: string) {
  if (!camelotKeys.includes(a) || !camelotKeys.includes(b)) return 0;
  if (a === b) return 1;
  const x = Number(a.slice(0, -1)), y = Number(b.slice(0, -1));
  if (x === y) return .9;
  const distance = Math.min(Math.abs(x - y), 12 - Math.abs(x - y));
  return a.slice(-1) === b.slice(-1) && distance === 1 ? .85 : 0;
}

// Use the same required incoming-track tempo shift for scoring and explanations.
export function tempoMatch(from: number, into: number) {
  return [.5, 1, 2].map(scale => ({ scale, shift: from / (into * scale) - 1 }))
    .sort((a, b) => Math.abs(a.shift) - Math.abs(b.shift))[0];
}

export function features(a: Track, b: Track, prep: Prep[]) {
  const x = metadata(a, prep), y = metadata(b, prep);
  const tempoKnown = x.bpm !== null && y.bpm !== null;
  const keyKnown = !!x.key && !!y.key;
  const energyKnown = x.energy !== null && y.energy !== null;
  const gap = tempoKnown ? Math.abs(tempoMatch(x.bpm!, y.bpm!).shift) : 0;
  return [
    1,
    tempoKnown ? Math.max(0, 1 - gap / .15) : 0,
    keyKnown ? harmonic(x.key!, y.key!) : 0,
    a.genre === b.genre ? 1 : 0,
    energyKnown ? 1 - Math.abs(y.energy! - x.energy!) / 9 : 0,
    tempoKnown ? 0 : 1, keyKnown ? 0 : 1, energyKnown ? 0 : 1
  ];
}

const prior = [-1, 1.3, 1, .25, .55, -.35, -.35, -.15];
const sigmoid = (value: number) => 1 / (1 + Math.exp(-Math.max(-30, Math.min(30, value))));
const dot = (weights: number[], values: number[]) => weights.reduce((sum, weight, i) => sum + weight * values[i], 0);
const validRating = (rating: number) => Number.isInteger(rating) && rating >= 1 && rating <= 5;

export function train(history: Transition[]) {
  const samples = history.flatMap(item => {
    try {
      const x: unknown = JSON.parse(item.features);
      if (!Array.isArray(x) || x.length !== prior.length || !x.every(value => typeof value === 'number' && Number.isFinite(value)) || !validRating(item.rating)) return [];
      return [{ x: x as number[], y: (item.rating - 1) / 4, pair: `${item.from_id}|${item.to_id}` }];
    } catch { return []; }
  });
  const pairs = new Set(samples.map(sample => sample.pair)).size;
  const trained = samples.length >= 8 && pairs >= 3 && new Set(samples.map(sample => sample.y)).size >= 2;
  const weights = [...prior];
  if (trained) {
    for (let epoch = 0; epoch < 400; epoch++) {
      const gradient = weights.map(() => 0);
      for (const sample of samples) {
        const error = sigmoid(dot(weights, sample.x)) - sample.y;
        sample.x.forEach((value, i) => gradient[i] += error * value / samples.length);
      }
      weights.forEach((weight, i) => weights[i] -= .12 * (gradient[i] + .08 * (weight - prior[i])));
    }
  }
  return { weights, trained, samples: samples.length, pairs };
}

export function evaluate(a: Track, b: Track, data: DJData, model = train(data.transitions), goal = 'steady') {
  const vector = features(a, b, data.prep), x = metadata(a, data.prep), y = metadata(b, data.prep);
  const observations = data.transitions.filter(item => item.from_id === a.id && item.to_id === b.id && validRating(item.rating));
  const rhythm = rhythmMatch(x.prep ?? {}, y.prep ?? {});
  const known = vector.slice(5).filter(value => value === 0).length + rhythm.known;
  let value = sigmoid(dot(model.weights, vector));
  if (observations.length) {
    const total = observations.reduce((sum, item) => sum + (item.rating - 1) / 4, 0);
    value = (3 * value + total) / (3 + observations.length);
  }
  if (x.energy !== null && y.energy !== null) {
    const delta = y.energy - x.energy;
    if (goal === 'build') value += delta >= 0 && delta <= 2 ? .08 : -.08;
    if (goal === 'cool') value += delta <= 0 && delta >= -2 ? .08 : -.08;
  }
  value += rhythm.adjustment;
  const reasons: string[] = [...rhythm.reasons];
  if (observations.length) {
    const rating = observations.reduce((sum, item) => sum + item.rating, 0) / observations.length;
    reasons.push(`${observations.length} recorded ${observations.length === 1 ? 'mix' : 'mixes'} · ${rating.toFixed(1)}/5`);
  }
  if (x.bpm !== null && y.bpm !== null) {
    const match = tempoMatch(x.bpm, y.bpm), shift = match.shift * 100;
    reasons.push(`Tempo shift ${shift >= 0 ? '+' : ''}${shift.toFixed(1)}%${match.scale !== 1 ? ' · half/double time' : ''}`);
    if (Math.abs(shift) > 6) reasons.push('Large tempo change: audition a cut or echo out');
  } else reasons.push('BPM missing');
  if (x.key && y.key) {
    reasons.push(harmonic(x.key, y.key) > 0 ? `Keys ${x.key} / ${y.key} compatible` : `Keys ${x.key} / ${y.key}: audition tonal overlap`);
  } else reasons.push('Key missing');
  reasons.push(x.energy !== null && y.energy !== null ? `Energy ${x.energy} → ${y.energy}` : 'Energy unrated');
  const shift = x.bpm !== null && y.bpm !== null ? tempoMatch(x.bpm, y.bpm).shift : null;
  const plan = mixPlan(x.bpm, y.bpm, shift, rhythm, y.prep?.phrase_bars);
  return { track: b, plan, score: known || observations.length ? Math.round(Math.max(0, Math.min(1, value)) * 100) : null, value, reasons, observations: observations.length, known };
}

export function recommend(a: Track, tracks: Track[], data: DJData, goal = 'steady', model = train(data.transitions)) {
  return tracks.filter(track => track.id !== a.id).map(track => evaluate(a, track, data, model, goal))
    .sort((a, b) => (b.score ?? -1) - (a.score ?? -1) || a.track.title.localeCompare(b.track.title));
}

// Bounded beam search: pin the opener, include each member once, retain the original
// order unless a candidate improves the total ranking objective.
export function optimize(tracks: Track[], data: DJData, goal = 'steady', model = train(data.transitions)) {
  if (tracks.length < 3 || tracks.length > 50) return tracks;
  const cache = new Map<string, number>();
  const score = (a: Track, b: Track) => {
    const key = `${a.id}|${b.id}`;
    if (!cache.has(key)) cache.set(key, evaluate(a, b, data, model, goal).value);
    return cache.get(key)!;
  };
  let beam = [{ order: [tracks[0]], remaining: tracks.slice(1), sum: 0 }];
  for (let step = 1; step < tracks.length; step++) {
    beam = beam.flatMap(path => path.remaining.map((track, i) => ({
      order: [...path.order, track], remaining: path.remaining.filter((_, j) => j !== i),
      sum: path.sum + score(path.order[path.order.length - 1], track)
    }))).sort((a, b) => b.sum - a.sum).slice(0, 32);
  }
  const candidate = beam[0].order;
  const quality = (set: Track[]) => set.slice(1).reduce((sum, track, i) => sum + score(set[i], track), 0);
  return quality(candidate) > quality(tracks) + 1e-8 ? candidate : tracks;
}
