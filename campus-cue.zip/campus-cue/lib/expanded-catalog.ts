// Vocal catalog expansion. Artist/title identities checked against official Spotify pages on 2026-10-05.
// Genres are editorial DJ categories. Decades refer to original song eras, not compilations.
export const expandedCatalog = [
  {
    "id": "more-2000-01",
    "title": "Hot In Herre",
    "artist": "Nelly",
    "genre": "Hip-hop",
    "decade": 2000,
    "spotify": "0G2DjUPaDtcaNz4n0sDSTj"
  },
  {
    "id": "more-2000-02",
    "title": "Temperature",
    "artist": "Sean Paul",
    "genre": "Dancehall",
    "decade": 2000,
    "spotify": "6GBJtmoGR4sfZQx6DXZMCE"
  },
  {
    "id": "more-2000-03",
    "title": "In Da Club",
    "artist": "50 Cent",
    "genre": "Hip-hop",
    "decade": 2000,
    "spotify": "3fsghmcEnT7K9f30ohHDRn"
  },
  {
    "id": "more-2000-04",
    "title": "Hey Ya!",
    "artist": "Outkast",
    "genre": "Pop",
    "decade": 2000,
    "spotify": "6miZ4eYyGGpqUwnGmm56tJ"
  },
  {
    "id": "more-2000-05",
    "title": "Get Busy",
    "artist": "Sean Paul",
    "genre": "Dancehall",
    "decade": 2000,
    "spotify": "7kcTg1JOAP2FhEhpINYkbY"
  },
  {
    "id": "more-2000-06",
    "title": "Promiscuous",
    "artist": "Nelly Furtado, Timbaland",
    "genre": "Pop",
    "decade": 2000,
    "spotify": "4LAlw52Iwjd9eOdfkWihyu"
  },
  {
    "id": "more-2000-07",
    "title": "Maneater",
    "artist": "Nelly Furtado",
    "genre": "Pop",
    "decade": 2000,
    "spotify": "4WR7ygsg3oc5rPzJFhp21p"
  },
  {
    "id": "more-2000-08",
    "title": "SexyBack",
    "artist": "Justin Timberlake, Timbaland",
    "genre": "Pop",
    "decade": 2000,
    "spotify": "09vlP0oThhnIvG7WnjIcdJ"
  },
  {
    "id": "more-2000-09",
    "title": "Rock Your Body",
    "artist": "Justin Timberlake",
    "genre": "Pop",
    "decade": 2000,
    "spotify": "6CGXW04Dam75Fjf8e0wyxv"
  },
  {
    "id": "more-2000-10",
    "title": "Gold Digger",
    "artist": "Kanye West, Jamie Foxx",
    "genre": "Hip-hop",
    "decade": 2000,
    "spotify": "1PS1QMdUqOal0ai3Gt7sDQ"
  },
  {
    "id": "more-2000-11",
    "title": "Stronger",
    "artist": "Kanye West",
    "genre": "Hip-hop",
    "decade": 2000,
    "spotify": "21EUxokHa4WQsEtqxAyMT2"
  },
  {
    "id": "more-2000-12",
    "title": "Just Dance",
    "artist": "Lady Gaga, Colby O'Donis",
    "genre": "Dance pop",
    "decade": 2000,
    "spotify": "4Rfq681QHRIHjQZbV8nq9M"
  },
  {
    "id": "more-2000-13",
    "title": "Poker Face",
    "artist": "Lady Gaga",
    "genre": "Dance pop",
    "decade": 2000,
    "spotify": "6rHTPcAlGJoK2sxfUtqMr7"
  },
  {
    "id": "more-2000-14",
    "title": "Bad Romance",
    "artist": "Lady Gaga",
    "genre": "Dance pop",
    "decade": 2000,
    "spotify": "4WtyRMR8BsxybeoPLgWEpM"
  },
  {
    "id": "more-2000-15",
    "title": "Disturbia",
    "artist": "Rihanna",
    "genre": "Dance pop",
    "decade": 2000,
    "spotify": "0caphG80bqllBXD9qCbMlD"
  },
  {
    "id": "more-2000-16",
    "title": "Don't Stop The Music",
    "artist": "Rihanna",
    "genre": "Dance pop",
    "decade": 2000,
    "spotify": "0uMIJoJPp84pVWqwHC0Fgx"
  },
  {
    "id": "more-2000-17",
    "title": "Umbrella",
    "artist": "Rihanna, JAŸ-Z",
    "genre": "R&B",
    "decade": 2000,
    "spotify": "4BwkzkcpUclY30liXhgNRz"
  },
  {
    "id": "more-2000-18",
    "title": "Pon de Replay",
    "artist": "Rihanna",
    "genre": "Dancehall",
    "decade": 2000,
    "spotify": "4TsmezEQVSZNNPv5RJ65Ov"
  },
  {
    "id": "more-2000-19",
    "title": "Hollaback Girl",
    "artist": "Gwen Stefani",
    "genre": "Pop",
    "decade": 2000,
    "spotify": "41VWJ7gCL0Mr7PCTzJ2nL7"
  },
  {
    "id": "more-2000-20",
    "title": "The Sweet Escape",
    "artist": "Gwen Stefani, Akon",
    "genre": "Pop",
    "decade": 2000,
    "spotify": "7lzQAO4S1J3UWwSvmBWYUz"
  },
  {
    "id": "more-2000-21",
    "title": "Gasolina",
    "artist": "Daddy Yankee",
    "genre": "Latin",
    "decade": 2000,
    "spotify": "3DL87tGCPxTLi2deEXHcmU"
  },
  {
    "id": "more-2000-22",
    "title": "Dilemma",
    "artist": "Nelly, Kelly Rowland",
    "genre": "R&B",
    "decade": 2000,
    "spotify": "1sMNuNh58FGMyAAAaGGfns"
  },
  {
    "id": "more-2000-23",
    "title": "Let Me Blow Ya Mind",
    "artist": "Eve, Gwen Stefani, Stevie J",
    "genre": "Hip-hop",
    "decade": 2000,
    "spotify": "4HwXVN9Z3MsVZf27J7bKnN"
  },
  {
    "id": "more-2000-24",
    "title": "One More Time",
    "artist": "Daft Punk",
    "genre": "Dance pop",
    "decade": 2000,
    "spotify": "5PUupBFovMdBj7ldQU3iH5"
  },
  {
    "id": "more-2010-01",
    "title": "Give Me Everything",
    "artist": "Pitbull, Ne-Yo, AFROJACK, Nayer",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "2N22Oy7VDVpNC2NufC8ID8"
  },
  {
    "id": "more-2010-02",
    "title": "Feel This Moment",
    "artist": "Pitbull, Christina Aguilera",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "5OM5D9n4eaL8fqN9vz1yxG"
  },
  {
    "id": "more-2010-03",
    "title": "Dynamite",
    "artist": "Taio Cruz",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "0a9F7IjixPixjunKpOSlLt"
  },
  {
    "id": "more-2010-04",
    "title": "DJ Got Us Fallin’ In Love",
    "artist": "USHER, Pitbull",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "6m8eWMGjog6wnIFyVMtW3D"
  },
  {
    "id": "more-2010-05",
    "title": "OMG",
    "artist": "USHER, will.i.am",
    "genre": "R&B",
    "decade": 2010,
    "spotify": "1bM50INir8voAkVoKuvEUI"
  },
  {
    "id": "more-2010-06",
    "title": "Club Can't Handle Me",
    "artist": "Flo Rida, David Guetta",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "0HHP9LURI6RS0Oqp7mWpKW"
  },
  {
    "id": "more-2010-07",
    "title": "Good Feeling",
    "artist": "Flo Rida",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "52WhASRSsihL7xpb0lD1y7"
  },
  {
    "id": "more-2010-08",
    "title": "Wild Ones",
    "artist": "Flo Rida, Sia",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "73tIrCND7rMyWlQrbHedtP"
  },
  {
    "id": "more-2010-09",
    "title": "Titanium",
    "artist": "David Guetta, Sia",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "0TDLuuLlV54CkRRUOahJb4"
  },
  {
    "id": "more-2010-10",
    "title": "Without You",
    "artist": "David Guetta, USHER",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "1BCqwvROVgc4A292IcYNSl"
  },
  {
    "id": "more-2010-11",
    "title": "Wake Me Up",
    "artist": "Avicii",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "1t3RvAL5Bxv1v72jRhcuc6"
  },
  {
    "id": "more-2010-12",
    "title": "Hey Brother",
    "artist": "Avicii",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "4lhqb6JvbHId48OUJGwymk"
  },
  {
    "id": "more-2010-13",
    "title": "Waiting For Love",
    "artist": "Avicii",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "5iUdANrZPYNpnc0qkwFo1o"
  },
  {
    "id": "more-2010-14",
    "title": "Summer",
    "artist": "Calvin Harris",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "3yM5E60FwJs3QYw9DXgE0w"
  },
  {
    "id": "more-2010-15",
    "title": "This Is What You Came For",
    "artist": "Calvin Harris, Rihanna",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "0azC730Exh71aQlOt9Zj3y"
  },
  {
    "id": "more-2010-16",
    "title": "Lean On",
    "artist": "Major Lazer, DJ Snake, MØ",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "04jQmBNUOrUD6fMnR8yHAp"
  },
  {
    "id": "more-2010-17",
    "title": "Closer",
    "artist": "The Chainsmokers, Halsey",
    "genre": "Dance pop",
    "decade": 2010,
    "spotify": "5KWrd0IWVkdpMal3WTZQFw"
  },
  {
    "id": "more-2010-18",
    "title": "Shake It Off",
    "artist": "Taylor Swift",
    "genre": "Pop",
    "decade": 2010,
    "spotify": "6PRELLjOe8RaRIcW0sHskx"
  },
  {
    "id": "more-2010-19",
    "title": "Blank Space",
    "artist": "Taylor Swift",
    "genre": "Pop",
    "decade": 2010,
    "spotify": "6hKd5ajbkYvzIJCEqj8SP1"
  },
  {
    "id": "more-2010-20",
    "title": "Call Me Maybe",
    "artist": "Carly Rae Jepsen",
    "genre": "Pop",
    "decade": 2010,
    "spotify": "4gkeknIpnbtIMxZvr3Ytlw"
  },
  {
    "id": "more-2010-21",
    "title": "Starships",
    "artist": "Nicki Minaj",
    "genre": "Pop",
    "decade": 2010,
    "spotify": "7yTZk1LMxRY9fdyk0DIls7"
  },
  {
    "id": "more-2010-22",
    "title": "SICKO MODE",
    "artist": "Travis Scott",
    "genre": "Hip-hop",
    "decade": 2010,
    "spotify": "2xLMifQCjDGFmkHkpNLD9h"
  },
  {
    "id": "more-2010-23",
    "title": "Mo Bamba",
    "artist": "Sheck Wes",
    "genre": "Hip-hop",
    "decade": 2010,
    "spotify": "37GEi7n9KFNLtIgrzKGtwU"
  },
  {
    "id": "more-2010-24",
    "title": "No Hands",
    "artist": "Waka Flocka Flame, Roscoe Dash, Wale",
    "genre": "Hip-hop",
    "decade": 2010,
    "spotify": "5JMvfls2N5FxalMqgnHYP3"
  },
  {
    "id": "more-2020-01",
    "title": "Take My Breath",
    "artist": "The Weeknd",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "4sppN8SrNShUme9oJueg8D"
  },
  {
    "id": "more-2020-02",
    "title": "Save Your Tears",
    "artist": "The Weeknd",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "4ChctXJ6UBHNJOg1Pspdxe"
  },
  {
    "id": "more-2020-03",
    "title": "Physical",
    "artist": "Dua Lipa",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "5M0vVGFryHrNlEr09G31wA"
  },
  {
    "id": "more-2020-04",
    "title": "Break My Heart",
    "artist": "Dua Lipa",
    "genre": "Dance pop",
    "decade": 2020,
    "spotify": "1AQ7kKcX7MBSq7Vndoprkp"
  },
  {
    "id": "more-2020-05",
    "title": "Dance The Night",
    "artist": "Dua Lipa",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "72IziSG4tVHM68tjZYB7Rk"
  },
  {
    "id": "more-2020-06",
    "title": "Cold Heart",
    "artist": "Elton John, Dua Lipa, PNAU",
    "genre": "Dance pop",
    "decade": 2020,
    "spotify": "01683LCZhai6X1dGuT5j1K"
  },
  {
    "id": "more-2020-07",
    "title": "I'm Good (Blue)",
    "artist": "David Guetta, Bebe Rexha",
    "genre": "Dance pop",
    "decade": 2020,
    "spotify": "3ajNxs5h37z331dkpNISxP"
  },
  {
    "id": "more-2020-08",
    "title": "STAY",
    "artist": "The Kid LAROI, Justin Bieber",
    "genre": "Dance pop",
    "decade": 2020,
    "spotify": "4NnAWVhgBclqbEpaIvKsVS"
  },
  {
    "id": "more-2020-09",
    "title": "INDUSTRY BABY",
    "artist": "Lil Nas X, Jack Harlow",
    "genre": "Hip-hop",
    "decade": 2020,
    "spotify": "0Dkviqf6u4mfF44MXCsvs6"
  },
  {
    "id": "more-2020-10",
    "title": "Kiss Me More",
    "artist": "Doja Cat, SZA",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "60s4Uak8Q4OUtrWbfFj2s4"
  },
  {
    "id": "more-2020-11",
    "title": "Paint The Town Red",
    "artist": "Doja Cat",
    "genre": "Hip-hop",
    "decade": 2020,
    "spotify": "5BdQrYp80FaLIp8chmpOoX"
  },
  {
    "id": "more-2020-12",
    "title": "First Class",
    "artist": "Jack Harlow",
    "genre": "Hip-hop",
    "decade": 2020,
    "spotify": "5Viqw6oDMxc3Thh04WXC5b"
  },
  {
    "id": "more-2020-13",
    "title": "Lovin On Me",
    "artist": "Jack Harlow",
    "genre": "Hip-hop",
    "decade": 2020,
    "spotify": "3l2FxJ5M6w5ePOnqtpe0CR"
  },
  {
    "id": "more-2020-14",
    "title": "Super Freaky Girl",
    "artist": "Nicki Minaj",
    "genre": "Hip-hop",
    "decade": 2020,
    "spotify": "3K7Fm9tTxSN2ZoMNWR8Q9D"
  },
  {
    "id": "more-2020-15",
    "title": "WAP",
    "artist": "Cardi B, Megan Thee Stallion",
    "genre": "Hip-hop",
    "decade": 2020,
    "spotify": "4Vo8jBpQTrm22sewNrYlKT"
  },
  {
    "id": "more-2020-16",
    "title": "Flowers",
    "artist": "Miley Cyrus",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "7DSAEUvxU8FajXtRloy8M0"
  },
  {
    "id": "more-2020-17",
    "title": "good 4 u",
    "artist": "Olivia Rodrigo",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "55NXq7JA1EN2Kn9fGDqlO4"
  },
  {
    "id": "more-2020-18",
    "title": "Water",
    "artist": "Tyla",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "5aIVCx5tnk0ntmdiinnYvw"
  },
  {
    "id": "more-2020-19",
    "title": "Please Please Please",
    "artist": "Sabrina Carpenter",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "67gyaiQkGTvdMbKm0st3vr"
  },
  {
    "id": "more-2020-20",
    "title": "Taste",
    "artist": "Sabrina Carpenter",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "0PycLn9BRFX2yhxd3RGwGK"
  },
  {
    "id": "more-2020-21",
    "title": "APT.",
    "artist": "ROSÉ, Bruno Mars",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "251TRoW27SWCAoQXWfoK6T"
  },
  {
    "id": "more-2020-22",
    "title": "Beautiful Things",
    "artist": "Benson Boone",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "1gG24Dfm4G6IdvXNfo1KzX"
  },
  {
    "id": "more-2020-23",
    "title": "Die With A Smile",
    "artist": "Lady Gaga, Bruno Mars",
    "genre": "Pop",
    "decade": 2020,
    "spotify": "4AwDaa96PLDhkognqMkt4w"
  },
  {
    "id": "more-2020-24",
    "title": "yes, and?",
    "artist": "Ariana Grande",
    "genre": "Dance pop",
    "decade": 2020,
    "spotify": "7gaA3wERFkFkgivjwbSvkG"
  }
] as const;

