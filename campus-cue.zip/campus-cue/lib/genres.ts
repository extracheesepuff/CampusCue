// One list for upload validation and the form. Library filters use genres present.
export const genres = [
  'Pop', 'Dance pop', 'Hip-hop', 'Southern hip-hop', 'Trap', 'Crunk', 'Snap',
  'Atlanta bass', 'R&B', 'Funk', 'Disco', 'Rock', 'Alternative rock', 'Country',
  'Afrobeats', 'Latin', 'Latin dance', 'Reggaeton', 'Merengue', 'Dancehall',
  'House', 'Deep House', 'Techno', 'Lo-fi', 'UK Garage', 'Electronic', 'Other'
] as const;
