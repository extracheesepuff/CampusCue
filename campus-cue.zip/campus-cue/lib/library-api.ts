export async function request(body: unknown) {
  const r = await fetch('/api/library', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  const d = (await r.json()) as {
    error?: string;
    ok?: boolean;
    id: string;
  };
  if (!r.ok) throw new Error(d.error || 'Could not save.');
  return d;
}
