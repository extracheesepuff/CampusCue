import type { Track } from './types';
import { searchTracks, type SearchScope } from './search.ts';
import { catalogContext } from './catalog-context.ts';
export type LibraryFilters = {
  query: string; scope: SearchScope; era: string; genre: string; source: string;
  sort: string; liked: boolean; collection: string;
};
export const defaultFilters: LibraryFilters = {
  query: '', scope: 'all', era: 'all', genre: 'all', source: 'all',
  sort: 'match', liked: false, collection: 'all'
};
const genreFamilies: Record<string, string[]> = {
  'Hip-hop': ['Hip-hop', 'Southern hip-hop', 'Trap', 'Crunk', 'Snap', 'Atlanta bass'],
  Latin: ['Latin', 'Latin dance', 'Reggaeton', 'Merengue'],
  Rock: ['Rock', 'Alternative rock'],
  Pop: ['Pop', 'Dance pop']
};
export const genreLabel = (genre: string) => genreFamilies[genre] ? `${genre} · all styles` : genre;
export const eraLabel = (era: string) => era === 'classic' ? 'Before 2000' : `${era}s`;
export const eraMatches = (track: Track, era: string) => era === 'all' || (era === 'classic'
  ? track.decade !== null && track.decade < 2000 : String(track.decade) === era);
export function libraryResults(tracks: Track[], filters: LibraryFilters, isLiked: (id: string) => boolean) {
  const filtered = tracks.filter(track =>
    eraMatches(track, filters.era) &&
    (filters.genre === 'all' || (genreFamilies[filters.genre] ?? [filters.genre]).includes(track.genre)) &&
    (filters.collection === 'all' || catalogContext(track.id)?.collections.includes(filters.collection)) &&
    (filters.source === 'all' || (filters.source === 'spotify' ? !!track.spotify_id : !track.spotify_id)) &&
    (!filters.liked || isLiked(track.id)));
  const results = searchTracks(filtered, filters.query, filters.scope);
  // Copy before sorting: search with a blank query returns its input.
  if (filters.sort === 'bpm') return [...results].sort((a, b) => (a.bpm ?? Infinity) - (b.bpm ?? Infinity) || a.title.localeCompare(b.title));
  if (filters.sort === 'popular') return [...results].sort((a, b) => b.plays - a.plays || b.likes - a.likes || a.title.localeCompare(b.title));
  if (filters.sort === 'title' || (filters.sort === 'match' && !filters.query.trim())) return [...results].sort((a, b) => a.title.localeCompare(b.title));
  return results;
}
