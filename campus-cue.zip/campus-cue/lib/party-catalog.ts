// Vocal recordings matched to Spotify listings; eras follow the original song.
// These are editorial browsing groups, not measured crowd rankings or verified mixes.
export const partyCatalog = [
  ['back', 'Back That Azz Up', 'JUVENILE, Lil Wayne, Mannie Fresh', 'Southern hip-hop', 1990, '6o2g1BJvtYQssH84kBYs7y', 'rap', 'homecoming'],
  ['whistle', 'Blow the Whistle', 'Too $hort', 'Hip-hop', 2000, '5vh1p3zMUPeMcMk3t8okoU', 'rap', 'homecoming'],
  ['lollipop', 'Lollipop', 'Lil Wayne, Static Major', 'Hip-hop', 2000, '6NWMLhhrl4FyJf3AAHQ7Ky', 'rap', 'homecoming'],
  ['aah', 'Say Aah (feat. Fabolous)', 'Trey Songz, Fabolous', 'R&B', 2000, '4zVl2Hv9qesl5GkdaThyKl', 'rap', 'homecoming'],
  ['freek', 'Freek-a-Leek', 'Petey Pablo', 'Crunk', 2000, '0PMkcU8Ych7TgXfTmiTz2G', 'rap', 'homecoming'],
  ['look', "Look At Me Now (feat. Lil' Wayne & Busta Rhymes)", 'Chris Brown, Lil Wayne, Busta Rhymes', 'Hip-hop', 2010, '1S9nmPHoG5FfAqITgn1JGS', 'rap', 'homecoming'],
  ['hotel', 'Hotel Room Service', 'Pitbull', 'Hip-hop', 2000, '6ABMQfhmYlSzRZLsdu2jq0', 'bar', 'ryeski'],
  ['time', 'Time of Our Lives', 'Pitbull, Ne-Yo', 'Dance pop', 2010, '2bJvI42r8EF3wxjOuDav4r', 'bar', 'ryeski'],
  ['gone', 'Since U Been Gone', 'Kelly Clarkson', 'Pop', 2000, '6JY1IdkZGeIcPegKxjSKeb', 'bar', 'ryeski'],
  ['way', 'I Want It That Way', 'Backstreet Boys', 'Pop', 1990, '47BBI51FKFwOMlIiX6m8ya', 'bar', 'ryeski'],
  ['love', 'Love Story', 'Taylor Swift', 'Country', 2000, '2YtZIbuVU5cgLiHMvpHWOL', 'bar', 'ryeski'],
  ['belong', 'You Belong With Me', 'Taylor Swift', 'Country', 2000, '2JTqsUGnGAZ6aGi9wKQgmS', 'bar', 'ryeski'],
  ['tik', 'TiK ToK', 'Kesha', 'Dance pop', 2000, '6y8SHJSkG6WEDNUJZ249Uj', 'bar', 'ryeski'],
  ['pony', 'Pink Pony Club', 'Chappell Roan', 'Pop', 2020, '6393yGahSJ9slVdOwSxOVR', 'bar', 'ryeski'],
  ['pump', 'Pump It', 'Black Eyed Peas', 'Hip-hop', 2000, '2ygMBIctKIAfbEBcT9065L', 'bar', 'ryeski'],
  ['up', 'Party Up', 'DMX', 'Hip-hop', 2000, '0LWkaEyQRkF0XAms8Bg1fC', 'rap', 'ryeski']
].map(([id, title, artist, genre, decade, spotify, collection, evidence]) => ({
  id: `party-${id}`, title: String(title), artist: String(artist), genre: String(genre),
  decade: Number(decade), spotify: String(spotify), collection: String(collection), evidence: String(evidence)
}));
export const partySets = [
  { id: 'party-rap', name: 'Frat party · rap picks', ids: ['atl-swag', 'atl-knuck', 'atl-get-low', 'more-2010-24', ...partyCatalog.filter(t => t.collection === 'rap').map(t => t.id)] },
  { id: 'party-bar', name: 'College bar · singalong picks', ids: ['atl-brightside', 'atl-usa', 'atl-wagon', 'atl-believin', ...partyCatalog.filter(t => t.collection === 'bar').map(t => t.id)] }
];
