// Only the player subscribes to time changes; the library stays untouched.
export function createPlaybackClock() {
  let time = 0;
  const listeners = new Set<() => void>();
  return {
    getSnapshot: () => time,
    subscribe(listener: () => void) {
      listeners.add(listener);
      return () => { listeners.delete(listener); };
    },
    set(next: number) {
      if (!Number.isFinite(next) || next < 0 || next === time) return;
      time = next;
      listeners.forEach(listener => listener());
    }
  };
}
export type PlaybackClock = ReturnType<typeof createPlaybackClock>;
