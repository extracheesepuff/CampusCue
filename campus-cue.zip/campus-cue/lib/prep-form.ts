import type { Prep } from './dj-model';
import type { Track } from './types';
export const formatCue = (seconds: number | null | undefined) => seconds == null ? '' : `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
export function parseCue(value: string): number | null {
  const text = value.trim();
  if (!text) return null;
  let seconds: number;
  if (/^\d+$/.test(text)) seconds = Number(text);else if (/^\d{1,3}:[0-5]\d$/.test(text)) {
    const [minutes, remainder] = text.split(':').map(Number);
    seconds = minutes * 60 + remainder;
  } else throw new Error('Enter cues as seconds or m:ss, such as 32 or 0:32.');
  if (seconds > 7200) throw new Error('Cue points must be within two hours.');
  return seconds;
}
export function prepRequest(form: FormData, track: Track, saved?: Prep) {
  const number = (name: string) => String(form.get(name) ?? '').trim() ? Number(form.get(name)) : null;
  const cueIn = parseCue(String(form.get('cueIn') ?? ''));
  const cueOut = parseCue(String(form.get('cueOut') ?? ''));
  if (cueIn !== null && cueOut !== null && cueOut <= cueIn) throw new Error('Mix-out must come after mix-in.');
  if (!track.spotify_id && [cueIn, cueOut].some(cue => cue !== null && cue > track.duration)) throw new Error('Cue exceeds the uploaded audio length.');
  return {
    action: 'prep',
    trackId: track.id,
    revision: saved?.revision ?? -1,
    bpm: number('bpm'),
    camelot: form.get('key') || null,
    energy: number('energy'),
    cueIn,
    cueOut,
    notes: String(form.get('notes') ?? ''),
    groove: form.get('groove') || null,
    phraseBars: number('phraseBars'),
    introVocals: form.get('introVocals') || null,
    outroVocals: form.get('outroVocals') || null
  };
}
