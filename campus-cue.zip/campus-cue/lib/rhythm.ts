// Optional details describe the section you intend to mix, not the whole recording.
export const grooves = ['Four on the floor', 'Breakbeat', 'Half-time', 'Shuffle'] as const;
export const vocalLevels = ['Clear', 'Sparse', 'Busy'] as const;
export type Rhythm = {
  groove?: string | null; phrase_bars?: number | null;
  intro_vocals?: string | null; outro_vocals?: string | null;
};
export function rhythmMatch(from: Rhythm, into: Rhythm) {
  const reasons: string[] = [];
  let adjustment = 0, known = 0;
  if (from.groove && into.groove) {
    known++;
    const same = from.groove === into.groove;
    adjustment += same ? .06 : -.04;
    reasons.push(same ? `Matching groove · ${from.groove}` : `${from.groove} → ${into.groove}: audition the drum change`);
  }
  const vocalKnown = !!from.outro_vocals && !!into.intro_vocals;
  const clash = from.outro_vocals === 'Busy' && into.intro_vocals === 'Busy';
  if (vocalKnown) {
    known++;
    adjustment += clash ? -.1 : from.outro_vocals === 'Clear' || into.intro_vocals === 'Clear' ? .04 : 0;
    reasons.push(clash ? 'Busy vocals overlap: cut or echo out before the next vocal' : 'Vocal sections leave room: check the entries by ear');
  }
  if (from.phrase_bars && into.phrase_bars) {
    reasons.push(`Align phrase starts · outgoing ${from.phrase_bars} / incoming ${into.phrase_bars} bars`);
  }
  return { adjustment, known, clash, reasons };
}
export function mixPlan(fromBpm: number | null, intoBpm: number | null, shift: number | null, rhythm: ReturnType<typeof rhythmMatch>, bars?: number | null) {
  if (rhythm.clash) return 'Try a cut or short echo at the phrase boundary; bring the next vocal in after the outgoing line.';
  if (shift !== null && Math.abs(shift) > .06) return 'Try an echo out or cut on a phrase boundary. Audition the tempo change before playing live.';
  if (fromBpm !== null && intoBpm !== null && shift !== null) {
    return `Try a ${bars ?? 16}-bar blend${bars ? '' : ' as a starting point'}: align phrase starts, match beats, and swap bass gradually. Check vocals and key by ear.`;
  }
  return 'Prep BPM and the sections you will mix, then audition the transition before choosing a technique.';
}
// Robust against one mistimed tap. A pause starts a new estimate.
export function tappedBpm(taps: number[]): number | null {
  if (taps.length < 4) return null;
  const intervals = taps.slice(1).map((time, i) => time - taps[i]).sort((a, b) => a - b);
  if (intervals.some(value => !Number.isFinite(value) || value <= 0)) return null;
  const middle = Math.floor(intervals.length / 2);
  const interval = intervals.length % 2 ? intervals[middle] : (intervals[middle - 1] + intervals[middle]) / 2;
  const bpm = 60000 / interval;
  return bpm >= 40 && bpm <= 240 ? Math.round(bpm * 10) / 10 : null;
}
