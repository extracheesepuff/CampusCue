import { collectionWords } from './catalog-context.ts';
import type { Track } from './types';

export type SearchScope = 'all' | 'title' | 'artist';

// Normalize spelling variants and common artist stylization; keep word boundaries.
export function normalizeSearch(value: string): string {
  return value.normalize('NFKD').replace(/\p{M}/gu, '').toLowerCase()
    .replace(/\b(?:[a-z]\.){2,}/g, initials => initials.replace(/\./g, ''))
    .replace(/(\p{L})!(?=\p{L})/gu, '$1i')
    .replace(/(\p{L})\$(?=\p{L})/gu, '$1s')
    .replace(/swag\s+surfing/g, 'swag surfin').replace(/['’‘]/g, '').replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

export function searchTracks(tracks: Track[], query: string, scope: SearchScope = 'all'): Track[] {
  const text = normalizeSearch(query);
  if (!text) return tracks;
  const words = text.split(/\s+/);
  const candidates = tracks.map(track => {
    const title = normalizeSearch(track.title);
    const artist = normalizeSearch(track.creator);
    const haystack = scope === 'title' ? title : scope === 'artist' ? artist
      : normalizeSearch(`${track.title} ${track.creator} ${track.genre} ${track.decade ? `${track.decade}s` : 'upload'} ${track.musical_key} ${track.dj_notes ?? ''} ${collectionWords(track.id)}`);
    const rank = title === text ? 4 : title.startsWith(text) ? 3 : artist === text ? 2 : artist.startsWith(text) ? 1 : 0;
    return { track, matches: words.every(word => haystack.includes(word)), rank };
  });
  return candidates.filter(item => item.matches)
    .sort((a, b) => b.rank - a.rank || a.track.title.localeCompare(b.track.title))
    .map(item => item.track);
}
