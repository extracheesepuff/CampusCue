import { atlantaCatalog } from './atlanta-catalog';
export async function seedAtlanta(db: D1Database, flags?: ReadonlySet<string>) {
  const flag = 'atlanta-v1';
  if (flags ? flags.has(flag) : await db.prepare('SELECT id FROM app_state WHERE id=?').bind(flag).first()) return;
  // Each statement stays below D1's parameter limit; the batch commits atomically.
  await db.batch([
    ...atlantaCatalog.map(t => db.prepare('INSERT OR IGNORE INTO creators (id,name,normalized_name) VALUES (?,?,?)')
      .bind(`artist-${t.id}`, t.artist, t.artist.toLowerCase())),
    ...atlantaCatalog.map(t => db.prepare(`INSERT OR IGNORE INTO tracks
      (id,creator_id,title,genre,bpm,musical_key,duration,demo_url,is_demo,spotify_id,decade)
      SELECT ?,id,?,?,40,'Not analyzed',1,?,0,?,? FROM creators WHERE normalized_name=?`)
      .bind(t.id, t.title, t.genre, `https://open.spotify.com/track/${t.spotify}`, t.spotify, t.decade, t.artist.toLowerCase())),
    // Correct the missing featured-artist credit without changing the recording ID.
    db.prepare('INSERT OR IGNORE INTO creators (id,name,normalized_name) VALUES (?,?,?)')
      .bind('artist-guetta-usher', 'David Guetta, USHER', 'david guetta, usher'),
    db.prepare('UPDATE tracks SET creator_id=(SELECT id FROM creators WHERE normalized_name=?) WHERE id=? AND spotify_id=?')
      .bind('david guetta, usher', 'more-2010-10', '1BCqwvROVgc4A292IcYNSl'),
    db.prepare('INSERT OR IGNORE INTO app_state (id) VALUES (?)').bind(flag)
  ]);
}
