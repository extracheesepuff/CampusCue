import { djCatalog, djCollections } from './dj-catalog';
export async function seedDJ(db: D1Database, flags?: ReadonlySet<string>) {
  // Single atomic, one-time addition: never restore sets after a user deletes them.
  const flag = 'dj-collections-v1';
  if (flags ? flags.has(flag) : await db.prepare('SELECT id FROM app_state WHERE id=?').bind(flag).first()) return;
  await db.batch([
    ...djCatalog.map(track => db.prepare('INSERT OR IGNORE INTO creators (id,name,normalized_name) VALUES (?,?,?)')
      .bind(`artist-${track.id}`, track.artist, track.artist.toLowerCase())),
    ...djCatalog.map(track => db.prepare(`INSERT OR IGNORE INTO tracks (id,creator_id,title,genre,bpm,musical_key,duration,demo_url,is_demo,spotify_id,decade)
      SELECT ?,id,?,?,40,'Not analyzed',1,?,0,?,? FROM creators WHERE normalized_name=?`)
      .bind(track.id, track.title, track.genre, `https://open.spotify.com/track/${track.spotify}`, track.spotify, track.decade, track.artist.toLowerCase())),
    ...djCollections.map(collection => db.prepare('INSERT OR IGNORE INTO playlists (id,user_id,name,description) VALUES (?,?,?,?)')
      .bind(collection.id, 'owner', `${collection.artist} · vocal picks`, 'Campus Cue artist collection. Selected vocal originals and collaborations; editable, with no claim to a live set order or artist endorsement.')),
    ...djCollections.flatMap(collection => collection.ids.map((id, position) => db.prepare('INSERT OR IGNORE INTO playlist_tracks (playlist_id,track_id,position) VALUES (?,?,?)')
      .bind(collection.id, id, position))),
    db.prepare('INSERT OR IGNORE INTO app_state (id) VALUES (?)').bind(flag)
  ]);
}
