import { partyCatalog, partySets } from './party-catalog';
export async function seedParty(db: D1Database, flags?: ReadonlySet<string>) {
  const flag = 'party-catalog-v1';
  if (flags ? flags.has(flag) : await db.prepare('SELECT id FROM app_state WHERE id=?').bind(flag).first()) return;
  // Atomic, one-time addition: deleted or edited picks are never restored on reload.
  await db.batch([
    ...partyCatalog.map(t => db.prepare('INSERT OR IGNORE INTO creators (id,name,normalized_name) VALUES (?,?,?)')
      .bind(`artist-${t.id}`, t.artist, t.artist.toLowerCase())),
    ...partyCatalog.map(t => db.prepare(`INSERT OR IGNORE INTO tracks
      (id,creator_id,title,genre,bpm,musical_key,duration,demo_url,is_demo,spotify_id,decade)
      SELECT ?,id,?,?,40,'Not analyzed',1,?,0,?,? FROM creators WHERE normalized_name=?`)
      .bind(t.id, t.title, t.genre, `https://open.spotify.com/track/${t.spotify}`, t.spotify, t.decade, t.artist.toLowerCase())),
    ...partySets.map(set => db.prepare('INSERT OR IGNORE INTO playlists (id,user_id,name,description) VALUES (?,?,?,?)')
      .bind(set.id, 'owner', set.name, 'Editable party shortlist sourced from published DJ tracklists. Starter order; audition versions and prepare BPM/key before mixing.')),
    ...partySets.flatMap(set => set.ids.map((id, position) => db.prepare(`INSERT OR IGNORE INTO playlist_tracks (playlist_id,track_id,position)
      SELECT ?,id,? FROM tracks WHERE id=?`).bind(set.id, position, id))),
    db.prepare('INSERT OR IGNORE INTO app_state (id) VALUES (?)').bind(flag)
  ]);
}
