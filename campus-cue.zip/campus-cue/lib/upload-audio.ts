export async function uploadAudio(form: FormData) {
  const file = form.get('audio');
  if (!(file instanceof File) || !file.size) throw new Error('Choose an audio file.');
  if (file.size > 20 * 1024 * 1024) throw new Error('File must be 20 MB or smaller.');
  const duration = await new Promise<number>((resolve, reject) => {
    const url = URL.createObjectURL(file),
      audio = new Audio();
    const cleanup = () => {
      clearTimeout(timer);
      audio.onloadedmetadata = null;
      audio.onerror = null;
      audio.src = '';
      URL.revokeObjectURL(url);
    };
    const timer = setTimeout(() => {
      cleanup();
      reject(new Error('Could not read audio duration. Try another file.'));
    }, 10000);
    audio.onloadedmetadata = () => {
      const duration = audio.duration;
      cleanup();
      Number.isFinite(duration) && duration > 0 ? resolve(duration) : reject(new Error('Invalid audio duration.'));
    };
    audio.onerror = () => {
      cleanup();
      reject(new Error('This audio file cannot be played by your browser.'));
    };
    audio.src = url;
  });
  form.set('duration', String(duration));
  const response = await fetch('/api/library', {
    method: 'POST',
    body: form
  });
  const data = (await response.json()) as {
    error?: string;
  };
  if (!response.ok) throw new Error(data.error || 'Upload failed.');
}
