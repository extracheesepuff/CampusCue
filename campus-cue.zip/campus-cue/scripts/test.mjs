import { spawnSync } from 'node:child_process';
const tests = ['search', 'dj-model', 'inputs', 'rhythm', 'discovery', 'performance', 'built'];
for (const test of tests) {
  const result = spawnSync(process.execPath, ['--experimental-strip-types', `scripts/verify-${test}.mjs`], { stdio: 'inherit' });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status ?? 1);
}
