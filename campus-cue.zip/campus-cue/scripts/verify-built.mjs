import { createRequire } from 'node:module';
import { resolve } from 'node:path';
import { readFile, readdir } from 'node:fs/promises';
import assert from 'node:assert/strict';
import { partyCatalog, partySets } from '../lib/party-catalog.ts';
import { atlantaCatalog } from '../lib/atlanta-catalog.ts';
import { randomUUID } from 'node:crypto';
const require=createRequire(import.meta.url);
const miniflareDir=(await readdir('node_modules/.pnpm')).find(n=>n.startsWith('miniflare@'));
const { Miniflare }=await import(resolve('node_modules/.pnpm',miniflareDir,'node_modules/miniflare/dist/src/index.js'));
async function moduleFiles(dir){const entries=await readdir(dir,{withFileTypes:true});return (await Promise.all(entries.map(e=>e.isDirectory()?moduleFiles(resolve(dir,e.name)):/\.(m?js)$/.test(e.name)?[resolve(dir,e.name)]:[]))).flat();}
const main=resolve('dist/server/index.js');
const modules=[main,...(await moduleFiles(resolve('dist/server'))).filter(p=>p!==main)].map(path=>({type:'ESModule',path}));
const mf=new Miniflare({modules,compatibilityDate:'2026-05-15',compatibilityFlags:['nodejs_compat'],d1Databases:{DB:'test-db'},r2Buckets:['BUCKET'],assets:{directory:resolve('dist/client'),binding:'ASSETS',routerConfig:{has_user_worker:true}}});
let checks=0;
const check=(value,message)=>{assert(value,message);checks++;};
const call=async(path='/api/library',payload,headers={})=>{const response=await mf.dispatchFetch('http://test.local'+path,{method:payload?'POST':'GET',headers:payload?{'Content-Type':'application/json',...headers}:headers,body:payload?JSON.stringify(payload):undefined});const text=await response.text();try{return {status:response.status,data:JSON.parse(text)};}catch{throw new Error(`Non-JSON response: ${response.status} ${path} ${text.slice(0,500)}`);}};
const post=(action,args={})=>call('/api/library',{action,...args});
const snap=async()=>{const r=await call();check(r.status===200,'Snapshot loads');return r.data;};
try{
 const db=await mf.getD1Database('DB');
 const apply=async(file)=>{const sql=await readFile(file,'utf8');for(const stmt of sql.split('--> statement-breakpoint').map(s=>s.trim()).filter(Boolean))await db.prepare(stmt).run();};
 await apply('drizzle/0000_uneven_rogue.sql');
 // Simulate existing production records before applying the additive migration.
 await db.batch([
 db.prepare("INSERT INTO users (id,name) VALUES ('owner','Brad')"),
 db.prepare("INSERT INTO users (id,name) VALUES ('legacy-user','Existing listener')"),
 db.prepare("INSERT INTO creators (id,name,normalized_name) VALUES ('legacy-creator','Existing artist','existing artist')"),
 db.prepare("INSERT INTO tracks (id,creator_id,title,genre,bpm,musical_key,duration,audio_key) VALUES ('legacy-audio','legacy-creator','Existing upload','House',118,'A minor',24,'legacy.wav')"),
 db.prepare("INSERT INTO playlists (id,user_id,name) VALUES ('legacy-set','owner','Existing set')"),
 db.prepare("INSERT INTO playlist_tracks (playlist_id,track_id,position) VALUES ('legacy-set','legacy-audio',0)"),
 db.prepare("INSERT INTO favorites (user_id,track_id) VALUES ('legacy-user','legacy-audio')"),
 db.prepare("INSERT INTO app_state (id) VALUES ('initialized')")
 ]);
 await apply('drizzle/0001_complete_next_avengers.sql');
 await apply('drizzle/0002_married_wolf_cub.sql');
 await apply('drizzle/0003_flawless_forgotten_one.sql');
 const base=await snap();
 check(base.tracks.filter(t=>t.spotify_id).length===154,'154 vocal catalog tracks');
 check([2000,2010,2020].every((e,i)=>base.tracks.filter(t=>t.decade===e).length===[30,36,32][i]+atlantaCatalog.filter(t=>t.decade===e).length+partyCatalog.filter(t=>t.decade===e).length),'Original decade catalog and DJ additions present');
 check(base.tracks.every(t=>!t.is_demo),'Instrumental demos excluded');
 check(base.tracks.filter(t=>t.spotify_id).every(t=>t.bpm===null&&t.duration===0&&t.musical_key===''),'Unverified catalog tempo, key, duration not exposed as facts');
 check(base.stats.plays===0,'No fabricated listening activity');
 check(base.tracks.some(t=>t.id==='legacy-audio'&&t.bpm===118),'Existing uploaded metadata preserved');
 check(base.items.some(i=>i.playlist_id==='legacy-set'&&i.track_id==='legacy-audio'),'Existing playlist preserved');
 check(base.favorites.some(f=>f.user_id==='legacy-user'&&f.track_id==='legacy-audio'),'Existing likes preserved');
 check(base.users.some(u=>u.id==='legacy-user'),'Existing listeners preserved');
 check(base.items.filter(i=>i.playlist_id.startsWith('era-')).length===18,'Three ordered era sets seeded');
 check(new Set(base.tracks.filter(t=>t.spotify_id).map(t=>t.spotify_id)).size===154,'Catalog track links unique');
 check(base.playlists.filter(p=>p.id.startsWith('dj-')).length===5,'Five DJ artist collections seeded');
 check(base.items.filter(i=>i.playlist_id.startsWith('dj-')).length===18,'DJ collections contain intended vocal selections');
 check(base.items.filter(i=>i.playlist_id==='dj-guetta').every(i=>base.tracks.find(t=>t.id===i.track_id).creator.includes('David Guetta')),'Guetta collection contains Guetta collaborations');
 check(atlantaCatalog.every(t=>base.tracks.some(row=>row.id===t.id&&row.genre===t.genre&&row.spotify_id===t.spotify)),'All 40 researched additions preserve title-linked IDs and genres');
 check(base.tracks.filter(t=>t.decade<2000&&t.decade!==null).length===10,'Older vocal singalongs retain their original eras');
 check(base.tracks.find(t=>t.id==='more-2010-10').creator==='David Guetta, USHER','Featured-artist correction preserves existing track identity');
 check(partyCatalog.every(t=>base.tracks.some(row=>row.id===t.id&&row.spotify_id===t.spotify&&row.genre===t.genre)),'All party recordings are seeded');
 check(partySets.every(set=>base.items.filter(i=>i.playlist_id===set.id).length===set.ids.length),'Party shortlists contain their intended picks');
 const again=await snap();check(again.tracks.filter(t=>t.spotify_id).length===154,'Reload does not duplicate expanded tracks');
 const html=await mf.dispatchFetch('http://test.local/');const text=await html.text();check(html.status===200&&text.includes('Plan the next set')&&text.includes('Mix planner'),'Redesigned product page renders');
 const css=await readFile('app/globals.css','utf8');check(css.includes('era-strip')&&css.includes('spotify-dock')&&css.includes('@media(max-width:620px)'),'Era controls, listening dock, and responsive styling present');
 let r=await post('createPlaylist',{name:'Test set',description:'Local only'});check(r.status===201,'Create playlist');const pid=r.data.id;
 for(const tid of ['y2k-yeah','2010-love','2020-espresso'])check((await post('addTrack',{playlistId:pid,trackId:tid})).status===200,'Add vocal track');
 check((await post('addTrack',{playlistId:pid,trackId:'y2k-yeah'})).status===200,'Duplicate insertion idempotent');
 let d=await snap();check(d.items.filter(i=>i.playlist_id===pid).length===3,'Duplicate membership constrained');let rev=d.playlists.find(p=>p.id===pid).revision;
 check((await post('reorder',{playlistId:pid,revision:rev,trackIds:['2020-espresso','2010-love','y2k-yeah']})).status===200,'Reorder commits');
 check((await post('reorder',{playlistId:pid,revision:rev,trackIds:['y2k-yeah','2010-love','2020-espresso']})).status===409,'Stale reorder rejected');
 d=await snap();check(JSON.stringify(d.items.filter(i=>i.playlist_id===pid).map(i=>i.track_id))===JSON.stringify(['2020-espresso','2010-love','y2k-yeah']),'Stale edits preserve order');rev=d.playlists.find(p=>p.id===pid).revision;
 check((await post('reorder',{playlistId:pid,revision:rev,trackIds:['y2k-yeah','y2k-yeah','2020-espresso']})).status===409,'Duplicate reorder rejected');
 check((await post('reorder',{playlistId:pid,revision:rev,trackIds:['y2k-yeah']})).status===409,'Incomplete reorder rejected');
 check((await post('renamePlaylist',{id:pid,name:'Renamed set',description:'Updated'})).status===200,'Rename saves');
 for(let i=0;i<2;i++)check((await post('favorite',{userId:'owner',trackId:'y2k-yeah',liked:true})).status===200,'Spotify likes idempotent');
 d=await snap();check(d.favorites.filter(f=>f.user_id==='owner'&&f.track_id==='y2k-yeah').length===1,'Unique listener track likes');
 check((await post('favorite',{userId:'owner',trackId:'y2k-yeah',liked:false})).status===200,'Unlike saves');
 r=await post('createUser',{name:'Test listener'});check(r.status===201,'Listener profile creation');const uid=r.data.id;
 check((await post('listen',{userId:uid,trackId:'y2k-yeah',seconds:10,eventId:randomUUID()})).status===400,'Spotify clicks are not fabricated as listens');
 check((await post('addTrack',{playlistId:pid,trackId:'missing'})).status===404,'Invalid track rejected');
 check((await post('favorite',{userId:'missing',trackId:'y2k-yeah',liked:true})).status===404,'Invalid listener rejected');
 check((await post('createPlaylist',{name:'   '})).status===400,'Blank names rejected');
 check((await call('/api/library',{action:'createPlaylist',name:'Blocked'},{Origin:'https://evil.example'})).status===403,'Cross-origin mutation rejected');
 check((await post('removeTrack',{playlistId:pid,trackId:'2010-love'})).status===200,'Remove membership');
 check((await post('deletePlaylist',{id:pid})).status===200,'Delete playlist');d=await snap();check(!d.playlists.some(p=>p.id===pid)&&!d.items.some(i=>i.playlist_id===pid),'Cascade deletion');
 check((await post('deletePlaylist',{id:'era-2000'})).status===200,'Delete seeded era set');d=await snap();check(!d.playlists.some(p=>p.id==='era-2000'),'Reload does not restore deleted era sets');
 check((await post('deletePlaylist',{id:'dj-avicii'})).status===200,'Delete DJ collection');
 check(!(await snap()).playlists.some(p=>p.id==='dj-avicii'),'Reload preserves deleted DJ collection');
 check((await post('deletePlaylist',{id:'party-rap'})).status===200,'Delete party shortlist');
 check(!(await snap()).playlists.some(p=>p.id==='party-rap'),'Deleted party shortlist stays deleted');
 const wav=new Uint8Array(await readFile('public/demo/demo-1.wav'));
 const upload=async(name,bytes,bpm=120,genre='House')=>{const form=new FormData();for(const [k,v]of Object.entries({title:'Uploaded loop',creator:'Test creator',genre,bpm,key:'A minor',duration:24}))form.set(k,String(v));form.set('audio',new File([bytes],name,{type:'audio/wav'}));const req=new Request('http://test.local/api/library',{method:'POST',body:form});const response=await mf.dispatchFetch(req.url,{method:'POST',headers:Object.fromEntries(req.headers),body:new Uint8Array(await req.arrayBuffer())});return {status:response.status,data:await response.json()};};
 check((await upload('country.wav',wav,120,'Country')).status===201,'New genre accepted by upload API');
 check((await upload('bad-genre.wav',wav,120,'Invented')).status===400,'Unknown genre rejected by upload API');
 const decimalUpload=await upload('fractional.wav',wav,124.5);check(decimalUpload.status===201,'Upload accepts decimal BPM matching its form');
 const decimalTrack=(await snap()).tracks.find(t=>t.id===decimalUpload.data.id);check(decimalTrack.bpm===124.5,'Decimal BPM is preserved in the library');
 r=await upload('original.wav',wav);check(r.status===201,'Audio upload remains functional');const tid=r.data.id;
 let response=await mf.dispatchFetch('http://test.local/api/audio/'+tid);let bytes=new Uint8Array(await response.arrayBuffer());check(response.status===200&&Buffer.from(bytes).equals(Buffer.from(wav)),'R2 exact bytes');
 response=await mf.dispatchFetch('http://test.local/api/audio/'+tid,{headers:{Range:'bytes=0-99'}});bytes=new Uint8Array(await response.arrayBuffer());check(response.status===206&&Buffer.from(bytes).equals(Buffer.from(wav.slice(0,100))),'Correct prefix range');
 response=await mf.dispatchFetch('http://test.local/api/audio/'+tid,{headers:{Range:'bytes=-100'}});bytes=new Uint8Array(await response.arrayBuffer());check(response.status===206&&Buffer.from(bytes).equals(Buffer.from(wav.slice(-100))),'Correct suffix range');
 check((await mf.dispatchFetch('http://test.local/api/audio/'+tid,{headers:{Range:'bytes=999999999-'}})).status===416,'Out of bounds rejected');
 check((await mf.dispatchFetch('http://test.local/api/audio/'+tid,{headers:{Range:'bytes=99-1'}})).status===416,'Reversed range rejected');
 check((await mf.dispatchFetch('http://test.local/api/audio/missing')).status===404,'Missing audio 404');
 check((await upload('fake.wav',new TextEncoder().encode('not audio'))).status===400,'Spoofed files rejected');
 check((await upload('original.wav',wav,999)).status===400,'Invalid metadata rejected');
 const eventId=randomUUID();for(let i=0;i<2;i++)check((await post('listen',{userId:uid,trackId:tid,seconds:10,eventId})).status===200,'Uploaded listen idempotent');
 d=await snap();check(d.stats.plays===1&&d.stats.seconds===10,'Exact local listening aggregates');check(d.genres[0].genre==='House'&&d.genres[0].plays===1,'Real local genre analytics');
 check((await post('listen',{userId:uid,trackId:tid,seconds:100,eventId:randomUUID()})).status===200,'Clamp listen duration');d=await snap();check(d.stats.seconds===34,'No more seconds than uploaded audio duration');
 check((await post('listen',{userId:uid,trackId:tid,seconds:1,eventId:randomUUID()})).status===400,'Short activity rejected');
 r=await post('createPlaylist',{name:'Concurrent set'});const cp=r.data.id;for(const trackId of ['y2k-yeah','2010-love'])await post('addTrack',{playlistId:cp,trackId});d=await snap();rev=d.playlists.find(p=>p.id===cp).revision;
 const results=await Promise.all([['y2k-yeah','2010-love'],['2010-love','y2k-yeah']].map(trackIds=>post('reorder',{playlistId:cp,revision:rev,trackIds})));check(JSON.stringify(results.map(r=>r.status).sort())==='[200,409]','One concurrent reorder wins');
 let failed=false;try{await db.prepare('INSERT INTO favorites (user_id,track_id) VALUES (?,?)').bind('invalid-user','y2k-yeah').run();}catch{failed=true;}check(failed,'SQL foreign-key enforcement');
 failed=false;try{await db.prepare('UPDATE tracks SET bpm=999 WHERE id=?').bind(tid).run();}catch{failed=true;}check(failed,'SQL tempo constraint');
 const plan=await db.prepare('EXPLAIN QUERY PLAN SELECT * FROM listens WHERE track_id=?').bind(tid).all();check(plan.results.some(p=>String(p.detail).includes('idx_listens_track')),'Analytics index used');
 const artworkMissing=await mf.dispatchFetch('http://test.local/api/artwork/missing');check(artworkMissing.status===404,'Missing artwork fallback path');
 // DJ preparation and history exercise the compiled production endpoints.
 const dj=async()=>{const r=await call('/api/dj');check(r.status===200,'DJ data loads');return r.data;};
 let djdata=await dj();check(djdata.prep.length===0&&djdata.transitions.length===0&&djdata.total===0,'No invented DJ metadata or past transitions');
 const prepBody={action:'prep',trackId:'y2k-yeah',revision:-1,bpm:105.5,camelot:'8A',energy:7,cueIn:16,cueOut:180,notes:'User-supplied version and phrase notes'};
 check((await call('/api/dj',prepBody)).status===200,'Save DJ metadata');
 check((await call('/api/dj',prepBody)).status===409,'Concurrent initial prep does not overwrite');
 check((await call('/api/dj',{...prepBody,revision:0,bpm:106})).status===200,'Revision-checked metadata update');
 check((await call('/api/dj',{...prepBody,revision:0,bpm:110})).status===409,'Stale metadata edit rejected');
 djdata=await dj();check(djdata.prep[0].bpm===106&&djdata.prep[0].revision===1,'Stale editor preserves winner');
 check((await call('/api/dj',{...prepBody,revision:1,groove:'Breakbeat',phraseBars:16,introVocals:'Sparse',outroVocals:'Busy'})).status===200,'Save rhythm section details');
 check((await call('/api/dj',{...prepBody,revision:2,groove:'Made up'})).status===400,'Invalid groove rejected');
 check((await call('/api/dj',{...prepBody,revision:2,phraseBars:7})).status===400,'Invalid phrase length rejected');
 check((await call('/api/dj',{...prepBody,revision:2,introVocals:'Made up'})).status===400,'Invalid vocal level rejected');
 check((await call('/api/dj',{...prepBody,revision:2,bpm:106})).status===200,'Older client updates preserve optional rhythm fields');
 const rhythmPrep=(await dj()).prep.find(p=>p.track_id==='y2k-yeah');
 check(rhythmPrep.groove==='Breakbeat'&&rhythmPrep.phrase_bars===16&&rhythmPrep.intro_vocals==='Sparse'&&rhythmPrep.outro_vocals==='Busy','Rhythm metadata survives legacy-client save');
 check((await call('/api/dj',{...prepBody,revision:3,bpm:106,groove:null,phraseBars:null,introVocals:null,outroVocals:null})).status===200,'Explicit null clears optional rhythm data');
 const prepared=(await snap()).tracks.find(t=>t.id==='y2k-yeah');check(prepared.bpm===106&&prepared.musical_key==='8A'&&prepared.energy===7&&prepared.dj_notes===prepBody.notes,'Library exposes saved prep for search, sort, and display');
 for(const change of [{bpm:400},{camelot:'13A'},{energy:11},{cueIn:-1},{cueIn:30,cueOut:20},{cueOut:7201}])check((await call('/api/dj',{...prepBody,revision:1,...change})).status===400,'Invalid preparation rejected');
 check((await call('/api/dj',{...prepBody,trackId:'missing'})).status===404,'Missing prep track rejected');
 check((await call('/api/dj',{...prepBody,trackId:tid,cueIn:1,cueOut:25})).status===400,'Native cue cannot exceed audio duration');
 check((await call('/api/dj',prepBody,{Origin:'https://evil.example'})).status===403,'DJ writes reject cross-origin');
 const transition={id:randomUUID(),fromId:'y2k-yeah',toId:'2010-love',rating:5,technique:'Echo out',notes:'Past mix rated by user'};
 const record=entries=>call('/api/dj',{action:'record',entries});
 check((await record([transition])).status===200,'Record directed transition');check((await record([transition])).status===200,'Transition ID retry idempotent');
 djdata=await dj();check(djdata.total===1&&djdata.transitions.length===1,'One transition after retried request');
 const stored=djdata.transitions[0].features;check(JSON.parse(stored).length===8,'Frozen model features stored');
 check((await call('/api/dj',{...prepBody,revision:4,bpm:120})).status===200,'Subsequent metadata update');djdata=await dj();check(djdata.transitions[0].features===stored,'Metadata edits do not rewrite training history');
 for(const change of [{rating:0},{rating:6},{technique:'Unknown'},{fromId:'y2k-yeah',toId:'y2k-yeah'}])check((await record([{...transition,id:randomUUID(),...change}])).status===400,'Invalid transition rejected');
 const invalidBatch=[{...transition,id:randomUUID()},{...transition,id:randomUUID(),toId:'missing'}];check((await record(invalidBatch)).status===404,'Invalid bulk import rejected');djdata=await dj();check(djdata.total===1,'Invalid bulk import writes no partial history');
 check((await record([{...transition,id:randomUUID()},{...transition,id:randomUUID(),fromId:'2010-love',toId:'2020-espresso',rating:2}])).status===200,'Valid bulk import commits');djdata=await dj();check(djdata.total===3,'Both imported records persisted');
 check((await call('/api/dj',{action:'delete',id:transition.id})).status===200,'Delete incorrect rating');djdata=await dj();check(djdata.total===2&&!djdata.transitions.some(t=>t.id===transition.id),'Deleted rating excluded from training');
 let sqlRejected=false;try{await db.prepare('INSERT INTO dj_transitions (id,from_id,to_id,rating,technique,features) VALUES (?,?,?,?,?,?)').bind(randomUUID(),'y2k-yeah','2010-love',9,'Blend','[]').run();}catch{sqlRejected=true;}check(sqlRejected,'Rating range enforced in SQL');
 sqlRejected=false;try{await db.prepare('UPDATE dj_prep SET energy=99 WHERE track_id=?').bind('y2k-yeah').run();}catch{sqlRejected=true;}check(sqlRejected,'Energy constraint enforced in SQL');
 const finalLibrary=await snap();check(finalLibrary.items.some(i=>i.playlist_id==='legacy-set'&&i.track_id==='legacy-audio'),'DJ additions retain preexisting sets');
 // Re-run only the expansion against a saved and edited workspace, as an upgrade would.
 const preUpgrade=await snap(),preDJ=await dj();
 await db.batch([db.prepare("DELETE FROM app_state WHERE id LIKE 'vocal-expansion-v4-%'"),db.prepare("DELETE FROM tracks WHERE id LIKE 'more-%' AND id NOT IN (SELECT track_id FROM playlist_tracks)")]);
 const upgraded=await snap(),afterDJ=await dj();
 check(upgraded.tracks.filter(t=>t.spotify_id).length===154,'Existing v2 catalog flag does not block expansion');
 check(JSON.stringify(upgraded.playlists)===JSON.stringify(preUpgrade.playlists),'Expansion preserves all playlist records and revisions');
 check(JSON.stringify(upgraded.items)===JSON.stringify(preUpgrade.items),'Expansion preserves playlist membership and ordering');
 check(!upgraded.playlists.some(p=>p.id==='era-2000'),'Expansion does not restore a deleted starter set');
 check(JSON.stringify(afterDJ)===JSON.stringify(preDJ),'Expansion retains prep and ML transition history exactly');
 check(JSON.stringify(upgraded.favorites)===JSON.stringify(preUpgrade.favorites),'Expansion retains favorites');
 check(JSON.stringify(upgraded.stats)===JSON.stringify(preUpgrade.stats),'Expansion creates no fabricated listening activity');
 check((await call('/api/dj',{...prepBody,revision:5,bpm:null,camelot:null,energy:null,notes:''})).status===200,'Clear external preparation');
 const cleared=(await snap()).tracks.find(t=>t.id==='y2k-yeah');check(cleared.bpm===null&&cleared.musical_key===''&&cleared.energy===null&&cleared.dj_notes==='','Clearing prep returns unknown fields, without storage sentinels');
 check((await call('/api/dj',{...prepBody,trackId:'legacy-audio',revision:-1,bpm:121,camelot:'9A',energy:6,cueIn:1,cueOut:20})).status===200,'Prepare existing native upload');
 const editedNative=(await snap()).tracks.find(t=>t.id==='legacy-audio');check(editedNative.bpm===121&&editedNative.musical_key==='9A'&&editedNative.duration===24,'Native preparation overlays tempo and key while preserving audio length');
 check((await call('/api/dj',{...prepBody,trackId:'legacy-audio',revision:0,bpm:null,camelot:null,energy:null,cueIn:null,cueOut:null})).status===200,'Clear native overrides');
 const restoredNative=(await snap()).tracks.find(t=>t.id==='legacy-audio');check(restoredNative.bpm===118&&restoredNative.musical_key==='A minor','Cleared native overrides retain original uploaded metadata');

 
 console.log(JSON.stringify({passed:checks,scope:'Additive migration preserves data; vocal catalog, playlists, likes, analytics, uploads, range playback, DJ prep, frozen transition features, atomic import, and concurrency',externalPlayback:'Spotify controls and regional access not browser-verified',browserUI:'Unavailable'},null,2));
}finally{await mf.dispose();}
