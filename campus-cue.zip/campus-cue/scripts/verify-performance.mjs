import assert from 'node:assert/strict';
import { createPlaybackClock } from '../lib/playback-clock.ts';
import { artworkResponse } from '../lib/artwork-response.ts';
const clock = createPlaybackClock();
let updates = 0;
const unsubscribe = clock.subscribe(() => updates++);
clock.set(1); clock.set(1); clock.set(NaN); clock.set(-1);
assert.equal(updates, 1); assert.equal(clock.getSnapshot(), 1);
unsubscribe(); clock.set(2); assert.equal(updates, 1);
const good = await artworkResponse('test', async () => Response.json({ thumbnail_url: 'https://i.scdn.co/image/test' }));
assert.equal(good.status, 302); assert.equal(good.headers.get('Location'), 'https://i.scdn.co/image/test');
for (const fetcher of [
  async () => new Response(null, { status: 404 }),
  async () => Response.json({ thumbnail_url: 'https://example.com/unsafe' }),
  async () => Response.json({}),
  async () => { throw new Error('Offline'); }
]) {
  const fallback = await artworkResponse('test', fetcher);
  assert.equal(fallback.status, 200);
  assert.equal(fallback.headers.get('Content-Type'), 'image/svg+xml');
  assert.equal(fallback.headers.get('Cache-Control'), 'public, max-age=300');
  assert.match(await fallback.text(), /<svg/);
}
console.log('Playback subscriptions and artwork failures passed');
