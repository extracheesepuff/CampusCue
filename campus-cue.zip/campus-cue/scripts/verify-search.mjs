import assert from 'node:assert/strict';
import { searchTracks, normalizeSearch } from '../lib/search.ts';
import { parseHistory } from '../lib/dj-history.ts';
let checks = 0;
const check = (test, message) => { assert(test, message); checks++; };
const throws = (callback, pattern, message) => { assert.throws(callback, pattern, message); checks++; };
const track = (id, title, creator, extra = {}) => ({ id, title, creator, genre: 'Pop', decade: 2010, musical_key: '', ...extra });
const tracks = [
  track('beyonce', 'Crazy in Love', 'Beyoncé'),
  track('drake', 'One Dance', 'Drake'),
  track('rihanna', 'Don’t Stop the Music', 'Rihanna', { decade: 2000 }),
  track('pink', 'Raise Your Glass', 'P!nk', { musical_key: '8A', dj_notes: 'Clean intro edit', energy: 7 }),
  track('exact', 'Love', 'Another artist'),
  track('starts', 'Love Tonight', 'Artist'),
  track('duplicate', 'Love', 'Different artist')
];
check(normalizeSearch('  BEYONCÉ  ') === 'beyonce', 'Accents, case, and extra spaces normalize');
check(searchTracks(tracks, 'beyonce')[0]?.id === 'beyonce', 'Accent-free artist lookup');
check(searchTracks(tracks, 'drake dance one')[0]?.id === 'drake', 'Artist and title terms can appear in any order');
check(searchTracks(tracks, '  ONE   Drake  ')[0]?.id === 'drake', 'Extra spaces and case do not block matching');
check(searchTracks(tracks, 'dont stop')[0]?.id === 'rihanna', 'Curly apostrophes do not block matching');
check(searchTracks(tracks, 'p nk')[0]?.id === 'pink', 'Punctuation separates words');
check(searchTracks(tracks, 'pink')[0]?.id === 'pink', 'Artist stylization does not block plain-name lookup');
check(searchTracks(tracks, 'drake', 'title').length === 0, 'Title-only search excludes artist matches');
check(searchTracks(tracks, 'one', 'artist').length === 0, 'Artist-only search excludes title matches');
check(searchTracks(tracks, 'Beyoncé', 'artist')[0]?.id === 'beyonce', 'Artist scope finds names');
check(searchTracks(tracks, '8a clean intro')[0]?.id === 'pink', 'Saved key and prep notes are searchable together');
check(searchTracks(tracks, '2000s')[0]?.id === 'rihanna', 'Decade names are searchable');
check(searchTracks(tracks, 'love')[0]?.title === 'Love', 'Exact title outranks a title prefix');
check(searchTracks(tracks, 'drake impossible').length === 0, 'All terms must match');
check(searchTracks(tracks, '---').length === tracks.length, 'Punctuation-only search behaves as empty search');
const original = tracks.map(track => track.id).join();
searchTracks(tracks, 'love');
check(tracks.map(track => track.id).join() === original, 'Ranking does not mutate catalog order');
const entry = parseHistory('Crazy in Love | One Dance | 5 | Echo out | Smooth phrase\n', tracks)[0];
check(entry.fromId === 'beyonce' && entry.toId === 'drake' && entry.rating === 5, 'History import resolves directed tracks');
check(parseHistory('Dont Stop the Music | ONE DANCE | 3', tracks)[0].technique === 'Blend', 'History accepts spelling variants and optional fields');
check(parseHistory('Love — Different artist | One Dance | 2', tracks)[0].fromId === 'duplicate', 'Artist identifies duplicate titles');
throws(() => parseHistory('Love | One Dance | 5', tracks), /uniquely match/, 'Ambiguous title rejected');
throws(() => parseHistory('\nOne Dance | One Dance | 4', tracks), /Row 2: choose two different/, 'Original row numbers and self-transition validation');
throws(() => parseHistory('One Dance | Love | 6', tracks), /rating must/, 'Invalid rating rejected');
throws(() => parseHistory('One Dance | Crazy in Love | 3 | Bad technique', tracks), /listed technique/, 'Unknown technique rejected');
throws(() => parseHistory('One Dance | Missing | 3', tracks), /uniquely match/, 'Missing track rejected');
throws(() => parseHistory('', tracks), /between 1 and 100/, 'Empty import rejected');
throws(() => parseHistory(Array(101).fill('One Dance | Crazy in Love | 3').join('\n'), tracks), /between 1 and 100/, 'Bounded bulk import');
console.log(JSON.stringify({ passed: checks, scope: 'Search normalization, ranking, scopes, and transition import behavior' }));
